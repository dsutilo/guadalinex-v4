# -*- coding: utf-8 -*-
# Copyright (C) 2006-2007  Vodafone España, S.A.
# Author:  Pablo Martí
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License along
# with this program; if not, write to the Free Software Foundation, Inc.,
# 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
"""Model for the diagnostics window"""
__version__ = "$Rev: 406 $"

# python imports
import os

# twisted imports
from twisted.internet import defer, utils

# gtkmvc imports
from gtkmvc import Model

# VMC imports
from models.base import SerialConnectionDispatcher

class DiagnosticsModel(Model, SerialConnectionDispatcher):
    """Model for diagnostics window"""
    
    __properties__ = {}
    
    def __init__(self, device):
        Model.__init__(self)
        SerialConnectionDispatcher.__init__(self, device)
    
    def get_uptime(self):
        d = utils.getProcessOutput('cat', args=['/proc/uptime'])
        def2 = defer.Deferred()
        def callback(uptime, d2):
            uptime = uptime.split()[0]
            uptime = float(uptime)
            from common.uptime import get_uptime_string
            msg = get_uptime_string(uptime)
            d2.callback(msg)
            
        d.addCallback(callback, def2)
        return def2
        
    def get_os_name(self):
        return os.uname()[0]
    
    def get_os_version(self):
        return os.uname()[2]
        