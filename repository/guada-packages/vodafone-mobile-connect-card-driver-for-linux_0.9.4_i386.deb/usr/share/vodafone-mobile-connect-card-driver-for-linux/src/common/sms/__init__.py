# The contents of this file are subject to the Mozilla Public License
# Version 1.1 (the "License"); you may not use this file except in
# compliance with the License. You may obtain a copy of the License at
# http://www.mozilla.org/MPL/ 

# Software distributed under the License is distributed on an "AS IS"
# basis, WITHOUT WARRANTY OF ANY KIND, either express or implied. See
# the License for the specific language governing rights and
# limitations under the License. 

# The Original Code is Vivesto Solutions code. 

# The Initial Developer of the Original Code is Viveto Solutions.
# Portions created by the Initial Developer are Copyright (C) 2003 the
# Initial Developer. All Rights Reserved.

# Modified by Pablo Marti at Warp Networks S.L. 11 Jan 2007
# Added a __version__ field

__version__ = "$Rev: 68 $"

import codecs

def sms_search_function(name):
    if name == 'sms-default':
        try:
            import _smsenc
        except ImportError:
            return None
        else:
            codec = _smsenc.Codec()
            return (codec.encode, codec.decode, _smsenc.StreamReader,
                    _smsenc.StreamWriter)

codecs.register(sms_search_function)
