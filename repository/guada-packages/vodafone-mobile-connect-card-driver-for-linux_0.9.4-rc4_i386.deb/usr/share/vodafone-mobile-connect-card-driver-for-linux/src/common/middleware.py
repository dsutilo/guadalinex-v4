# -*- coding: utf-8 -*-
# Copyright (C) 2006-2007  Vodafone España, S.A.
# Author:  Pablo Martí
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License along
# with this program; if not, write to the Free Software Foundation, Inc.,
# 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
"""
Wrapper around common.SIMCardConnection

It basically provides error control and more high-level operations
"""

__version__ = "$Rev: 406 $"

# twisted imports
from twisted.internet import reactor, defer
# VMC imports
from common.protocol import SIMCardConnection
import common.exceptions as ex
from common.persistent import Contact
from common.sms.sms import pdu_to_message

class SIMCardConnAdapter(SIMCardConnection):
    
    def get_all_contacts(self):
        """Returns a list with all the contacts in the SIM"""
        def get_em(auxdefer=None):
            d2 = auxdefer and auxdefer or defer.Deferred()
            d = SIMCardConnection._get_all_contacts(self)
            def callback(contacts):
                clist = []
                for contact in contacts:
                    name = unicode(contact.group('name'), 'utf8')
                    clist.append(Contact(name,
                                         contact.group('number'),
                                         int(contact.group('id'))))
                
                d2.callback(clist)
            
            def no_contacts_eb(failure):
                failure.trap(ex.CMEErrorNotFound, ex.ATError)
                d2.callback([])
            
            def sim_busy_eb(failure):
                failure.trap(ex.CMEErrorSIMBusy, ex.CMEErrorSIMNotStarted)
                # This basically is a loop that will be repeated until we get
                # a response. The reason is that some times the card will
                # reply with a SIM BUSY error or similar while trying to read
                # the contacts/messages, this is buggy and needs to be handled
                reactor.callLater(2, get_em, d2)
            
            d.addCallback(callback)
            d.addErrback(no_contacts_eb)
            d.addErrback(sim_busy_eb)
        
            return d2
        
        return get_em()
    
    def get_all_sms(self):
        """
        Returns a list of ShortMessage objects with all the SMS in the SIM card
        """
        def get_em(auxdefer=None):
            d2 = auxdefer and auxdefer or defer.Deferred()
            
            d = SIMCardConnection.get_all_sms(self)
            def callback(messages):
                mlist = []
                for rawsms in messages:
                    # ShortMessage obj
                    sms = pdu_to_message(rawsms.group('pdu'))
                    sms.index = int(rawsms.group('id'))
                    sms.where = int(rawsms.group('storedat'))
                    mlist.append(sms)
                
                d2.callback(mlist)
            
            def error_sim_eb(failure):
                failure.trap(ex.CMEErrorNotFound, ex.ATError)
                d2.callback([])
            
            def sms_sim_busy_eb(failure):
                failure.trap(ex.CMEErrorSIMBusy,
                             ex.CMEErrorSIMNotStarted, ex.CMSError500)
                reactor.callLater(2, get_em, d2)
            
            d.addCallback(callback)
            d.addErrback(error_sim_eb)
            d.addErrback(sms_sim_busy_eb)
            
            return d2
        
        return get_em()
    
    def get_card_model(self):
        d = SIMCardConnection.get_card_model(self)
        d.addCallback(lambda response: response[0].group('model'))
        d2 = defer.Deferred()
        d.chainDeferred(d2)
        return d2
    
    def get_card_version(self):
        d = SIMCardConnection.get_card_version(self)
        d.addCallback(lambda response: response[0].group('version'))
        d2 = defer.Deferred()
        d.chainDeferred(d2)
        return d2
    
    def get_imei_number(self):
        d = SIMCardConnection.get_imei_number(self)
        d.addCallback(lambda response: response[0].group('imei'))
        d2 = defer.Deferred()
        d.chainDeferred(d2)
        return d2
    
    def get_imsi_number(self):
        d = SIMCardConnection.get_imsi_number(self)
        d.addCallback(lambda response: response[0].group('imsi'))
        d2 = defer.Deferred()
        d.chainDeferred(d2)
        return d2
    
    def get_phonebook_size(self):
        """Returns the phonebook size of the SIM card"""
        def get_it(auxdefer=None):
            d2 = auxdefer and auxdefer or defer.Deferred()
            
            d = SIMCardConnection.get_phonebook_size(self)
            def callback(resp):
                size = int(resp[0].group('size'))
                d2.callback(size)
            
            def errback(failure):
                failure.trap(ex.ATError, ex.CMEErrorSIMBusy, ex.CMSError500)
                reactor.callLater(2, get_it, d2)
                
            d.addCallback(callback)
            d.addErrback(errback)
            return d2
        
        return get_it()
    
    def get_pin_status(self):
        """Returns 1 if PIN authentication is set, 0 otherwise"""
        def get_it(auxdefer=None):
            d2 = auxdefer and auxdefer or defer.Deferred()
            
            d = SIMCardConnection._get_pin_status(self)
            
            def callback(resp):
                active = int(resp[0].group('status'))
                d2.callback(active)
                
            def busy_errback(failure):
                failure.trap(ex.CMEErrorSIMBusy, ex.CMEErrorSIMNotStarted)
                reactor.callLater(2, get_it, d2)
            
            def pinreq_errback(failure):
                failure.trap(ex.CMEErrorSIMPINRequired)
                d2.callback(1)
                
            d.addCallback(callback)
            d.addErrback(pinreq_errback)
            d.addErrback(busy_errback)
            
            return d2
        
        return get_it()
    
    
    def get_sms(self, index):
        d2 = defer.Deferred()
        d = SIMCardConnection.get_sms(self, index)
        def callback(rawsms):
            rawsms = rawsms[0]
            sms = pdu_to_message(rawsms.group('pdu'))
            sms.index = index
            sms.where = int(rawsms.group('storedat'))
            
            d2.callback(sms)
        d.addCallback(callback)
        return d2
    
    def _get_imsi_prefix(self):
        d = self.get_imsi_number()
        d.addCallback(lambda response: int(response[:5]))
        d2 = defer.Deferred()
        d.chainDeferred(d2)
        return d2
    
    def get_network_info(self, process=True):
        d = SIMCardConnection.get_network_info(self)
        def callback(netinfo):
            if netinfo:
                status = int(netinfo[0].group('status'))
                conn_type = (status == 0) and 'GPRS' or '3G'
                netname = netinfo[0].group('netname')
                if netname == 'Limited Service':
                    return None, None
                 
                try:
                    netname = int(netname)
                except ValueError:
                    # we got a string id
                    return netname, conn_type
                else:
                    if not process:
                        return netname, conn_type
                    
                    # we got a numeric id, lets convert it
                    from utils.utilities import get_network_name_from_id
                    from utils.utilities import country_to_code
                    def callback(response):
                        if not response:
                            return None, None
                            
                        operator = response[0]
                        country = response[1]
                        try:
                            code = country_to_code[country]
                        except KeyError:
                            code = country
                        
                        op_name = operator + ' ' + code.upper()
                        return op_name, conn_type
                    
                    return get_network_name_from_id(netname).addCallback(
                                                                 callback)
            else:
                return None, None
        
        d.addCallback(callback)
        d2 = defer.Deferred()
        d.chainDeferred(d2)
        return d2
    
    def get_network_names(self):
        d = SIMCardConnection.get_network_names(self)
        def process_network_names(resp):
            text = resp[0].group()
            processor = NetworkNamesProcessor(text)
            return processor.get_network_objects()
            
        d.addCallback(process_network_names)
        d2 = defer.Deferred()
        d.chainDeferred(d2)
        return d2
    
    def register_with_network(self):
        d = self._get_imsi_prefix()
        response_deferred = defer.Deferred()
        def check_if_necessary(imsi_prefix):
            # is it really necessary to try to register with a network?
            d = self.get_network_info(process=False)
            def check_if_cb(netinfo):
                netname, conn_type = netinfo
                if isinstance(netname, int):
                    if netname == imsi_prefix:
                        d = self.get_network_info()
                        d.chainDeferred(response_deferred)
                        
                    else:
                        def register_callback(net_obj):
                            d = SIMCardConnection.register_with_network(self,
                                                                net_obj.netid)
                            def callback(resp):
                                d2 = self.get_network_info()
                                d2.chainDeferred(response_deferred)
                                
                            d.addCallback(callback)
                        
                        self._get_netobj_to_register(imsi_prefix)\
                                .addCallback(register_callback)
                else:
                    response_deferred.callback(netinfo)
            
            d.addCallback(check_if_cb)
                           
        d.addCallback(check_if_necessary)
        return response_deferred
    
    def _get_netobj_to_register(self, prefix):
        d = self.get_network_names()
        def callback(net_objs):
            for net_obj in net_objs:
                if net_obj.netid == prefix:
                    return net_obj
            
        d.addCallback(callback)
        d2 = defer.Deferred()
        d.chainDeferred(d2)
        return d2

class NetworkObject(object):
    def __init__(self, netinfo):
        self.stat = None
        self.long_name = None
        self.short_name = None
        self.netid = None
        self.rat = None
        self.process_info(netinfo)
    
    def process_info(self, netinfo):
        #'1,"vodafone ES","voda ES","21401",0'
        fields = netinfo.split(',')
        self.stat = int(fields[0])
        self.long_name = fields[1].replace('"', '')
        self.short_name = fields[2].replace('"', '')
        self.netid = int(fields[3].replace('"', ''))
        self.rat = int(fields[4])
        
OPEN = 0x00
CLOSED = 0x01

class NetworkNamesProcessor(object):
    
    def __init__(self, text):
        self.text = text
        self.resp = []
        self.state = CLOSED
    
    def _process_text(self):
        # (1,"vodafone ES","voda ES","21401",0),
        # (2,"vodafone ES","voda ES","21401",2),
        # (1,"Retevision Movil","AMENA","21403",0),
        # (1,"movistar","movistar","21407",0),
        # (1,"movistar","movistar","21407",2),
        # (1,"Retevision Movil","AMENA","21403",2)
        tmpbuffer = []
        for ch in self.text:
            if ch == '(' and self.state == CLOSED:
                self.state = OPEN
            elif ch == ')' and self.state == OPEN:
                self.state = CLOSED
                net_name = NetworkObject(''.join(tmpbuffer))
                self.resp.append(net_name)
                tmpbuffer = []
            elif ch == ',' and self.state == CLOSED:
                continue
            else:
                tmpbuffer.append(ch)
    
    def get_network_objects(self):
        self._process_text()
        return self.resp
                