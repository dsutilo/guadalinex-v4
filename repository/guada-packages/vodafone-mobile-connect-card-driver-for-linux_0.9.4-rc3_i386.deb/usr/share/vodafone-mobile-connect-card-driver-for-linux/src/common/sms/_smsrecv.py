# -*- coding: utf-8 -*-
# Copyright (c) 2006 Thomas Lotze
# Zope Public License (ZPL) Version 2.1
# A copyright notice accompanies this license document that identifies the
# copyright holders.
# This license has been certified as open source. It has also been designated
# as GPL compatible by the Free Software Foundation (FSF).
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions are met:
#
# 1. Redistributions in source code must retain the accompanying copyright
# notice, this list of conditions, and the following disclaimer.
#
# 2. Redistributions in binary form must reproduce the accompanying copyright
# notice, this list of conditions, and the following disclaimer in the
# documentation and/or other materials provided with the distribution.
#
# 3. Names of the copyright holders must not be used to endorse or promote
# products derived from this software without prior written permission from
# the copyright holders.
#
# 4. The right to distribute this software or to use it for any purpose does
# not give you the right to use Servicemarks (sm) or Trademarks (tm) of the
# copyright holders. Use of them is covered by separate agreement with the
# copyright holders.
#
# 5. If any files are modified, you must cause the modified files to carry
# prominent notices stating that you changed the files and the date of any
# change.
# Disclaimer
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS ``AS IS'' AND ANY
# EXPRESSED OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
# WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE 
# DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS BE LIABLE FOR ANY
# DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
# (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
# ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
# (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
# THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

# Modified by Pablo Marti @ Warp Networks S.L. / 11 January 2007
# * Merged phebe/sms.py and phebe/gsmaddress.py
# * backported to python2.4

__version__ = "$Rev: 86 $"

import codecs
import datetime

hex_decoder = codecs.getdecoder("hex_codec")
utf_16_decoder = codecs.getdecoder("utf_16")
latin1_decoder = codecs.getdecoder("latin1")

DEFAULT_ALPHABET = 0
EIGHT_BIT = 1
UCS2 = 2

GSM_DEFAULT_TABLE = u"\
@£$¥èéùìòÇ\nØø\rÅå\
Δ_ΦΓΛΩΠΨΣΘΞ ÆæßÉ\
 !\"#¤%&'()*+,-./\
0123456789:;<=>?\
¡ABCDEFGHIJKLMNO\
PQRSTUVWXYZÄÖÑÜ§\
¿abcdefghijklmno\
pqrstuvwxyzäöñüà\
"

class FallbackDict(dict):

    def __init__(self, fallback, *args, **kwargs):
        super(FallbackDict, self).__init__(*args, **kwargs)
        self.__fallback = fallback
        
    def __missing__(self, key):
        return self.__fallback[key]

GSM_EXTENSION_TABLE = FallbackDict(GSM_DEFAULT_TABLE, {
    10: u"\f",
    20: u"^",
    27: u" ",
    40: u"{",
    41: u"}",
    47: u"\\",
    60: u"[",
    61: u"~",
    62: u"]",
    64: u"|",
    101: u"€",
    })

class ShortMessage(object):
    """Represents a generic GSM short message.
    """

    pdu_type = "generic"

    pdu = None
    address = None
    datetime = None
    header = None
    user_data = None

    def __init__(self, pdu=""):
        self.pdu = pdu

    def __repr__(self):
        return "<Short message of type %s: %r>" % (self.pdu_type,
                                                   self.user_data)

    def user_data_from_octets(self, flags, octets, coding_scheme):
        user_data_len = octets.pop(0)

        if flags & 64: # user data header indicator
            header_len8 = octets[0] + 1
            self.header = octets[1:header_len8]
        else:
            header_len8 = 0

        compressed = (coding_scheme & 224 == 32)

        if (coding_scheme & 236 == 0 # general data coding
            or coding_scheme & 224 == 192 # message waiting indication
            or coding_scheme & 244 == 240): # data coding/message class
            coding = DEFAULT_ALPHABET
        elif (coding_scheme & 236 == 4 # general data coding
              or coding_scheme & 244 == 244): # data coding/message class
            coding = EIGHT_BIT
        elif (coding_scheme & 236 == 8 # general data coding
              or coding_scheme & 240 == 224): # message waiting indication
            coding = UCS2
        else:
            raise ValueError("Unsupported coding scheme.")

        if coding == DEFAULT_ALPHABET and not compressed:
            header_len7 = (header_len8*8 + 6)/7 # ceil(int*8/7)
            septets = unpack_septets(octets)[header_len7:user_data_len]
            self.user_data = gsm_decoder(septets)
        else:
            octets = octets[header_len8:user_data_len]
            if compressed:
                raise NotImplementedError

            if coding == DEFAULT_ALPHABET:
                self.user_data = gsm_decoder(unpack_septets(octets))
            else:
                user_data = "".join(chr(o) for o in octets)
                if coding == UCS2:
                    self.user_data = utf_16_decoder(user_data)[0]
                elif coding == EIGHT_BIT:
                    self.user_data = latin1_decoder(user_data)[0]

class ShortMessageDeliver(ShortMessage):
    """Represents a short message of PDU type DELIVER.
    """

    pdu_type = "DELIVER"

    def protocol_data_from_octets(self, flags, octets):
        self.address = gsm_address_from_octets(octets)
        del octets[0] # protocol identifier
        coding_scheme = octets.pop(0)
        self.datetime = datetime_from_octets(octets)

        return coding_scheme

    def dump(self):
        return """\
Sender: %s
Date: %s

%s
""" % (self.address, self.datetime, self.user_data)


class ShortMessageSubmit(ShortMessage):
    """Represents a short message of PDU type SUBMIT.
    """

    pdu_type = "SUBMIT"

    def protocol_data_from_octets(self, flags, octets):
        del octets[0] # TP message reference
        self.address = gsm_address_from_octets(octets)
        del octets[0] # protocol identifier
        coding_scheme = octets.pop(0)

        # TP validity period
        if flags & 8: # enhanced or absolute format
            del octets[:7]
        elif flags & 16: # relative format
            del octets[0]

        return coding_scheme

    def dump(self):
        return """\
Recipient: %s

%s
""" % (self.address, self.user_data)

def pdu_to_short_message(pdu):
    """Factory for short message objects.

    pdu: PDU formatted message

    returns an instance of a ShortMessage subclass
    """
    octets = [ord(c) for c in hex_decoder(pdu)[0]]

    smsc_len = octets.pop(0)
    del octets[0] # smsc address type
    del octets[:smsc_len-1] # smsc address

    flags = octets.pop(0)

    cls = {0: ShortMessageDeliver,
           1: ShortMessageSubmit,
           }[flags & 3] # message type indicator
    obj = cls(pdu)

    coding_scheme = obj.protocol_data_from_octets(flags, octets)
    obj.user_data_from_octets(flags, octets, coding_scheme)

    return obj

def gsm_address_from_octets(octets):
    """Read a gsm address from octets.

    Consumes those octets holding the address field.

    returns GSMAddress
    """
    address_len = octets.pop(0)
    address_type = octets.pop(0)
    number = ""
    while len(number) < address_len:
        o = octets.pop(0)
        number += str(o & 15) + str(o >> 4)
    number = number[:address_len]
    return GSMAddress(number, address_type)

def datetime_from_octets(octets):
    """Read date and time from octets.

    Consumes those octets holding the timestamp.

    returns naive datetime.datetime instance relative to UTC
    """
    values = [(o&15)*10 + (o>>4) for o in octets[:7]]
    del octets[:7]
    year = values[0]
    if year < 68:
        year = year + 2000
    result = datetime.datetime(year, *values[1:6])
    zone = values[-1]
    delta = datetime.timedelta(minutes=(zone&127)*15)
    if zone & 128:
        result -= delta
    else:
        result += delta
    return result

def unpack_septets(octets):
    """Decode 7 bit character strings packed into 8 bit byte strings.

    input: iterable of int

    returns str
    """
    septets = []
    overflow = overflow_len = 0

    for value in octets:
        septets.append(value << overflow_len & 127 | overflow)
        overflow = value >> (7 - overflow_len)
        overflow_len += 1
        if overflow_len == 7:
            septets.append(overflow)
            overflow = overflow_len = 0

    return septets

def gsm_decoder(septets):
    """Decode septets to unicode by the GSM default alphabet.

    septets: iterable of int

    returns unicode
    """
    septets_iter = iter(septets)
    resp = []
    for s in septets_iter:
        if s != 27:
            resp.append(GSM_DEFAULT_TABLE[s])
        else:
            resp.append(GSM_EXTENSION_TABLE[septets_iter.next()])
    return u"".join(resp)

TYPE_UNKNOWN = 0
TYPE_INTERNATIONAL = 1
TYPE_NATIONAL = 2

PLAN_UNKNOWN = 0
PLAN_ISDN = 1

def get_number_type(address_type):
    return {
        0: TYPE_UNKNOWN,
        1: TYPE_INTERNATIONAL,
        2: TYPE_NATIONAL,
        }.get(address_type >> 4 & 7)

def get_numbering_plan(address_type):
    return {
        0: PLAN_UNKNOWN,
        1: PLAN_ISDN,
        }.get(address_type & 15)

def normalize(value, type):
    if get_number_type(type) == TYPE_INTERNATIONAL and value.startswith('+'):
        return value[1:]
    else:
        return value

class GSMAddress(object):
    """Represents a typeful GSM address."""
    __all = {}

    __value = None
    value = property(lambda self: self.__value)

    __type = None
    type = property(lambda self: self.__type)

    __number_type = None
    number_type = property(lambda self: self.__number_type)

    __numbering_plan = None
    numbering_plan = property(lambda self: self.__numbering_plan)

    def __new__(cls, value, type):
        value = normalize(value, type)
        self = cls.__all.get((type, value))
        if self is None:
            self = cls.__all[(type, value)] = object.__new__(cls)
        return self

    def __init__(self, value, type):
        value = normalize(value, type)
        self.__value = value
        self.__type = type
        self.__number_type = get_number_type(type)
        self.__numbering_plan = get_numbering_plan(type)

    def __repr__(self):
        return "<GSM address of type %s: %s>" % (self.type, self.value)

    def __str__(self):
        return "%s: %s" % (self.type, self.value)
    
    def get_number(self):
        if self.__number_type == TYPE_INTERNATIONAL:
            return '+' + self.__value
        else:
            return self.__value
    