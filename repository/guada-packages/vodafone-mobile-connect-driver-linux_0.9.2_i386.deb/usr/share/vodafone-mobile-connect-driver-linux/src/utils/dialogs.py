# Author:  Pablo Marti
# Copyright (C) 2006  Warp Networks S.L.
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License along
# with this program; if not, write to the Free Software Foundation, Inc.,
# 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
"""Some utilities for displaying dialogs"""
__version__ = "$Rev: 308 $"

# python imports
import os.path
# gtk imports
import gtk
# gtkmvc imports
from gtkmvc.controller import Controller
from gtkmvc.model import Model
# VMC imports
import views.dialogs

class PopupDialogCtrl (Controller):
    """Base controller class for popup dialogs"""
    
    def __init__(self):
        Controller.__init__(self, Model())

def open_message_dialog(message, details):
    """Shows a standard message dialog"""
    ctrl =  PopupDialogCtrl()
    view = views.dialogs.DialogMessage(ctrl, message, details)
    view.run()
    
def open_warning_request_cancel_ok(message, details):
    """Returns True if the user confirmed the request, False otherwise"""
    ctrl = PopupDialogCtrl()
    view = views.dialogs.WarningRequestOkCancel(ctrl, message, details)
    resp = view.run()
    return resp == gtk.RESPONSE_OK

def open_confirm_action_dialog(action_text, message, details):
    """Returns True if the user confirmed the action, False otherwise"""
    ctrl = PopupDialogCtrl()
    view = views.dialogs.QuestionConfirmAction(ctrl, action_text, message,
                                            details)
    resp = view.run()
    return resp == gtk.RESPONSE_OK

def open_import_csv_dialog(path=None):
    """Opens a filechooser dialog to import a csv file"""
    title = _("Import contacts from...")
    chooser_dialog = gtk.FileChooserDialog(title,
                    buttons = (gtk.STOCK_CANCEL, gtk.RESPONSE_CANCEL,
                               gtk.STOCK_OPEN, gtk.RESPONSE_OK))
    
    chooser_dialog.set_default_response(gtk.RESPONSE_OK)
    
    filter_ = gtk.FileFilter()
    filter_.set_name(_("Csv files"))
    filter_.add_mime_type("text/xml")
    filter_.add_pattern("*csv")
    chooser_dialog.add_filter(filter_)
    filter_ = gtk.FileFilter()
    filter_.set_name(_("All files"))
    filter_.add_pattern("*")
    chooser_dialog.add_filter(filter_)
    
    if path:
        chooser_dialog.set_filename(os.path.abspath(path))
    if chooser_dialog.run() == gtk.RESPONSE_OK:
        resp = chooser_dialog.get_filename()
    else:
        resp = None

    chooser_dialog.destroy()
    return resp

def save_csv_file(path=None):
    """Opens a filechooser dialog to choose where to save a csv file"""
    title = _("Save as ...")
    chooser_dialog = gtk.FileChooserDialog(title,
                    action=gtk.FILE_CHOOSER_ACTION_SAVE,
                    buttons = (gtk.STOCK_CANCEL, gtk.RESPONSE_CANCEL,
                               gtk.STOCK_SAVE, gtk.RESPONSE_OK))

    chooser_dialog.set_default_response(gtk.RESPONSE_OK)
    filter_ = gtk.FileFilter()
    filter_.set_name(_("Csv files"))
    filter_.add_mime_type("text/xml")
    filter_.add_pattern("*csv")
    chooser_dialog.add_filter(filter_)

    filter_ = gtk.FileFilter()
    filter_.set_name(_("All files"))
    filter_.add_pattern("*")
    chooser_dialog.add_filter(filter_)

    if path:
        chooser_dialog.set_filename(os.path.abspath(path))
    if chooser_dialog.run() == gtk.RESPONSE_OK:
        resp = chooser_dialog.get_filename()
        if os.path.isfile(resp):
            # requests to confirm overwrite:
            overwrite = open_confirm_action_dialog(_("Overwrite"),
                          _('Overwrite "%s"?') % os.path.basename(resp),
                          _("""A file with this name already exists.
If you choose to overwrite this file, the contents will be lost."""))
            if not overwrite:
                resp = None
            
    else:
        resp = None

    chooser_dialog.destroy()
    return resp
