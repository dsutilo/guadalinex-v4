# -*- coding: utf-8 -*-
# Copyright (C) 2006-2007  Vodafone España, S.A.
# Author:  Pablo Martí
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License along
# with this program; if not, write to the Free Software Foundation, Inc.,
# 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
"""
Utilities to measure network speed in an hardware agnostic way
"""
__version__ = "$Rev: 406 $"

# python imports
import re
from time import time

# twisted imports
from twisted.internet import task, defer
from twisted.internet.utils import getProcessOutput

STATSREGEXP = re.compile('\s+ppp0:\s+(?P<in>\d+)\s+\d+\s+\d+\s+\d+\s+\d+\s+\d+\s+\d+\s+\d+\s+(?P<out>\d+)')

class NetworkSpeed(object):
    """Class to measure network speed"""
    
    CMD = 'cat'
    PATH = '/proc/net/dev'
    INTERVAL = .5
    
    def __init__(self):
        self.speed = {'down': 0.0, 'up': 0.0}
        self.loop = task.LoopingCall(self.compute_stats)
        self.mutex = defer.DeferredLock()
        self.__time = None
        self.__inbytes = 0
        self.__outbytes = 0
    
    def __getitem__(self, key):
        if key in self.speed:
            return self.speed[key]
        raise IndexError
        
    def start(self):
        self.loop.start(self.INTERVAL, now=False)
        self.__time = time()
    
    def stop(self):
        self.loop.stop()
        
    def compute_stats(self):
        d = getProcessOutput(self.CMD, args=[self.PATH])
        d.addCallback(self.parse_input)
        d.addCallback(self.update_stats)
        
    def parse_input(self, text):
        """Extracts the recv and sent bytes from /proc/net/dev"""
        inbytes = None
        outbytes = None
        match = STATSREGEXP.search(text)
        if match:
            inbytes = int(match.group('in'))
            outbytes = int(match.group('out'))
            
        return inbytes, outbytes
    
    def update_stats(self, (inbytes, outbytes)):
        """Updates the stats with parse_input's result"""
        # Inspired by Gdesklet's Net.py module
        if inbytes is None or outbytes is None:
            return
        
        if not self.__inbytes or not self.__outbytes:
            self.__inbytes = inbytes
            self.__outbytes = outbytes
        
        def doit(ignored):
            now = time()
            interval = now - self.__time
            
            in_diff = inbytes - self.__inbytes
            out_diff = outbytes - self.__outbytes
            
            speed_in  = int(in_diff / interval)
            speed_out = int(out_diff / interval)
            
            self.speed['down'] = speed_in
            self.speed['up'] = speed_out
                    
            self.__inbytes = inbytes
            self.__outbytes = outbytes
            self.__time = now
            self.mutex.release()
        
        d = self.mutex.acquire()
        d.addCallback(doit)
        