# Author:  Pablo Marti
# Copyright (C) 2006  Warp Networks S.L.
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License along
# with this program; if not, write to the Free Software Foundation, Inc.,
# 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
"""
Module uptime
"""
__version__ = "$Rev: 118 $"

# fix path stuff
import sys
sys.path = ['/home/huno/vmc/src'] + sys.path

# python imports
import time
# VMC imports
from common.uptime import get_time_dict, get_uptime_string

class TestUptime:
    """Tests for uptime module"""
    
    def test_get_time_dict(self):
        assert get_time_dict(120) == {'minute': 2}
        assert get_time_dict(86460) == {'day': 1, 'minute' : 1}
    
    def test_get_uptime_string(self):
        assert get_uptime_string(120) == "0:02"
        assert get_uptime_string(86460) == "1 day, 0:01"
        assert get_uptime_string(86359) == "23:59"
        