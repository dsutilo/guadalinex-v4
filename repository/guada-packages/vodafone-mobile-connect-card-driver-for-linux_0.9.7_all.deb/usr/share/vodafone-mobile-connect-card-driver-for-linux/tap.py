# -*- coding: utf-8 -*-
# Copyright (C) 2006-2007  Vodafone España, S.A.
# Author:  Pablo Martí
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License along
# with this program; if not, write to the Free Software Foundation, Inc.,
# 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
"""
Starts Vodafone Mobile Connect driver for Linux

execute it with:  twistd -r gtk2 -noy tap.py
"""

import os
import sys
import re
import gettext
import locale

from twisted.internet import reactor
from twisted.application.service import Application

from vmc.common.startup import create_service
from vmc.common.oal import get_os_object
import vmc.utils.globals
import vmc.utils.dialogs
from vmc.common.exceptions import DeviceNotFoundError, DeviceLacksExtractInfo
from vmc.common.hardware import HardwareRegistry
from vmc.common.encoding import _

__version__ = "$Rev: 658 $"

# i10n stuff
locale.setlocale(locale.LC_ALL, '')

from vmc.common.startup import check_dependencies, check_permissions
    
probs = check_dependencies()
if probs:
    message = _('Missing dependencies')
    probtext = '\n'.join(probs)
    details = _('The following dependencies are not satisfied:\n%s') % probtext
    vmc.utils.dialogs.open_warning_dialog(message, details)
    raise SystemExit

osobj = get_os_object()
if not osobj:
    message = _('OS/Distro not registered')
    details = """
The OS/Distro under which you are running %s
is not registered in the OS database. Check the common.oal module for what
you can do in order to support your OS/Distro
""" % vmc.utils.globals.APP_LONG_NAME
    vmc.utils.dialogs.open_warning_dialog(message, details)
    raise SystemExit

if osobj.manage_secrets:
    probs = check_permissions()
    if probs:
        message = _('Permissions problems')
        probtext = '\n'.join(probs)
        details = """
    %s needs the following files and dirs with some specific permissions
    in order to work properly:\n%s""" % (vmc.utils.globals.APP_LONG_NAME,
                                         probtext)
    
        vmc.utils.dialogs.open_warning_dialog(message, details)
        raise SystemExit

def get_device():
    hw_reg = HardwareRegistry()
    
    try:
        device = hw_reg.get_3g_device()
    except DeviceNotFoundError:
        device = None
        
    return device

device = get_device()

def install_signal_handler():
    import signal
    from vmc.common.shutdown import shutdown_core
    signal.signal(signal.SIGINT, shutdown_core)

install_signal_handler()

service = create_service(device)
application = Application(vmc.utils.globals.APP_SHORT_NAME)
service.setServiceParent(application)
