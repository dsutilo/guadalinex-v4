# Author:  Pablo Marti
# Copyright (C) 2006  Warp Networks S.L.
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License along
# with this program; if not, write to the Free Software Foundation, Inc.,
# 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

__version__ = "$Rev: 207 $"

# python imports
import os
# gtk imports
import gtk
import gobject
# gtkmvc imports
from gtkmvc.model import ListStoreModel
# VMC imports
import utils.globals

MOBILE_IMG = gtk.gdk.pixbuf_new_from_file(
              os.path.join(utils.globals.IMAGES_DIR, 'mobile.png'))
COMPUTER_IMG = gtk.gdk.pixbuf_new_from_file(
              os.path.join(utils.globals.IMAGES_DIR, 'computer.png'))

class ContactsStoreModel(ListStoreModel):
    """Store Model for Contacts treeviews"""
    def __init__(self):
        ListStoreModel.__init__(self, gtk.gdk.Pixbuf,
                    gobject.TYPE_STRING, gobject.TYPE_STRING,
                    gobject.TYPE_STRING)
    
    def add_contacts(self, contacts):
        for contact in contacts:
            self.add_contact(contact)
    
    def add_contact(self, contact):
        entry = []
        if contact.index < 1000:
            entry.append(MOBILE_IMG)
        else:
            entry.append(COMPUTER_IMG)
        
        entry.append(contact.name)
        entry.append(contact.number)
        entry.append(str(contact.index))
        
        self.append(entry)
        