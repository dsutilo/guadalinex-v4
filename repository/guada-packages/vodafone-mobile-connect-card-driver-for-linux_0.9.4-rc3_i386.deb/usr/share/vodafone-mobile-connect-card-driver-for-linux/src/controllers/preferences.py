# Author:  Pablo Marti
# Copyright (C) 2006  Warp Networks S.L.
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License along
# with this program; if not, write to the Free Software Foundation, Inc.,
# 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
"""
Preferences' Controllers
"""
__version__ = "$Rev: 389 $"

# python
import os

# gtkmvc imports
from gtkmvc import Controller
from gtkmvc import Model

# VMC imports
from views.preferences import ProfileEditorView
from common.hardware import CONN_OPTS_DICT
from common.config import VMCConfig
from common import wvdialprofile
import utils.dialogs
import utils.globals
import common.exceptions as ex

class PreferencesController(Controller):
    """Controller for preferences"""
    
    def __init__(self, model, parent_ctrl):
        Controller.__init__(self, model)
        self.parent_ctrl = parent_ctrl
    
    def register_view(self, view):
        Controller.register_view(self, view)
        preferences = self.get_conn_preferences()
        self.initial_conn = preferences['connection']

    def get_conn_preferences(self):
        model = self.view['connection_combobox'].get_model()
        index = self.view['connection_combobox'].get_active()
        if index < 0:
            conn = None
        else:
            conn = model[index][0]
        
        conn_option = CONN_OPTS_DICT[conn]
        return dict(username=self.view['username_entry'].get_text(),
                    password=self.view['password_entry'].get_text(),
                    connection=conn_option,
                    apn = self.view['apn_entry'].get_text())
    
    def get_selected_wvdial_profile(self):
        model = self.view['wvdial_profiles_combobox'].get_model()
        index = self.view['wvdial_profiles_combobox'].get_active()
        if index < 0:
            return None
        else:
            name = model[index][0]
            return wvdialprofile.get_profile_from_name(name)
    
    # ------------------------------------------------------------ #
    #                       Signals Handling                       #
    # ------------------------------------------------------------ #
    
    def on_preferences_ok_button_clicked(self, widget):
        preferences = self.get_conn_preferences()
        
        conf = VMCConfig()
        conf.set('connection', 'username', preferences['username'])
        conf.set('connection', 'password', preferences['password'])
        conf.set('connection', 'connection', preferences['connection'])
        conf.set('connection', 'apn', preferences['apn'])
        
        if self.view['checkbutton'].get_active():
            dns1 = self.view['dns1_entry'].get_text()
            dns2 = self.view['dns2_entry'].get_text()
            if not self._validate_correct_dns_ip(dns1):
                self.popup_invalid_url()
                self.view['dns1_entry'].select_region(0, -1)
                return
            elif not self._validate_correct_dns_ip(dns2):
                self.popup_invalid_url()
                self.view['dns2_entry'].select_region(0, -1)
                return
            else:
                conf.set('connection', 'dns1', dns1)
                conf.set('connection', 'dns2', dns2)
                conf.set('connection', 'staticdns', 'yes')
                
        else:
            conf.set('connection', 'staticdns', 'no')
        
        # secondpage
        custom = self.view['custom_profile_checkbutton'].get_active()
        if custom:
            conf.set('connection', 'use_custom_wvdial_profile', 'yes')
            # get combobox option
            profile = self.get_selected_wvdial_profile()
            if not profile:
                conf.set('connection', 'use_custom_wvdial_profile', 'no')
            else:
                conf.set('connection', 'use_custom_wvdial_profile', 'yes')
                conf.set('connection', 'wvdial_profile_name', profile.name)
                conf.write()
                from common.wvdialprofile import link_configuration
                link_configuration()
                
        else:
            conf.set('connection', 'use_custom_wvdial_profile', 'no')
        
        conf.write()
        
        if not self.model.device:
            self._hide_ourselves()
            return
        
        # check if the user has changed the conn preferences
        if self.initial_conn == preferences['connection']:
            self._hide_ourselves()
            return
        
        # now set the new connection preference
        conn_str = self.model.device.conn_dict[preferences['connection']]
        d = self.model.send_conn_string(conn_str)
        def callback(resp):
            # now hide
            self._hide_ourselves()
            from twisted.internet import reactor
            reactor.callLater(1, self.parent_ctrl.set_cell_type)
            
        def errback(failure):
            print "FAILURE received setting up connection", failure
            
        d.addCallback(callback)
        d.addErrback(errback)
    
    def on_preferences_cancel_button_clicked(self, widget):
        self._hide_ourselves()
    
    def _hide_ourselves(self):
        self.model.unregister_observer(self)
        self.view.hide()
    
    def on_checkbutton_toggled(self, widget):
        try:
            active = self.view['checkbutton'].get_active()
        except TypeError:
            # We ignore this because the view will emit the toggled signal
            # and as the controller is not still registered, it produces
            # an exception, we can safely ignore it.
            return
        
        if active:
            self.view['dns1_entry'].set_sensitive(True)
            self.view['dns2_entry'].set_sensitive(True)
        else:
            self.view['dns1_entry'].set_sensitive(False)
            self.view['dns2_entry'].set_sensitive(False)
    
    # second notebook page stuff
    
    def on_custom_profile_checkbutton_toggled(self, button):
        try:
            if button.get_active():
                self.view['frame19'].set_sensitive(True)
                # populate combobox
                self.view.setup_wvdial_combobox()
            else:
                self.view['frame19'].set_sensitive(False)
        except TypeError:
            # the controller is not registered yet,
            # it can be safely ignored
            pass
    
    def on_new_wvdialprof_button_clicked(self, button):
        ctrl = ProfileEditorController(Model())
        view = ProfileEditorView(ctrl)
        view.set_new_view()
    
    def on_edit_wvdialprof_button_clicked(self, button):
        profile = self.get_selected_wvdial_profile()
        if not profile:
            return
        
        ctrl = ProfileEditorController(Model())
        view = ProfileEditorView(ctrl)
        view.set_edit_view()
        
        ctrl._load_profile(profile)
    
    def on_delete_wvdialprof_button_clicked(self, button):
        profile = self.get_selected_wvdial_profile()
        if not profile:
            return
        
        message = _("Delete profile")
        details = _(
            "Are you sure that you want to delete profile %s") % profile.name
        resp = utils.dialogs.open_warning_request_cancel_ok(message, details)
        if not resp:
            return
        
        try:
            wvdialprofile.delete_profile(profile)
        except ex.ProfileNotFoundError:
            message = _("Error while deleting profile")
            details = _("Profile %s does not exists") % profile
            utils.dialogs.open_message_dialog(message, details)
        except (IOError, OSError):
            message = _("Error while deleting profile")
            details = _("Profile %s can not be deleted") % profile
            utils.dialogs.open_message_dialog(message, details)

        # regenerate combobox
        self.view.setup_wvdial_combobox()
    
    # ------------------------------------------------------------ #
    #                       Misc Functionality                     #
    # ------------------------------------------------------------ #
    
    def _validate_correct_dns_ip(self, ip_str):
        return self.model.validate_ip(ip_str)
    
    def popup_invalid_url(self):
        import utils.dialogs
        message = _("Invalid IP")
        details = _("The IP you've just entered is not valid")
        utils.dialogs.open_message_dialog(message, details)


class ProfileEditorController(Controller):
    """Controller for the profiles' editor"""
    
    def __init__(self, model, profile=None):
        Controller.__init__(self, model)
        self.changed = False
        self.setting_text = False
        self.profile = profile
    
    def register_view(self, view):
        Controller.register_view(self, view)
        self.setup_signals()
        if self.profile:
            self._load_profile(self.profile)
        
        self.view['save_button'].set_sensitive(False)
    
    def setup_signals(self):
        textbuffer = self.view['textview1'].get_buffer()
        textbuffer.connect('changed', self._textbuffer_changed)
    
    def _textbuffer_changed(self, textbuffer):
        if self.setting_text or self.changed:
            return
        
        self.changed = True
        self.view['save_button'].set_sensitive(True)
    
    def on_save_button_clicked(self, button):
        from utils.utilities import save_file
        text = self.get_text()
        if self.profile: # we are editing an existing profile
            save_file(self.profile.path, text)
            self._hide_myself()
        else: # we are editing a new profile
            # this path.join is needed as the FileDialog does a basename(path)
            path = utils.dialogs.save_standard_file(os.path.join(
                        utils.globals.WVDIAL_PROFILES, 'foo'))
            if path:
                save_file(path, text)
                self._hide_myself()
    
    def _hide_myself(self):
        self.view.hide()
        self.model.unregister_observer(self)
        
    def on_cancel_button_clicked(self, button):
        self.view.hide()
        self.model.unregister_observer(self)
    
    def _load_profile(self, profile):
        from utils.utilities import get_file_data
        text = get_file_data(profile.path)
        self.set_text(text)
    
    def get_text(self):
        textbuffer = self.view['textview1'].get_buffer()
        start, end = textbuffer.get_bounds()
        return textbuffer.get_text(start, end)
    
    def set_text(self, text):
        textbuffer = self.view['textview1'].get_buffer()
        self.setting_text = True
        textbuffer.set_text(text)
        self.setting_text = False
    