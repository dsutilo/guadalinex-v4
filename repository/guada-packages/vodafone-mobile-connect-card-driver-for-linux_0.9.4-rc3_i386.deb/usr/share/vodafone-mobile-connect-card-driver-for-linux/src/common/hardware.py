# Author:  Pablo Marti
# Copyright (C) 2006  Warp Networks S.L.
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License along
# with this program; if not, write to the Free Software Foundation, Inc.,
# 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
"""
Set of classes that handle device discovery via dbus/hal
"""
__version__ = "$Rev: 363 $"

# dbus imports
import dbus

if dbus.version >= (0, 80, 0):
    print "VMC with dbus >= 0.8.0 is currently broken"
    from twisted.internet import reactor
    reactor.stop()

if getattr(dbus, 'version', (0, 0, 0)) >= (0, 41, 0):
    import dbus.glib
    
# louie imports
import louie

# VMC imports
import common.exceptions as ex
import utils.globals
from utils.utilities import dict_reverter

try:
    _
except NameError:
    import gettext
    _ = gettext.gettext

HUAWEI_DICT = {
   'GPRSONLY' : 'AT^SYSCFG=13,1,3FFFFFFF,2,4',
   '3GONLY'   : 'AT^SYSCFG=14,2,3FFFFFFF,2,4',
   'GPRSPREF' : 'AT^SYSCFG=2,1,3FFFFFFF,2,4',
   '3GPREF'   : 'AT^SYSCFG=2,2,3FFFFFFF,2,4',
}

OPTION_DICT = {
   'GPRSONLY' : 'AT_OPSYS=0',
   '3GONLY'   : 'AT_OPSYS=1',
   'GPRSPREF' : 'AT_OPSYS=2',
   '3GPREF'   : 'AT_OPSYS=3',
}

CONN_OPTS_LIST = [_('GPRS only').encode('utf8'),
                  _('3G only').encode('utf8'),
                  _('GPRS preferred').encode('utf8'),
                  _('3G preferred').encode('utf8')]

CONN_OPTS_DICT = {
   _('GPRS only').encode('utf8') : 'GPRSONLY',
   _('3G only').encode('utf8') : '3GONLY',
   _('GPRS preferred').encode('utf8') : 'GPRSPREF',
   _('3G preferred').encode('utf8') : '3GPREF'
}

CONN_OPTS_DICT_REV = dict_reverter(CONN_OPTS_DICT)

class Device(object):
    """I represent a device in the system"""
    __properties__ = {}
    __name__ = None
    conn_dict = None
    sconn = None
    baudrate = 115200
    
    def __init__(self):
        self.udi = None
        self.device_props = None
        self.cport = None
        self.dport = None
        
    def __eq__(self, element_dict):
        for k, v in self.__properties__.iteritems():
            try:
                if element_dict[k] != v:
                    return False
            except KeyError:
                return False
        
        self.udi = element_dict['info.udi']
        return True
    
    def _get_my_children(self, device_props):
        children = []
        for device in device_props:
            try:
                if device['info.parent'].startswith(self.udi):
                    children.append(device)
            except KeyError:
                pass
        
        return children
    
    def extract_info(self, children):
        for device in children:
            try:
                if device['serial.port'] == 2: # control port
                    self.cport = device['linux.device_file'].encode('utf8')
                elif device['serial.port'] == 0: # data port
                    self.dport = device['linux.device_file'].encode('utf8')
            except KeyError:
                pass
        
        if not self.cport or not self.dport:
            raise ex.DeviceLacksExtractInfo
    
    def setup(self, device_props):
        children = self._get_my_children(device_props)
        self.extract_info(children)

class HuaweiE620(Device):
    __properties__ = {
          'usb_device.vendor_id': 0x12D1,
          'usb_device.product_id': 0x1001,
      }
    __name__ = "Huawei E620"
    conn_dict = HUAWEI_DICT

class HuaweiE220(Device):
    __properties__ = {
          'usb_device.vendor_id': 0x12D1,
          'usb_device.product_id': 0x1003,
      }
    __name__ = "Huawei E220"
    conn_dict = HUAWEI_DICT

class OptionGlobeTrotter3G(Device):
    __properties__ = {
          'pci.vendor_id' : 0x1931,
          'pci.product_id': 0x0C,
      }
    __name__ = "Option GlobeTrotter 3G+"
    conn_dict = OPTION_DICT

class Option3GDatacard(Device):
    __properties__ = {
          'usb_device.vendor_id' : 0xAF0,
          'usb_device.product_id': 0x5000,
      }
    __name__ = "Option 3G Datacard"
    conn_dict = OPTION_DICT
        
HARDWARE_DB = [
   HuaweiE620(),
   HuaweiE220(),
   OptionGlobeTrotter3G(),
   Option3GDatacard(),
]

class DbusComponent(object):
    def __init__(self):
        self.bus = dbus.SystemBus()
        self.obj = self.bus.get_object('org.freedesktop.Hal',
                                  '/org/freedesktop/Hal/Manager')
        self.manager = dbus.Interface(self.obj, 'org.freedesktop.Hal.Manager')

    def get_properties_from_udi(self, udi):
        obj = self.bus.get_object('org.freedesktop.Hal', udi)
        dev = dbus.Interface(obj, 'org.freedesktop.Hal.Device')
        return dev.GetAllProperties()
    
    def get_devices_properties(self):
        return [self.get_properties_from_udi(udi)
                    for udi in self.manager.GetAllDevices()]

class HardwareRegistry(DbusComponent):
    """Hardware Registry"""
        
    def get_3g_device(self):
        device_properties = self.get_devices_properties()
        for device in HARDWARE_DB:
            if device in device_properties:
                device.setup(device_properties)
                return device
        
        raise ex.DeviceNotFoundError

class DeviceListener(DbusComponent):
    
    def __init__(self, device):
        DbusComponent.__init__(self)
        self.device = device
        self.register_handlers()
    
    def register_handlers(self):
        self.manager.connect_to_signal('DeviceAdded',
                                       self.device_added_cb)
        self.manager.connect_to_signal('DeviceRemoved',
                                       self.device_removed_cb)
    def device_added_cb(self, udi):
        if self.device:
            return
        
        properties = self.get_devices_properties()
        for device in HARDWARE_DB:
            if device in properties:
                device.setup(properties)
                louie.send(utils.globals.SIG_DEVICE_ADDED, None, device)
                self.device = device
    
    def device_removed_cb(self, udi):
        if not self.device:
            return
        
        if self.device.udi == udi:
            louie.send(utils.globals.SIG_DEVICE_REMOVED, None)
            self.device = None
        