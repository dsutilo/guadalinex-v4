# Author:  Pablo Marti
# Copyright (C) 2006  Warp Networks S.L.
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License along
# with this program; if not, write to the Free Software Foundation, Inc.,
# 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
"""
Base classes for Controllers
"""

__version__ = "$Rev: 312 $"

TV_DICT = {0 : 'inbox_treeview', 1 : 'inbox_treeview', 2 : 'drafts_treeview',
           3 : 'sent_treeview', 4 : 'contacts_treeview'}

class Notifier(object):
    def __init__(self):
        self._notifications = []
    
    def hide_notifications(self):
        for notification in self._notifications:
            # TODO: check if this really raises an exception
            try:
                notification.close()
            except:
                pass
    
    def append_notification(self, notification):
        self._notifications.append(notification)

    