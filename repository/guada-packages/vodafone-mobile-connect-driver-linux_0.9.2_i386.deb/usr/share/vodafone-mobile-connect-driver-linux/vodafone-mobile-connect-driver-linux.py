#!/usr/bin/env python
# Author:  Pablo Marti
# Copyright (C) 2006  Warp Networks S.L.
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License along
# with this program; if not, write to the Free Software Foundation, Inc.,
# 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
"""Starts Vodafone Mobile Connect Driver Linux"""

from twisted.internet import gtk2reactor
gtk2reactor.install()
# python imports
import os
import sys
import re
# twisted imports
from twisted.internet import reactor, threads

__version__ = "$Rev: 323 $"

def check_dependencies():
    """checks that dependencies are satisfied"""
    try:
        import pygtk
        pygtk.require("2.0")
    except (ImportError, AssertionError):
        print "pygtk2 not found in sys.path"
        sys.exit(1)
        
    try:
        from twisted.copyright import version
        if [int(x) for x in re.search(r'^(\d+)\.(\d+)\.(\d+)',
                      version).groups()] < [ 2, 2, 0, ]:
            
            print "python-twisted module is too old, please upgrade"
            sys.exit(1)
        del version
    except ImportError:
        print "python-twisted module not present"
        sys.exit(1)
        
def setup_path():
    """Sets up the python include paths"""
    if sys.argv[0]:
        base_dir = os.path.dirname(os.path.abspath(sys.argv[0]))
        sys.path = [os.path.join(base_dir, "src")] + sys.path

def main():
    """main method"""
    
    # parse options
    from twisted.python import usage
    class Options(usage.Options):
        optFlags = [["debug", "d", "Set debug on"]]
    
    options = Options()
    try:
        options.parseOptions(sys.argv[1:])
    except usage.UsageError, errortext:
        print '%s: %s' % (sys.argv[0], errortext)
        print '%s: Try --help for usage details.' % (sys.argv[0])
        sys.exit(1)
    
    debug = False
    if options['debug']:
        debug = True
    
    import gnome
    # avoid gnome warnings
    gnome.init("Vodafone Mobile Connect Driver Linux", __version__)
    
    # VMC imports
    import common.exceptions as ex
    from common.device import DeviceManager
    
    dm = DeviceManager()
    
    # start splash
    from controllers.splash import SplashController
    from models.splash import SplashModel
    from views.splash import SplashView
    
    smodel = SplashModel()
    sctrl = SplashController(smodel)
    sview = SplashView(sctrl)
    sview.show()
    
    sview.set_fraction(.1)
    
    # check if this is the first time we run VMC
    from common.config import VMCConfig
    try:
        vomcfg = VMCConfig()
    except IOError: # First time
        import shutil
        import utils.globals
        import utils.utilities
        try:
            os.mkdir(utils.globals.VMC_HOME)
        except OSError:
            pass
        sview.set_text(_('Initial setup...'))
        sview.set_fraction(.2)
        utils.utilities.populate_networks_db()
        shutil.copy(utils.globals.CFGTEMPLATE, utils.globals.VMC_CFG)
        os.chmod(utils.globals.VMC_CFG, 0600)
        vomcfg = VMCConfig()
        
    def device_found(ignored):
        conn = vomcfg.get('connection', 'connection')
        if not conn:
            sview.set_text(_('Running hardware wizard...'))
            sview.set_fraction(.3)
            from controllers.initialconf import DeviceConfController
            from models.initialconf import DeviceConfModel
            from views.initialconf import DeviceConfView
            
            model = DeviceConfModel(dm.device)
            ctrl = DeviceConfController(model, sview)
            view = DeviceConfView(ctrl)
            view.run()
        
        from common.startup import hook_it_up, attach_serial_protocol
        sconn = attach_serial_protocol(dm.device, debug)[0]
        sconn.disable_echo()        
        
        d2 = sconn.check_pin()
        def check_pin_cb(result):
            resp = result[0].group('resp')
            sview.set_text(_('Authenticating...'))
            sview.set_fraction(.4)
            if resp == '+CPIN: READY':
                sview.set_text(_('Authentication not necessary!'))
                sview.set_fraction(.5)
                hook_it_up(sview, dm, sconn)
            
            elif resp == '+CPIN: SIM PIN':
                from controllers.pin import AskPINAndExecuteFuncController
                from models.pin import AskPINModel
                from views.pin import AskPINView
                
                model = AskPINModel(sconn)
                ctrl = AskPINAndExecuteFuncController(model)
                ctrl.set_callback(hook_it_up, sview, dm, sconn)
                def errback(): reactor.stop()
                ctrl.set_errback(errback)
                
                ctrl.set_mode('send_pin')
                view = AskPINView(ctrl)
                view.show()
            
            elif resp in '+CPIN: SIM PUK':
                from controllers.pin import AskPUKAndExecuteFuncController
                from views.pin import AskPUKView
                from models.pin import AskPINModel
                
                model = AskPINModel(sconn)
                ctrl = AskPUKAndExecuteFuncController(model)
                ctrl.set_callback(hook_it_up, sview, dm, sconn)
                ctrl.set_mode('send_puk')
                def errback(): reactor.stop()
                ctrl.set_errback(errback)
                view = AskPUKView(ctrl)
                view.show()
        
        def sim_busy_eb(failure):
            failure.trap(ex.CMEErrorSIMBusy, ex.CMEErrorSIMNotStarted,
                         ex.CMEErrorSIMFailure)
            def try_later():
                sconn.check_pin().addCallbacks(check_pin_cb, sim_busy_eb)
            
            reactor.callLater(6, try_later)
        
        d2.addCallbacks(check_pin_cb, sim_busy_eb)
                
    def error_callback(failure):
        from common.exceptions import DeviceNotFoundError
        failure.trap(DeviceNotFoundError)
        import utils.dialogs
        message = _("No 3G Device found")
        details = _(
"""
Please check that the card is properly connected and try again.
If the card is already connected: eject and insert it and try
again.
""")
        utils.dialogs.open_message_dialog(message, details)
        reactor.stop()
                
    d = threads.deferToThread(dm.get_3g_device)
    d.addCallback(device_found)
    d.addErrback(error_callback)
    
    reactor.run()
    
if __name__ == '__main__':
    # i10n and i18n stuff
    import gettext
    import locale
    locale.setlocale(locale.LC_ALL, '')
    gettext.install("VMC", None, unicode=1)
    # lets start the show
    check_dependencies()
    setup_path()
    main()
    