#!/bin/sh
"/usr/bin/synce-in-computer-folder" $1 &
disown
