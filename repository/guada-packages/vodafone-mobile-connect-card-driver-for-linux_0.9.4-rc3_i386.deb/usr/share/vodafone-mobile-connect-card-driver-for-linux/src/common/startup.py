# Author:  Pablo Marti
# Copyright (C) 2006  Warp Networks S.L.
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License along
# with this program; if not, write to the Free Software Foundation, Inc.,
# 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
"""
Stuff used at startup
"""
__version__ = "$Rev: 374 $"

# gnome imports
import gnome

# Twisted imports
from twisted.application.service import Service
from twisted.internet.serialport import SerialPort
from twisted.internet import reactor

# VMC imports
from common.protocol import SIMCardConnection
from common.middleware import SIMCardConnAdapter
import common.exceptions as ex
from common.config import VMCConfig
from common.hardware import DeviceListener
from common.shutdown import shutdown_core

from controllers.initialconf import DeviceConfController
from controllers.splash import SplashController
from controllers.pin import (AskPUKAndExecuteFuncController,
                             AskPINAndExecuteFuncController)
from views.pin import AskPUKView, AskPINView
from models.pin import AskPINModel
from models.initialconf import DeviceConfModel
from models.splash import SplashModel
from views.initialconf import DeviceConfView
from views.splash import SplashView

class StartupController(object):
    
    def __init__(self, device):
        self.device = device
        self.num_sim_failure_errors = 0
        self.sview = None
        self.dev_listener = None
        self.start_gui(device)

    def start_gui(self, device):
        """main method"""
        # avoid gnome warnings
        import utils.globals
        gnome.init(utils.globals.APP_LONG_NAME, __version__)
        self.dev_listener = DeviceListener(self.device)
        # start splash
        smodel = SplashModel()
        sctrl = SplashController(smodel)
        self.sview = SplashView(sctrl)
        
        self.sview.show()
        self.sview.set_fraction(.1)
        
        # check if this is the first time we run VMC
        try:
            vomcfg = VMCConfig()
        except IOError: # First time
            self.sview.set_text(_('Initial setup...'))
            self.sview.set_fraction(.1)
            
            import utils.utilities
            utils.utilities.initial_user_setup()
            
            vomcfg = VMCConfig()
        
        from common.wvdialprofile import link_configuration
        link_configuration()
        
        conn = vomcfg.get('connection', 'connection')
        if not conn: # the user never never ran the app
            if self.device:
                self.sview.set_text(_('Running hardware wizard...'))
                self.sview.set_fraction(.2)
                    
                model = DeviceConfModel(self.device)
                ctrl = DeviceConfController(model, self.sview)
                view = DeviceConfView(ctrl)
                view.run()
        
        self.sview.set_fraction(.3)     
        from common.startup import hook_it_up
        if self.device:
            self.check_pin()
        else: # no device
            hook_it_up(self.sview, self.dev_listener, self.device)
        
    def check_pin_cb(self, result):
        resp = result[0].group('resp')
        self.sview.set_fraction(.4)
        if resp == '+CPIN: READY':
            self.sview.set_text(_('Authentication not necessary!'))
            self.sview.set_fraction(.5)
            hook_it_up(self.sview, self.dev_listener, self.device)
                
        elif resp == '+CPIN: SIM PIN':
            model = AskPINModel(self.device)
            ctrl = AskPINAndExecuteFuncController(model)
            ctrl.set_callback(hook_it_up, self.sview, self.dev_listener, self.device)
            ctrl.set_errback(shutdown_core)
            ctrl.set_mode('send_pin')
            
            view = AskPINView(ctrl)
            view.show()
                    
        elif resp == '+CPIN: SIM PUK':
            model = AskPINModel(self.device)
            ctrl = AskPUKAndExecuteFuncController(model)
            ctrl.set_callback(hook_it_up, self.sview, self.dev_listener, self.device)
            ctrl.set_errback(shutdown_core)
            ctrl.set_mode('send_puk')
            
            view = AskPUKView(ctrl)
            view.show()

    def sim_no_present(self, failure):
        failure.trap(ex.CMEErrorSIMNotInserted)
        hook_it_up(self.sview, self.dev_listener, None)
                
    def sim_busy_eb(self, failure):
        failure.trap(ex.CMEErrorSIMBusy, ex.CMEErrorSIMNotStarted,
                     ex.CMEErrorSIMFailure)
        
        reactor.callLater(6, self.check_pin)
    
    def sim_failure_eb(self, failure):
        failure.trap(ex.CMEErrorSIMFailure)
        self.num_sim_failure_errors += 1
        if self.num_sim_failure_errors >= 3:
            hook_it_up(self.sview, self.dev_listener, None)
            return
        
        reactor.callLater(6, self.check_pin)
        
    def check_pin(self):
        self.sview.set_text(_('Authenticating...'))
        self.device.sconn.disable_echo()
        d = self.device.sconn.check_pin()
        d.addCallback(self.check_pin_cb)
        d.addErrback(self.sim_failure_eb)
        d.addErrback(self.sim_busy_eb)
        d.addErrback(self.sim_no_present)
    
class SerialService(Service):
    """
    I am a twistd Service that starts a GUI and hooks up a serial service
    """
    
    def __init__(self, device, debug):
        self.device = device
        self.debug = debug
    
    def startService(self):
        if self.device:
            sconn = SIMCardConnAdapter(self.device, self.debug)
            bdrate = self.device.baudrate
            cport = self.device.cport
            self.device.sconn = sconn
            SerialPort(sconn, cport, reactor, baudrate=bdrate)
        
        StartupController(self.device)
        
def attach_serial_protocol(device, debug=False, test=False):
    """
    Attachs the protocol to the reactor and returns the protocol's instance
    """
    if not test:
        sconn = SIMCardConnAdapter(device, debug)
    else:
        sconn = SIMCardConnection(device, debug)

    SerialPort(sconn, device.cport, reactor, baudrate=device.baudrate)
    return sconn

def hook_it_up(sview, device_listener, device=None):
    """Attachs comms core to GUI and presents main screen"""
    
    # get main screen up
    from models.application import ApplicationModel
    from views.application import ApplicationView
    from controllers.application import ApplicationController
            
    model = ApplicationModel(sview, device)
    ctrl = ApplicationController(model, device_listener)
    view = ApplicationView(ctrl)
    
    import louie
    from louie.plugin import TwistedDispatchPlugin
    louie.install_plugin(TwistedDispatchPlugin())

def create_service(device):
    debug = True
    return SerialService(device, debug)
    