/* This file is auto generated, version 2 */
/* SMP */
#define UTS_MACHINE "i386"
#define UTS_VERSION "#2 SMP Sun Apr 15 07:36:31 UTC 2007"
#define LINUX_COMPILE_TIME "07:36:31"
#define LINUX_COMPILE_BY "root"
#define LINUX_COMPILE_HOST "palmer"
#define LINUX_COMPILE_DOMAIN "buildd"
#define LINUX_COMPILER "gcc version 4.1.2 (Ubuntu 4.1.2-0ubuntu4)"
