# Author:  Pablo Marti
# Copyright (C) 2006  Warp Networks S.L.
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License along
# with this program; if not, write to the Free Software Foundation, Inc.,
# 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
"""Model for main application"""
__version__ = "$Rev: 312 $"

# python imports
import signal
import os

# twisted imports
from twisted.internet import defer, reactor, interfaces
from twisted.python.failure import Failure

# gtkmvc imports
from gtkmvc.model import Model

# VMC imports
from models.base import SerialConnectionDispatcher
from common.config import VMCConfig
import common.exceptions as ex
import utils.globals

class ApplicationModel(Model, SerialConnectionDispatcher):
    """Model for the main application"""
    
    __properties__ = {
          "connecting" : False,
          "internet_connected" : False,
          "usage_shown": False,
          "sms_shown" : True,
          "support_shown" : False
    }
    
    def __init__(self, sview, sconn):
        Model.__init__(self)
        SerialConnectionDispatcher.__init__(self, sconn)
        self.sview = sview
        self.iconn = None
        self.netspeed = None
        self.wvdial_conf_path = None
        self.config = VMCConfig()
        
    #----------------------------------------------#
    # CONNECTION/DISCONNECTION SERIAL/INTERNET     #
    #----------------------------------------------#
    
    def cleanup_reactor(self):
        self.sconn.transport.unregisterProducer()
        rem_selectables = reactor.removeAll()
        for sel in rem_selectables:
            if interfaces.IProcessTransport.providedBy(sel):
                sel.signalProcess('KILL')
        
    def connect_internet(self):
        """Starts wvdial in case it wasn't already started"""
        d = defer.Deferred()
        
        if self.connecting:
            return d.errback(Failure(ex.AlreadyConnecting))
    
        if self.internet_connected:
            return d.errback(Failure(ex.AlreadyConnected))
        
        self.setup_connection()
            
        from common.protocol import WVDialProtocol
        from twisted.python.procutils import which
        from common.config import get_wvdial_conf_file
        from common.netspeed import NetworkSpeed
            
        self.wvdial_conf_path = get_wvdial_conf_file(self.sconn.device.dport)
        wvdial_path = which('wvdial')[0]
            
        # cleanup just in case
        try:
            os.remove(utils.globals.VMC_DNS_LOCK)
        except:
            pass
            
        staticdns = self.config.getboolean('connection', 'staticdns')
        if staticdns:
            from utils.utilities import generate_vmc_dns_lock
            dns1 = self.config.get('connection', 'dns1')
            dns2 = self.config.get('connection', 'dns2')
            generate_vmc_dns_lock(dns1, dns2)
            
        args = [wvdial_path, '-C', self.wvdial_conf_path, 'connect']
            
        wvproto = WVDialProtocol(staticdns)
        self.netspeed = NetworkSpeed()
        def callback(ignored):
            self.internet_connected = True
            self.netspeed.start()
            d.callback('connected')
                
        wvproto.deferred.addCallback(callback)
        self.iconn = reactor.spawnProcess(wvproto, wvdial_path,
                                              args, env=None)
        return d
    
    def disconnect_internet(self):
        """Disconnects from the Internet and kills all related processes"""
        if self.internet_connected or self.connecting:
            try:
                self.netspeed.stop()
            except AssertionError:
                pass
            
            self.netspeed = None
            os.system("killall pppd")
            try: 
                os.kill(self.iconn.pid, signal.SIGKILL)
            except TypeError:
                # it can be safely ignored as it probably is that wvdial
                # died for some unknown reason, anyway for the sake of
                # being sure we will try to kill it again to avoid having
                # a zombie wvdial
                os.system("killall wvdial")
            
            # cleanup the created wvdial.conf and its dir
            try:
                path = os.path.dirname(self.wvdial_conf_path)
                os.remove(self.wvdial_conf_path)
                os.rmdir(path)
            except IOError:
                pass
            
            try:
                os.remove(utils.globals.VMC_DNS_LOCK)
            except:
                pass
            
            self.wvdial_conf_path = None
            self.internet_connected = False
            
    def disconnect_serial(self):
        self.cleanup_reactor()
        reactor.stop()
    
    def setup_connection(self):
        preferred = self.config.get('connection', 'connection')
        conn_str = self.sconn.device.conndict[preferred]
        d = self.send_conn_string(conn_str)
        def callback(resp):
            pass
        def errback(failure):
            print "FAILURE received setting up connection", failure
        
        d.addCallback(callback)
        d.addErrback(errback)
    
    #----------------------------------------------#
    # EXTRA FUNCTIONALITY                          #
    #----------------------------------------------#
    
    def set_splash_text(self, text):
        self.sview.set_text(text)
    
    def set_splash_fraction(self, fraction):
        self.sview.set_fraction(fraction)
    