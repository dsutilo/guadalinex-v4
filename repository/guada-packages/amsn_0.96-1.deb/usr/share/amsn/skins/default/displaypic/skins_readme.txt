When creating a new skin, replace only the loading.gif and nopic.gif files. The rest of files are supposed to be not skin-dependent. If you want us to ship some other display picture with amsn, just tell us, instead of including it in your skin.


