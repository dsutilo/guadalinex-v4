# Author:  Pablo Marti
# Copyright (C) 2006  Warp Networks S.L.
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License along
# with this program; if not, write to the Free Software Foundation, Inc.,
# 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
"""Controllers for both add_contact and search_contact dialogs"""
__version__ = "$Rev: 359 $"

# python imports
import os

# gtk imports
import gtk

# gtkmvc imports
from gtkmvc import Controller

# VMC imports
import utils.globals
import common.exceptions as ex
from common.persistent import ContactsManager, Contact
from models.contacts import ContactsStoreModel

MOBILE_IMG = gtk.gdk.pixbuf_new_from_file(
              os.path.join(utils.globals.IMAGES_DIR, 'mobile.png'))
COMPUTER_IMG = gtk.gdk.pixbuf_new_from_file(
              os.path.join(utils.globals.IMAGES_DIR, 'computer.png'))

class AddContactController(Controller):
    """Controller for the add contact dialog"""
    
    def __init__(self, model, parent_ctrl):
        Controller.__init__(self, model)
        self.parent_ctrl = parent_ctrl
    
    def register_view(self, view):
        Controller.register_view(self, view)
        if not self.model.device:
            self.view['mobile_radio_button'].set_sensitive(False)
            self.view['computer_radio_button'].set_active(True)
    
    def on_add_contact_ok_button_clicked(self, widget):
        # get data from GUI
        name = self.view['add_contact_name_entry'].get_text()
        number = self.view['add_contact_number_entry'].get_text().strip()
        save_in_sim = self.view['mobile_radio_button'].get_active()
        # check if the number is valid
        from utils.utilities import is_valid_number
        if not is_valid_number(number):
            self.view['add_contact_number_entry'].select_region(0, -1)
            self.view['add_contact_number_entry'].grab_focus()
            return
        
        # utf8-name
        name = unicode(name, 'utf8')
        
        # create contact object
        contact = Contact(name, number)
        if save_in_sim:
            d = self.parent_ctrl.model.add_contact(contact)
            def callback(index):
                # add it to the treeview model
                model = self.parent_ctrl.view['contacts_treeview'].get_model()
                contact.index = int(index)
                model.add_contact(contact)
                self._hide_me()
            
            def errback(failure):
                failure.trap(ex.CMEErrorInvalidCharactersInDialString)
                
            d.addCallback(callback)
            d.addErrback(errback)
        else:
            # add it to the contacts database
            manager = ContactsManager()
            def callback(index):
                # add it to the treeview model
                model = self.parent_ctrl.view['contacts_treeview'].get_model()
                contact.index = int(index)
                model.add_contact(contact)
                manager.close()
                self._hide_me()
                
            d = manager.insert_contact(contact)
            d.addCallback(callback)
    
    def on_add_contact_cancel_button_clicked(self, widget):
        self._hide_me()
    
    def _hide_me(self):
        self.view.hide()
        self.model.unregister_observer(self)

class SearchContactController(Controller):
    """Controller for the search contact interface"""
    
    def __init__(self, model, parent_ctrl):
        Controller.__init__(self, model)
        self.parent_ctrl = parent_ctrl
    
    def on_search_cancel_button_clicked(self, widget):
        pass
    
    def on_search_find_button_clicked(self, widget):
        pattern = self.view['search_entry'].get_text()
        # contacts from sim
        d = self.parent_ctrl.model.find_contact(pattern)
        def callback(simresult):
            # contacts from SIM
            result = []
            if simresult:
                if len(simresult) == 1:
                    result.append(list(simresult[0].groups()))
                else:
                    result = [list(result.groups()) for result in simresult]
            # contacts from DB    
            mana = ContactsManager()
            d = mana.find_contacts(pattern)
            def callback2(theresult):
                self.find_contacts_in_db(pattern, theresult, result)
                mana.close()
                
            d.addCallback(callback2)
        def errback(failure):
            # contacts from DB    
            mana = ContactsManager()
            d = mana.find_contacts(pattern)
            def callback2(theresult):
                self.find_contacts_in_db(pattern, theresult, [])
                mana.close()
                
            d.addCallback(callback2)
            
        d.addCallback(callback)
        d.addErrback(errback)
    
    def find_contacts_in_db(self, pattern, theresult, current_result):
        if theresult:
            for r in theresult:
                current_result.append(list(r))
        if not current_result:
            utils.dialogs.open_message_dialog(_('No contact found'),
                  _('No contact with the name %s found') % pattern)
            return
            
        treeview = self.parent_ctrl.view['contacts_treeview']
        model = treeview.get_model()
        contact_ids = [str(contact[0]) for contact in current_result]
        cont = 0
        path = []
        for row in model:
            if row[3] in contact_ids: # contact id
                path.append(str(cont))
            cont = cont + 1
        
        sel = treeview.get_selection()
        sel.unselect_all()
        for elem in path:
            sel.select_path(elem)

class ContactsListController(Controller):
    """Controller for the contacts list"""
    
    def __init__(self, model, parent_ctrl):
        Controller.__init__(self, model)
        self.parent_ctrl = parent_ctrl
    
    def register_view(self, view):
        Controller.register_view(self, view)
        self._position_and_show()
        self._setup_view()
        self._fill_treeview()
    
    def _position_and_show(self):
        window = self.view.get_top_widget()
        parent_window = self.parent_ctrl.view.get_top_widget()
        width, height = parent_window.get_size()
        x, y = parent_window.get_position()
        reqx = x + width + 10
        window.move(reqx, y)
        
        self.view.show()
    
    def _setup_view(self):
        # setup treeview
        treeview = self.view['treeview1']
        COL_TYPE, COL_NAME, COL_NUMBER, COL_ID = range(4)
        model = ContactsStoreModel()
        treeview.set_model(model)
        treeview.get_selection().set_mode(gtk.SELECTION_MULTIPLE)
        
        treeview.connect('row-activated', self._row_activated_handler)
        
        cell = gtk.CellRendererPixbuf()
        column = gtk.TreeViewColumn(_("Type"))
        column.pack_start(cell)
        column.set_attributes(cell, pixbuf = COL_TYPE)
        treeview.append_column(column)
        
        cell = gtk.CellRendererText()
        column = gtk.TreeViewColumn(_("Name"), cell, text=COL_NAME)
        column.set_resizable(True)
        column.set_sort_column_id(COL_NAME)
        cell.set_property('editable', False)
        treeview.append_column(column)
        
        cell = gtk.CellRendererText()
        column = gtk.TreeViewColumn(_("Number"), cell, text=COL_NUMBER)
        column.set_resizable(True)
        column.set_sort_column_id(COL_NUMBER)
        cell.set_property('editable', False)
        treeview.append_column(column)
        
        cell = gtk.CellRendererText()
        column = gtk.TreeViewColumn("IntId", cell, text=COL_ID)
        column.set_visible(False)
        column.set_sort_column_id(COL_ID)
        treeview.append_column(column)
        
        # make add contact insensitive until a row has been selected
        self.view['add_button'].set_sensitive(False)
    
    def _fill_treeview(self):
        _model = self.view['treeview1'].get_model()
        d = self.parent_ctrl.parent_ctrl.model.get_all_contacts()
        def callback(contacts):
            _model.add_contacts(contacts)
            # fill contacts from hard drive
            manager = ContactsManager()
            d = manager.read_contacts()
            def callback2(contacts):
                _model.add_contacts(contacts)
                manager.close()
            
            d.addCallback(callback2)
            
        d.addCallback(callback)
    
    def _row_activated_handler(self, treeview, path, col):
        model, selected = treeview.get_selection().get_selected_rows()
        if not selected or len(selected) > 1:
            return
        
        _iter = model.get_iter(selected[0])
        number = model.get_value(_iter, 2)
        current_numbers = self.parent_ctrl.get_numbers_list()
        self.parent_ctrl.set_entry_text('')
        if not current_numbers:
            self.parent_ctrl.set_entry_text(number)
        else:
            current_numbers.append(number)
            self.parent_ctrl.set_entry_text(','.join(current_numbers))
        
        self.model.unregister_observer(self)
        self.view.hide()
        
    def on_add_button_clicked(self, widget):
        treeview = self.view['treeview1']
        # get selected rows
        selection = treeview.get_selection()
        model, selected = selection.get_selected_rows()
        iters = [model.get_iter(path) for path in selected]
        numbers = []
        for _iter in iters:
            numbers.append(model.get_value(_iter, 2)) # 2 == number in model
        # set the text in the parent's text entry
        numberstext = ','.join(numbers)
        self.parent_ctrl.set_entry_text(numberstext)
        self.model.unregister_observer(self)
        self.view.hide()
    
    def on_cancel_button_clicked(self, widget):
        self.model.unregister_observer(self)
        self.view.hide()
    
    def on_treeview1_cursor_changed(self, treeview):
        model, selected = treeview.get_selection().get_selected_rows()
        if len(selected):
            self.view['add_button'].set_sensitive(True)
        