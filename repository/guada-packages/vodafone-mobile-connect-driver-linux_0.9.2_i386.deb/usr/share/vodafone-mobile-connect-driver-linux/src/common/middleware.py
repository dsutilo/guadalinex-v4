# Author:  Pablo Marti
# Copyright (C) 2006  Warp Networks S.L.
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License along
# with this program; if not, write to the Free Software Foundation, Inc.,
# 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
"""
Wrapper around common.SIMCardConnection

It basically provides error control and more high-level operations
"""

__version__ = "$Rev: 299 $"

# twisted imports
from twisted.internet import reactor, defer
# VMC imports
from common.protocol import SIMCardConnection
import common.exceptions as ex
from common.persistent import Contact
from common.sms.sms import pdu_to_message

class SIMCardConnAdapter(SIMCardConnection):
    
    def get_all_contacts(self):
        """Returns a list with all the contacts in the SIM"""
        def get_em(auxdefer=None):
            if auxdefer:
                d2 = auxdefer
            else:
                d2 = defer.Deferred()
            
            d = SIMCardConnection._get_all_contacts(self)
            def callback(contacts):
                clist = []
                for contact in contacts:
                    name = unicode(contact.group('name'), 'utf8')
                    clist.append(Contact(name,
                                         contact.group('number'),
                                         int(contact.group('id'))))
                
                d2.callback(clist)
            
            def no_contacts_eb(failure):
                failure.trap(ex.CMEErrorNotFound, ex.ATError)
                d2.callback([])
            
            def sim_busy_eb(failure):
                failure.trap(ex.CMEErrorSIMBusy, ex.CMEErrorSIMNotStarted)
                # This basically is a loop that will be repeated until we get
                # a response. The reason is that some times the card will
                # reply with a SIM BUSY error or similar while trying to read
                # the contacts/messages, this is buggy and needs to be handled
                reactor.callLater(2, get_em, d2)
            
            d.addCallback(callback)
            d.addErrback(no_contacts_eb)
            d.addErrback(sim_busy_eb)
        
            return d2
        
        return get_em()
    
    def get_all_sms(self):
        """
        Returns a list of ShortMessage objects with all the SMS in the SIM card
        """
        def get_em(auxdefer=None):
            if auxdefer:
                d2 = auxdefer
            else:
                d2 = defer.Deferred()
            
            d = SIMCardConnection.get_all_sms(self)
            def callback(messages):
                mlist = []
                for rawsms in messages:
                    # ShortMessage obj
                    sms = pdu_to_message(rawsms.group('pdu'))
                    sms.index = int(rawsms.group('id'))
                    sms.where = int(rawsms.group('storedat'))
                    mlist.append(sms)
                
                d2.callback(mlist)
            
            def error_sim_eb(failure):
                failure.trap(ex.CMEErrorNotFound, ex.ATError)
                d2.callback([])
            
            def sms_sim_busy_eb(failure):
                failure.trap(ex.CMEErrorSIMBusy,
                             ex.CMEErrorSIMNotStarted, ex.CMSError500)
                reactor.callLater(2, get_em, d2)
            
            d.addCallback(callback)
            d.addErrback(error_sim_eb)
            d.addErrback(sms_sim_busy_eb)
            
            return d2
        
        return get_em()
    
    def get_phonebook_size(self):
        """Returns the phonebook size of the SIM card"""
        def get_it(auxdefer=None):
            if auxdefer:
                d2 = auxdefer
            else:
                d2 = defer.Deferred()
            
            d = SIMCardConnection.get_phonebook_size(self)
            def callback(resp):
                size = int(resp[0].group('size'))
                d2.callback(size)
            
            def errback(failure):
                failure.trap(ex.ATError, ex.CMEErrorSIMBusy, ex.CMSError500)
                reactor.callLater(2, get_it, d2)
                
            d.addCallback(callback)
            d.addErrback(errback)
            return d2
        
        return get_it()
    
    def get_pin_status(self):
        """Returns 1 if PIN authentication is set, 0 otherwise"""
        def get_it(auxdefer=None):
            if not auxdefer:
                d2 = defer.Deferred()
            else:
                d2 = auxdefer
            
            d = SIMCardConnection._get_pin_status(self)
            
            def callback(resp):
                active = int(resp[0].group('status'))
                d2.callback(active)
                
            def busy_errback(failure):
                failure.trap(ex.CMEErrorSIMBusy, ex.CMEErrorSIMNotStarted)
                reactor.callLater(2, get_it, d2)
            
            def pinreq_errback(failure):
                failure.trap(ex.CMEErrorSIMPINRequired)
                d2.callback(1)
                
            d.addCallback(callback)
            d.addErrback(pinreq_errback)
            d.addErrback(busy_errback)
            
            return d2
        
        return get_it()
    
    def get_sms(self, index):
        d2 = defer.Deferred()
        d = SIMCardConnection.get_sms(self, index)
        def callback(rawsms):
            rawsms = rawsms[0]
            sms = pdu_to_message(rawsms.group('pdu'))
            sms.index = index
            sms.where = int(rawsms.group('storedat'))
            
            d2.callback(sms)
        d.addCallback(callback)
        return d2
    