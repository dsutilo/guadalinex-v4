# -*- coding: utf-8 -*-
# Copyright (C) 2006-2007  Vodafone España, S.A.
# Author:  Pablo Martí
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License along
# with this program; if not, write to the Free Software Foundation, Inc.,
# 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
"""Unittests for the SIM card

You need to be authenticated before running the test suite
"""

__version__ = "$Rev: 406 $"

from twisted.internet import defer
from twisted.trial import unittest
# fix path stuff
import sys
sys.path = ['/home/huno/vmc/src'] + sys.path

from common.hardware import HardwareRegistry
from common.persistent import Contact
import common.exceptions as ex

class TestSIMCard(unittest.TestCase):
    """Test for SIM card functionality"""
    
    def _start_protocol(self):
        hw = HardwareRegistry()
        device = hw.get_3g_device()
        from common.startup import attach_serial_protocol
        self.sconn = attach_serial_protocol(device, False, True)
    
    def setUpClass(self):
        self.sconn = None
        self.serial = None
        self._start_protocol()
    
    def tearDownClass(self):
        self.sconn.transport.unregisterProducer()
        from twisted.internet import reactor, interfaces
        rem_selectables = reactor.removeAll()
        for sel in rem_selectables:
            if interfaces.IProcessTransport.providedBy(sel):
                    sel.signalProcess('KILL')
    
    def test_a_delete_all_sms(self):
        d = self.sconn.delete_all_sms()
        d.addCallback(lambda val: self.assertEqual(val, True))
        return d
    
    def test_b_delete_all_contacts(self):
        d = self.sconn.delete_all_contacts()
        d.addCallback(lambda val: self.assertEqual(val, True))
        def errback(failure):
            self.failUnless(failure.type == ex.CMEErrorNotFound)
        d.addErrback(errback)
        return d
    
    def test_c_add_contact1(self):
        from common.persistent import Contact
        contact = Contact(u"Vodafone", "+34670979779")
        d = self.sconn.add_contact(contact)
        d.addCallback(lambda val: self.assertEqual(val, 1))
        return d
    
    def test_d_add_contact2(self):
        contact = Contact(u"Mery", "+34673423421")
        d = self.sconn.add_contact(contact)
        d.addCallback(lambda val: self.assertEqual(val, 2))
        return d
    
    def test_e__get_all_contacts(self):
        d = self.sconn._get_all_contacts()
        def callback(contacts):
            clist = []
            for contact in contacts:
                name = unicode(contact.group('name'), 'utf8')
                clist.append(Contact(name, contact.group('number')))
            
            self.assertEqual(clist[0], Contact(u"Vodafone", "+34670979779"))
            self.assertEqual(clist[1], Contact(u"Mery", "+34673423421"))
        
        d.addCallback(callback)
        return d
    
    def test_f_find_contact(self):
        d = self.sconn.find_contact('Vodafone')
        def callback(resp):
            resp = resp[0]
            index = int(resp.group('id'))
            number = resp.group('number')
            name = unicode(resp.group('name'), 'utf8')
            self.assertEqual(Contact(u"Vodafone", "+34670979779", 1),
                             Contact(name, number, index))
        
        d.addCallback(callback)
        return d
    
    def test_g_delete_contact(self):
        d = self.sconn.delete_contact(2)
        def callback(resp):
            self.sconn.get_used_contact_ids().addCallback(
                  lambda val: self.assertEqual(val, [1]))
        d.addCallback(callback)
        return d
    
    def test_h_get_network_names(self):
        d = self.sconn.get_network_names()
        resp = '(1,"vodafone ES","voda ES","21401",0),(2,"vodafone ES","voda ES","21401",2),(1,"movistar","movistar","21407",0),(1,"Retevision Movil","AMENA","21403",0),(1,"movistar","movistar","21407",2),(1,"Retevision Movil","AMENA","21403",2)'
        d.addCallback(lambda val: self.assertEqual(val[0].group(), resp))
        return d
    
    