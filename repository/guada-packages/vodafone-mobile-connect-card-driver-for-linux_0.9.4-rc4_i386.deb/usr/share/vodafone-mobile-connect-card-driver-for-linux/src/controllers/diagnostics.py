# -*- coding: utf-8 -*-
# Copyright (C) 2006-2007  Vodafone España, S.A.
# Author:  Pablo Martí
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License along
# with this program; if not, write to the Free Software Foundation, Inc.,
# 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
"""
Controller for the diagnostics window
"""
__version__ = "$Rev: 406 $"

# gtkmvc imports
from gtkmvc import Controller

class DiagnosticsController(Controller):
    """Controller for the diagnostics window"""
    
    def __init__(self, model):
        Controller.__init__(self, model)
    
    def register_view(self, view):
        """
        Fill the label fields of the diagnostics dialog
        
        This will be called once the view is registered
        """
        Controller.register_view(self, view)
        if self.model.device:
            self.set_sim_info()
        
        self.model.get_uptime().addCallback(lambda x:
                self.view['uptime_number_label'].set_text(x))
        
        self.view['os_name_label'].set_text(self.model.get_os_name())
        self.view['os_version_label'].set_text(self.model.get_os_version())
    
    def set_sim_info(self):
        d = self.model.get_imei_number()
        d.addCallback(lambda x: self.view['imei_number_label'].set_text(x))
        d2 = self.model.get_imsi_number()
        d2.addCallback(lambda x: self.view['imsi_number_label'].set_text(x))
        d3 = self.model.get_card_version()
        d3.addCallback(lambda x: self.view['firmware_label'].set_text(x))
        d4 = self.model.get_card_model()
        d4.addCallback(lambda x: self.view['card_model_label'].set_text(x))
    
    # ------------------------------------------------------------ #
    #                       Signals Handling                       #
    # ------------------------------------------------------------ #
    
    def on_internet_button_clicked(self, widget):
        print "Internet button clicked"
    
    def on_modems_button_clicked(self, widget):
        print "Modems button clicked"
    
    def on_system_button_clicked(self, widget):
        print "System button clicked"
    
    def on_network_button_clicked(self, widget):
        print "network button clicked"
    
    def on_reboot_button_clicked(self, widget):
        print "reboot button clicked"
    
    def on_moreinfo_button_clicked(self, widget):
        print "more info button clicked"
    
    def on_close_button_clicked(self, widget):
        self.model.unregister_observer(self)
        