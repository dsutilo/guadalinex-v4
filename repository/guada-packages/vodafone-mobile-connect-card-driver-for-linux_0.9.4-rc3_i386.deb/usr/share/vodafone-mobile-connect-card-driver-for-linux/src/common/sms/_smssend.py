# -*- coding: utf-8 -*-
# The contents of this file are subject to the Mozilla Public License
# Version 1.1 (the "License"); you may not use this file except in
# compliance with the License. You may obtain a copy of the License at
# http://www.mozilla.org/MPL/ 
# Software distributed under the License is distributed on an "AS IS"
# basis, WITHOUT WARRANTY OF ANY KIND, either express or implied. See
# the License for the specific language governing rights and
# limitations under the License.
#
# The Original Code is Vivesto Solutions code. 
# The Initial Developer of the Original Code is Viveto Solutions.
# Portions created by the Initial Developer are Copyright (C) 2003 the
# Initial Developer. All Rights Reserved.
#
# The format of the SMS TPDU is described in GSM 03.40

# Modified by Pablo Marti at Warp Networks S.L.
# Original name was SMSSubmit.py

def int2hexstr(i):
    """int2hexstr(11) => '0B'"""
    return '%02X' % i
        
def swap(s):
    """
    Convert a string of numbers into the semi-octet representation
    described in GSM 03.40, 9.1.2.3"""
    r = ''
    if len(s) % 2 == 1:
        s = s + 'F'

    for i in range(0, len(s), 2):
        r += s[i+1]
        r += s[i]

    return r

def canonicalize_number(s):
    """
    Strips out all non-numeric characters from a string except
    for a single leading '+' character, which is used to indicate
    an international number."""

    if s.startswith('+'):
        r = "+"
    else:
        r = ""

    for c in s:
        if c.isdigit():
            r += c
    return r

def pack_7bit_bytes(s):
    """pack_7bit_bytes("hellohello") => "E8329BFD4697D9EC37"

    Packs a series of 7-bit bytes into 8-bit bytes and then to
    ASCII strings as hexidecimal. See GSM 03.40, 9.1.2.1"""
    
    out = ''
    for i in range(0, len(s)):
        if i % 8 == 7:
            continue
        
        end = ord(s[i]) >> (i % 8)

        if i + 1 < len(s):        
            start = ord(s[i+1])  << (7 - (i % 8))
            start = start & 0xFF
            out += int2hexstr(start | end)
        else:
            out += int2hexstr(end)

    return out

def pack_8bit_bytes(s):
    return "".join([int2hexstr(ord(c)) for c in s])
        
class Callable:
    """A simple helper for creating class methods"""
    def __init__(self, anycallable):
        self.__call__ = anycallable

class TypeOfNumber:
    UNKNOWN = 0
    INTERNATIONAL = 1
    NATIONAL = 2
    
    def bit_pattern(typ):
        return typ            
    bit_pattern = Callable(bit_pattern)
    
class NumberingPlan:
    UNKNOWN = 0
    ISDNORTELEPHONE = 1

    def bit_pattern(plan):
        return plan            
    bit_pattern = Callable(bit_pattern)
    
class Address:
    def __init__(self, number):
        number = canonicalize_number(number)
        if number.startswith('+'):
            self.number = number[1:]
            self.type_of_number = TypeOfNumber.INTERNATIONAL
        else:
            self.number = number
            self.type_of_number = TypeOfNumber.UNKNOWN
        
        self.numbering_plan_identification = NumberingPlan.ISDNORTELEPHONE

    def serialize(self, stream):
        stream.write(int2hexstr(len(self.number)))

        # GSM 03.40, section 9.1.2.5
        header = 0x80

        header = header | (TypeOfNumber.bit_pattern(self.type_of_number) << 4)
        header = header | NumberingPlan.bit_pattern(
                                        self.numbering_plan_identification)
        
        stream.write(int2hexstr(header))

        stream.write(swap(self.number))


def clean_text(text):
    """Temporary workaround while we solve the encoding issues"""
    return text.replace('á', 'a').replace('é', 'e')\
                .replace('í', 'i').replace('ó', 'o').replace('ú', 'u')

class SMSSubmitPDU:
    def __init__(self, number, message):
        self.address = Address(number)
        self.message = clean_text(message)
        self.include_user_data_header = False
        self.user_data = ""
        try:        
            sms_text = self.message.encode('sms-default')
            self.user_data_length = len(self.message.encode('sms-default'))
        except UnicodeError, e:
            # Should try to encode as UCS-2
            raise Exception(_('only characters part of the SMS default alphabet are supported'))
        else:            
            if len(sms_text) > 160:
                raise Exception(_('SMS messages can have a maximum length of 160 characters'))
        
            self.user_data = pack_7bit_bytes(sms_text)

    def serialize_dcs(self, stream):
        # GSM 03.38, section 4

        dcs = 0        

        # Bits 3 and 2 indicate the alphabet being used

        if 1:
            dcs = dcs | 0x00 # 7Bit
        else:
            dcs = dcs | 0x08 # UCS-2

        stream.write(int2hexstr(dcs))

    def serialize(self, stream):
        header = 0
        
        # TP-Message-Type-Indicator = 01
        header = header | 0x01

        # TP-Reject-Duplicates = 0

        # TP-Validity-Period-Format = 00 (TP-VP field not present)

        # TP-Status-Report-Request = 0

        # TP-User-Data-Header-Indicator

        if self.include_user_data_header:
            header = header | 0x40

        # TP-Reply-Path = 0

        stream.write(int2hexstr(header))

        # TP-Message-Reference = 0

        stream.write(int2hexstr(0))
        
        # TP-Destination-Address

        self.address.serialize(stream)

        # TP-Protocol-Identifier

        stream.write("00")

        # TP-Data-Coding-Scheme

        self.serialize_dcs(stream)

        # TP-Validity-Period (skipped)
        
        # TP-User-Data-Length

        stream.write(int2hexstr(self.user_data_length))
        
        # TP-User-Data        

        stream.write(self.user_data)
