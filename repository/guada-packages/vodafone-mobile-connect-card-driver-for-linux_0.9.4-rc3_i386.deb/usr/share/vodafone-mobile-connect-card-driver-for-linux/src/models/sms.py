# Author:  Pablo Marti
# Copyright (C) 2006  Warp Networks S.L.
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License along
# with this program; if not, write to the Free Software Foundation, Inc.,
# 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

__version__ = "$Rev: 359 $"

# python imports
import os

# gtk imports
import gtk
import gobject

# twisted imports
from twisted.internet import defer

# gtkmvc imports
from gtkmvc import ListStoreModel, Model

# VMC imports
import utils.globals
from common.persistent import SMSManager
MOBILE_IMG = gtk.gdk.pixbuf_new_from_file(
              os.path.join(utils.globals.IMAGES_DIR, 'mobile.png'))
COMPUTER_IMG = gtk.gdk.pixbuf_new_from_file(
              os.path.join(utils.globals.IMAGES_DIR, 'computer.png'))

class NewSmsModel(Model):
    __properties__ = {}
    
    def __init__(self):
        Model.__init__(self)
    
    def save_sms_to_db(self, smslist, where):
        d2 = defer.Deferred()
        manager = SMSManager()
        def closeit(smslistback):
            d2.callback(smslistback)
            manager.close()
        
        d = manager.insert_messages(smslist, where)
        d.addCallback(closeit)
        return d2

class SMSStoreModel(ListStoreModel):
    
    def __init__(self):
        ListStoreModel.__init__(self, gtk.gdk.Pixbuf,
                    gobject.TYPE_STRING, gobject.TYPE_STRING,
                    gobject.TYPE_STRING, gobject.TYPE_STRING)
    
    def add_messages(self, messages):
        for sms in messages:
            self.add_message(sms)
    
    def add_message(self, message):
        entry = []
        if message.index < 1000:
            entry.append(MOBILE_IMG)
        else:
            entry.append(COMPUTER_IMG)
        
        entry.append(message.text)
        entry.append(message.number)
        entry.append(message.get_localised_date())
        entry.append(str(message.index))
        
        self.append(entry)
        