# Author:  Pablo Marti
# Copyright (C) 2006  Warp Networks S.L.
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License along
# with this program; if not, write to the Free Software Foundation, Inc.,
# 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
"""Controllers for the sms dialogs"""
__version__ = "$Rev: 359 $"

# python imports
import os
import datetime
import time

# gtk imports
import gtk

# gtkmvc imports
from gtkmvc import Controller

# twisted imports
from twisted.internet.defer import DeferredList

# VMC imports
from common.sms.sms import ShortMessage
from controllers.base import TV_DICT
import utils.globals
import utils.dialogs

MOBILE_IMG = gtk.gdk.pixbuf_new_from_file(
          os.path.join(utils.globals.IMAGES_DIR, 'mobile.png'))
COMPUTER_IMG = gtk.gdk.pixbuf_new_from_file(
              os.path.join(utils.globals.IMAGES_DIR, 'computer.png'))

class NewSmsController(Controller):
    """Controller for the new sms dialog"""
    
    def __init__(self, model, parent_ctrl = None):
        Controller.__init__(self, model)
        self.parent_ctrl = parent_ctrl
    
    def register_view(self, view):
        Controller.register_view(self, view)
        # center on parent screen
        window = view.get_top_widget()
        window.set_transient_for(self.parent_ctrl.view.get_top_widget())
        window.set_position(gtk.WIN_POS_CENTER_ON_PARENT)
        # signals stuff
        self.view['bottom_label'].set_text(_('0/160 chars'))
        textbuffer = self.view['sms_edit_text_view'].get_buffer()
        textbuffer.connect('changed', self._textbuffer_changed)
        # show the view
        view.show()
        self.view['recipients_entry'].grab_focus()
    
    def on_send_button_clicked(self, widget):
        # check that is a valid number
        from utils.utilities import is_valid_number
        numbers = self.get_numbers_list()
        for number in numbers:
            if not is_valid_number(number):
                self.view['recipients_entry'].select_region(0, -1)
                self.view['recipients_entry'].grab_focus()
                return
        
        messages = self.get_messages_list()
        if not messages:
            return
        
        message_text = self.get_message_text()
        if not message_text:
            resp = utils.dialogs.open_warning_request_cancel_ok(
                        _("Send empty message"),
                        _("Are you sure you want to send an empty message?"))
            if not resp: # guy said no
                return
        
        # get the date localised
        date = time.strftime("%c", datetime.datetime.now().timetuple())
        # send the sms
        notifications = []
        smslist = []
        for sms in messages:
            d = self.parent_ctrl.model.send_sms(sms)
            notifications.append(d)
            smslist.append(sms)
            self.view['sms_progressbar'].set_fraction(
                                  len(smslist) / len(messages))
        
        def list_cb(resp):
            self.save_messages_to_db(smslist, where=3)
            self.model.unregister_observer(self)
            self.view.hide()
        
        dlist = DeferredList(notifications)
        dlist.addCallback(list_cb)
        
    def on_save_button_clicked(self, widget):
        # get number list and text
        messages = self.get_messages_list()
        if not messages:
            return
        
        self.save_messages_to_db(messages)
        
        self.model.unregister_observer(self)
        self.view.hide()
    
    def on_cancel_button_clicked(self, widget):
        self.model.unregister_observer(self)
        self.view.hide()
    
    def on_contacts_button_clicked(self, widget):
        from controllers.contacts import ContactsListController
        from views.contacts import ContactsListView
        from gtkmvc.model import Model
        
        ctrl = ContactsListController(Model(), self)
        view = ContactsListView(ctrl)
        resp = view.run()
    
    def _textbuffer_changed(self, textbuffer):
        """Handler for the textbuffer changed signal"""
        charcount = textbuffer.get_char_count()
        if charcount > 160:
            start, end = textbuffer.get_bounds()
            message_text = textbuffer.get_text(start, end)
            textbuffer.set_text(message_text[:160])
            charcount = 160
        self.view['bottom_label'].set_text(_('%d/160 chars') % charcount)
    
    def get_message_text(self):
        """Returns the text written by the user in the textview"""
        textbuffer = self.view['sms_edit_text_view'].get_buffer()
        bounds = textbuffer.get_bounds()
        return textbuffer.get_text(bounds[0], bounds[1])
    
    def get_numbers_list(self):
        """Returns a list with all the numbers in the recipients_entry"""
        numbers_text = self.view['recipients_entry'].get_text()
        numbers = numbers_text.split(',')
        if numbers[0] == '':
            return None
        
        return numbers
        
    def get_messages_list(self):
        """Returns a list with all the messages to send/save"""
        # get number list and text
        numbers = self.get_numbers_list()
        if not numbers:
            return None
        
        message_text = self.get_message_text()
        message_text = unicode(message_text, 'utf8')
        
        return [ShortMessage(number, message_text,
                    datetime=datetime.datetime.now()) for number in numbers]
    
    def set_entry_text(self, text):
        self.view['recipients_entry'].set_text(text)
    
    def save_messages_to_db(self, smslist, where=2):
        now = datetime.datetime.now()
        def callback(smslistback):
            tv_name = TV_DICT[where]
            model = self.parent_ctrl.view[tv_name].get_model()
            model.add_messages(smslistback)
        
        d = self.model.save_sms_to_db(smslist, where)
        d.addCallback(callback)

class ForwardSmsController(NewSmsController):
    """Controller for ForwardSms"""
    
    def __init__(self, model, parent_ctrl):
        NewSmsController.__init__(self, model, parent_ctrl)
    
    def set_recipient_numbers(self, text):
        self.view['recipients_entry'].set_text(text)
    
    def set_textbuffer_text(self, text):
        textbuffer = self.view['sms_edit_text_view'].get_buffer()
        textbuffer.set_text(text)
        