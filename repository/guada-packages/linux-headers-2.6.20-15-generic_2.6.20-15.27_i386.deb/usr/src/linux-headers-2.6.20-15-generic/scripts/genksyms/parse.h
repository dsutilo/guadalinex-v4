/* A Bison parser, made by GNU Bison 2.0.  */

/* Skeleton parser for Yacc-like parsing with Bison,
   Copyright (C) 1984, 1989, 1990, 2000, 2001, 2002, 2003, 2004 Free Software Foundation, Inc.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330,
   Boston, MA 02111-1307, USA.  */

/* As a special exception, when this file is copied by Bison into a
   Bison output file, you may use that output file without restriction.
   This special exception was added by the Free Software Foundation
   in version 1.24 of Bison.  */

/* Tokens.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
   /* Put the tokens into the symbol table, so that GDB and other debuggers
      know about them.  */
   enum yytokentype {
     ASM_KEYW = 258,
     ATTRIBUTE_KEYW = 259,
     AUTO_KEYW = 260,
     BOOL_KEYW = 261,
     CHAR_KEYW = 262,
     CONST_KEYW = 263,
     DOUBLE_KEYW = 264,
     ENUM_KEYW = 265,
     EXTERN_KEYW = 266,
     FLOAT_KEYW = 267,
     INLINE_KEYW = 268,
     INT_KEYW = 269,
     LONG_KEYW = 270,
     REGISTER_KEYW = 271,
     RESTRICT_KEYW = 272,
     SHORT_KEYW = 273,
     SIGNED_KEYW = 274,
     STATIC_KEYW = 275,
     STRUCT_KEYW = 276,
     TYPEDEF_KEYW = 277,
     UNION_KEYW = 278,
     UNSIGNED_KEYW = 279,
     VOID_KEYW = 280,
     VOLATILE_KEYW = 281,
     TYPEOF_KEYW = 282,
     EXPORT_SYMBOL_KEYW = 283,
     ASM_PHRASE = 284,
     ATTRIBUTE_PHRASE = 285,
     BRACE_PHRASE = 286,
     BRACKET_PHRASE = 287,
     EXPRESSION_PHRASE = 288,
     CHAR = 289,
     DOTS = 290,
     IDENT = 291,
     INT = 292,
     REAL = 293,
     STRING = 294,
     TYPE = 295,
     OTHER = 296,
     FILENAME = 297
   };
#endif
#define ASM_KEYW 258
#define ATTRIBUTE_KEYW 259
#define AUTO_KEYW 260
#define BOOL_KEYW 261
#define CHAR_KEYW 262
#define CONST_KEYW 263
#define DOUBLE_KEYW 264
#define ENUM_KEYW 265
#define EXTERN_KEYW 266
#define FLOAT_KEYW 267
#define INLINE_KEYW 268
#define INT_KEYW 269
#define LONG_KEYW 270
#define REGISTER_KEYW 271
#define RESTRICT_KEYW 272
#define SHORT_KEYW 273
#define SIGNED_KEYW 274
#define STATIC_KEYW 275
#define STRUCT_KEYW 276
#define TYPEDEF_KEYW 277
#define UNION_KEYW 278
#define UNSIGNED_KEYW 279
#define VOID_KEYW 280
#define VOLATILE_KEYW 281
#define TYPEOF_KEYW 282
#define EXPORT_SYMBOL_KEYW 283
#define ASM_PHRASE 284
#define ATTRIBUTE_PHRASE 285
#define BRACE_PHRASE 286
#define BRACKET_PHRASE 287
#define EXPRESSION_PHRASE 288
#define CHAR 289
#define DOTS 290
#define IDENT 291
#define INT 292
#define REAL 293
#define STRING 294
#define TYPE 295
#define OTHER 296
#define FILENAME 297




#if ! defined (YYSTYPE) && ! defined (YYSTYPE_IS_DECLARED)
typedef int YYSTYPE;
# define yystype YYSTYPE /* obsolescent; will be withdrawn */
# define YYSTYPE_IS_DECLARED 1
# define YYSTYPE_IS_TRIVIAL 1
#endif

extern YYSTYPE yylval;



