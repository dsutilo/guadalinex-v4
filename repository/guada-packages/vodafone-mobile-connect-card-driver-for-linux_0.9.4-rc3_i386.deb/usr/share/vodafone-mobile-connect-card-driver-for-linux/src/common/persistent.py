# Author:  Pablo Marti
# Copyright (C) 2006  Warp Networks S.L.
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License along
# with this program; if not, write to the Free Software Foundation, Inc.,
# 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
"""
SQLite stuff
"""
__version__ = "$Rev: 357 $"

# python imports
import time
import datetime
# pysqlite imports
from pysqlite2 import dbapi2 as sqlite
# twisted imports
from twisted.internet import defer
from twisted.enterprise import adbapi
# VMC imports
from common.sms.sms import ShortMessage
import utils.globals

class Contact(object):
    """I represent a contact in VMC"""
    def __init__(self, name, number, index=None):
        assert isinstance(name, unicode)
        self.name = name
        self.number = number
        self.index = index
        self.category = self.number.startswith('+') and '145' or '129'
    
    def __cmp__(self, contact):
        return cmp(self.name, contact.name) | \
               cmp(self.number, contact.number) | \
               cmp(self.index, contact.index)
    
    def to_csv(self):
        """Returns a list with the name and number formatted for csv"""
        name = '"' + self.name + '"'
        number = '"' + self.number + '"'
        return [name, number]

class DBManager(object):
    """Base class for the {Contacts,SMS}Manager"""
    CREATEDB_STRING = ""
    
    def __init__(self, path=None):
        self.path = path
        self.pool = None
        self.__connect_to_db()
    
    def __connect_to_db(self):
        conn = sqlite.connect(self.path)
        conn.row_factory = sqlite.Row
        cur = conn.cursor()
        try:
            cur.execute(self.CREATEDB_STRING)
            conn.commit()
        except sqlite.DatabaseError:
            pass
        
        self.pool = adbapi.ConnectionPool('pysqlite2.dbapi2',
                          self.path, isolation_level=None)
    
    def close(self):
        self.pool.close()
    
class ContactsManager(DBManager):
    CREATEDB_STRING = """
    create table contacts
    (id integer, category integer, name text, number text);
    """
    
    def __init__(self, path=utils.globals.CONTACTS_DB):
        DBManager.__init__(self, path)
    
    def delete_ids(self, cids):
        """Deletes the given ids from the DB"""
        def interaction(txn, contacts):
            for id_ in contacts:
                txn.execute('delete from contacts where id = ?', (id_,))  
        
        return self.pool.runInteraction(interaction, cids)
    
    def update_contact(self, contact):
        def interaction(txn):
            sql_str = \
                'update contacts set category=?, name=?, number=? where id=?;'
            txn.execute(sql_str, (contact.category, contact.name,
                                  contact.number, contact.index))
            return True
        
        return self.pool.runInteraction(interaction)
    
    def insert_contact(self, contact):
        """Inserts a contact in the DB and returns its index"""
        def interaction(txn):
            txn.execute('SELECT MAX(id) from contacts;')
            resp = txn.fetchall()
            if resp:
                maxid = resp[0][0]
                
            if maxid is None:
                maxid = 1000
            else:
                maxid = int(maxid) + 1
            txn.execute("""INSERT INTO contacts(id, category, name, number)
                values (?, ?, ?, ?);""",
                (maxid, contact.category, contact.name, contact.number,))
            
            return maxid
        
        return self.pool.runInteraction(interaction)
    
    def find_contacts(self, pattern):
        """
        Returns a list of tuples with the contacts whom name match pattern
        """
        def interaction(txn):
            txn.execute(
                "select * from contacts where name LIKE '%%%s%%'" % pattern)
            resp = txn.fetchall()
            return resp
        
        return self.pool.runInteraction(interaction)
    
    def read_contacts(self):
        """Returns a list of tuples with the contacts stored in the DB"""
        def interaction(txn):
            rows = txn.execute("select * from contacts;")
            contacts = []
            for row in rows:
                contact = Contact(row[2], row[3])
                contact.index = row[0]
                contacts.append(contact)
            
            return contacts
        
        return self.pool.runInteraction(interaction)

class SMSManager(DBManager):
    CREATEDB_STRING = """
    create table messages
    (id integer, category integer, number text, date text, smstext text);
    """
    
    def __init__(self, path=utils.globals.MESSAGES_DB):
        DBManager.__init__(self, path)
    
    def delete_ids(self, mids):
        """Deletes the given ids from the DB"""
        def interaction(txn, messages):
            for id_ in messages:
                txn.execute('delete from messages where id = ?', (id_,))  
        
        return self.pool.runInteraction(interaction, mids)
    
    def insert_messages(self, smslist, where):
        responses = []
        d2 = defer.Deferred()
        for sms in smslist:
            d = self.insert_message(sms, where)
            def callback(message):
                responses.append(message)
                if len(responses) == len(smslist):
                    d2.callback(responses)
            
            d.addCallback(callback)
        
        return d2
    
    def insert_message(self, sms, where):
        """
        Inserts a message into DB and returns the index where has been stored
        """
        def interaction(txn):
            txn.execute('SELECT MAX(id) from messages;')
            resp = txn.fetchall()
            if resp:
                maxid = resp[0][0]
                
            if maxid is None:
                maxid = 1000
            else:
                maxid = int(maxid) + 1
            
            sms.index = maxid
                
            if sms.datetime:
                timerecv = time.mktime(sms.datetime.timetuple())
            else:
                timerecv = time.time()
            
            txn.execute("""
                INSERT INTO messages (id, category, number, date, smstext)
                values (?, ?, ?, ?, ?);""",
                (sms.index, int(where), sms.number, timerecv, sms.text,))
            
            return sms
        return self.pool.runInteraction(interaction)
    
    def read_messages(self):
        """Returns a list of tuples with the messages in the DB"""
        def interaction(txn):
            rows = txn.execute("select * from messages;")
            messages = []
            for row in rows:
                sms = ShortMessage(row[2], row[4])
                timerecv = float(row[3])
                sms.datetime = datetime.datetime.fromtimestamp(timerecv)
                sms.index = row[0]
                sms.where = int(row[1])
                messages.append(sms)
            
            return messages
        
        return self.pool.runInteraction(interaction)

class NetworksManager(DBManager):
    CREATEDB_STRING = """create table networks
    (id integer, name text, country text);"""
    
    def __init__(self, path=utils.globals.NETWORKS_DB):
        DBManager.__init__(self, path)
    
    def populate_db(self, an_iter):
        def interaction(txn, theiter):
            txn.executemany("""insert into networks (id, name, country)
values (?, ?, ?);""", theiter)
            return True
        
        return self.pool.runInteraction(interaction, an_iter)
    
    def lookup_network(self, netid):
        def interaction(txn):
            txn.execute('select name, country from networks where id=?;', \
                         (netid,))
            return txn.fetchone()
        
        return self.pool.runInteraction(interaction)
        