# -*- coding: utf-8 -*-
# Copyright (C) 2006-2007  Vodafone España, S.A.
# Author:  Pablo Martí
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License along
# with this program; if not, write to the Free Software Foundation, Inc.,
# 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
"""
I manage wvdial's profiles

To sum up, I'm a big ugly hack needed to overcome a wvdial/pppd deficiency.

According to wvdial(1):
 /etc/ppp/peers/wvdial
     Required for correct authentication in pppd version 2.3.0 or newer.

Wvdial reads the authentication details from that file and only that file.
This is obviously not good in a multi-user environment, and we are left with
no choice but simlinking dynamically /etc/ppp/peers/wvdial to the given custom
config file. This is hacky and not really desirable, but we gotta stick to
this solution until we find a better one.
"""
__version__ = "$Rev: 406 $"

# python imports
import os
import errno

# VMC imports
import utils.globals
from common.config import VMCConfig
from utils.utilities import dict_reverter
import common.exceptions as ex

DEFAULT_CONF = {
    _('default') : 'default',
    _('only-pap') : 'only-pap',
    _('only-chap') : 'only-chap',
}

DEFAULT_CONF_REV = dict_reverter(DEFAULT_CONF)

class WvdialProfile(object):
    """I represent a custom wvdial profile"""
    def __init__(self, path):
        self.path = path
        self.name = os.path.basename(path)

def get_custom_profiles_list():
    """
    Returns a list with all profiles in $VMC_CFG/wvdial-configs
    """    
    return [WvdialProfile(path)
            for path in os.listdir(utils.globals.WVDIAL_PROFILES)]
    
def force_symlink(src, dst):
    """
    Creates a symlink between C{src} and C{dst}
    
    If C{dst} exists, it will be deleted.
    """
    try:
        os.symlink(src, dst)
    except OSError, e:
        if e.errno == errno.EEXIST:
            os.unlink(dst)
            os.symlink(src, dst)
        else:
            print "OSERROR", e
    
    except IOError, e:
        print "IOERROR", e

def link_configuration():
    conf = VMCConfig()
    custom = conf.getboolean('connection', 'use_custom_wvdial_profile')
    profile = custom and conf.get('connection',
                                  'wvdial_profile_name') or 'default'
    
    profile_path = os.path.join(utils.globals.WVDIAL_PROFILES, profile)
    
    force_symlink(profile_path, utils.globals.WVDIAL_AUTH_CONF)

def delete_profile(profile):
    """
    Deletes the given profile
    """
    if not os.path.exists(profile.path):
        raise ex.ProfileNotFoundError
    
    try:
        os.unlink(profile.path)
    except (OSError, IOError):
        raise

def get_profile_from_name(name):
    path = os.path.join(utils.globals.WVDIAL_PROFILES, name)
    return os.path.exists(path) and WvdialProfile(path) or None
    