# Author:  Pablo Marti
# Copyright (C) 2006  Warp Networks S.L.
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License along
# with this program; if not, write to the Free Software Foundation, Inc.,
# 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
"""Unittests for the csv module"""

__version__ = "$Rev: 363 $"

# fix path stuff
import sys
sys.path = ['/home/huno/vmc/src'] + sys.path

import os
from common.csvutils import CSVUnicodeWriter, CSVUnicodeReader

TMPFILE = 'test.csv'

class TestCSVUtils:
    """Test for csvutils functionality"""
    
    def test_get_rows(self):
        fobj = open('/home/huno/vmc/tests/contacts.csv')
        reader = CSVUnicodeReader(fobj)
        resp = reader.get_rows()
        
        assert resp == [[u'John', u'+3532344333'],
                        [u'Peter', u'+345465454'],
                        [u'Lucy', u'+4464576556']]
    
    def test_write_row(self):
        writer = CSVUnicodeWriter(open(TMPFILE, 'w'))
        row = [u'Pabl\0231', u'+345667781']
        writer.write_row(row)
        
        reader = CSVUnicodeReader(open(TMPFILE))
        resp = reader.get_rows()
        assert resp == [row]
        os.unlink(TMPFILE)
    
    def test_write_rows(self):
        writer = CSVUnicodeWriter(open(TMPFILE, 'w'))
        rows = [[u'Pablo', u'+345667781'],
                [u'Xabïé', u'+347327211'],
                [u'Raúls', u'+349494949'],
                [u'María', u'+312232111'],
                [u'André', u'+378544522']]
        
        writer.write_rows(rows)
        
        reader = CSVUnicodeReader(open(TMPFILE))
        resp = reader.get_rows()
        assert resp == rows
        os.unlink(TMPFILE)
        