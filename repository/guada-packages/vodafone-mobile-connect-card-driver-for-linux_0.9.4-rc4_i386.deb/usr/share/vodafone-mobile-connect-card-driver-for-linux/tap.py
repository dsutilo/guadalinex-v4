#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Copyright (C) 2006-2007  Vodafone España, S.A.
# Author:  Pablo Martí
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License along
# with this program; if not, write to the Free Software Foundation, Inc.,
# 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
"""
Starts Vodafone Mobile Connect driver for Linux

execute it with:  twistd -r gtk2 -noy tap.py
"""

# python imports
import os
import sys
import re
import signal
import gettext
import locale

# twisted imports
from twisted.internet import reactor
from twisted.application.service import Application

__version__ = "$Rev: 406 $"

# i10n and i18n stuff
locale.setlocale(locale.LC_ALL, '')
gettext.install("VMC", None, unicode=1)

def check_dependencies():
    """checks that dependencies are satisfied"""
    try:
        import pygtk
        pygtk.require("2.0")
    except (ImportError, AssertionError):
        print "pygtk2 not found in sys.path"
        sys.exit(1)
        
    try:
        from twisted.copyright import version
        if [int(x) for x in re.search(r'^(\d+)\.(\d+)\.(\d+)',
                      version).groups()] < [ 2, 2, 0, ]:
            
            print "python-twisted module is too old, please upgrade"
            sys.exit(1)
        del version
    except ImportError:
        print "python-twisted module not present"
        sys.exit(1)
    
check_dependencies()

def setup_path():
    """Sets up the python include paths"""
    base_dir = os.path.dirname(os.path.abspath(__file__))
    sys.path = [os.path.join(base_dir, "src")] + sys.path

setup_path()
# lets start the show

import utils.globals

def get_device():
    # VMC imports
    from common.exceptions import DeviceNotFoundError, DeviceLacksExtractInfo
    from common.hardware import HardwareRegistry
    
    hw_reg = HardwareRegistry()
    
    try:
        device = hw_reg.get_3g_device()
    except DeviceNotFoundError:
        device = None
        
    return device

device = get_device()

def install_signal_handler():
    from common.shutdown import shutdown_core
    signal.signal(signal.SIGINT, shutdown_core)

install_signal_handler()

from common.startup import create_service
service = create_service(device)
application = Application(utils.globals.APP_SHORT_NAME)
service.setServiceParent(application)
