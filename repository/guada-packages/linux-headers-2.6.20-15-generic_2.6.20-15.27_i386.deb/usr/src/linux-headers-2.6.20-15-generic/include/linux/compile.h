/* This file is auto generated, version 1 */
/* SMP */
#define UTS_MACHINE "i386"
#define UTS_VERSION "#1 SMP Tue Jun 19 13:53:04 UTC 2007"
#define LINUX_COMPILE_TIME "13:53:04"
#define LINUX_COMPILE_BY "root"
#define LINUX_COMPILE_HOST "ggv4-desktop"
#define LINUX_COMPILE_DOMAIN ""
#define LINUX_COMPILER "gcc version 4.1.2 20060928 (prerelease) (Ubuntu 4.1.1-13ubuntu5)"
