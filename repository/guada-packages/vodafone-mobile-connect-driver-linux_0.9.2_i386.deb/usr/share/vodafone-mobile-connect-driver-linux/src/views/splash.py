# Author:  Pablo Marti
# Copyright (C) 2006  Warp Networks S.L.
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License along
# with this program; if not, write to the Free Software Foundation, Inc.,
# 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
"""View for the splash screen"""
__version__ = "$Rev: 226 $"

# python imports
import os.path
# gtkmvc imports
from gtkmvc.view import View
# VMC imports
import utils.globals

class SplashView(View):
    """View for the splash screen"""
    
    GLADE_FILE = os.path.join(utils.globals.GLADE_DIR, 'splash.glade')
    
    def __init__(self, ctrl):
        View.__init__(self, ctrl, self.GLADE_FILE, 'splash_window',
                      register=False, domain="VMC")
        self.setup_view()
        ctrl.register_view(self)
        
    def setup_view(self):
        self['splash_image'].set_from_file(
                       os.path.join(utils.globals.IMAGES_DIR, "splash.png"))
    
    def set_fraction(self, fraction):
        """Sets the given fraction in the progress bar"""
        self['splash_progress_bar'].set_fraction(fraction)
        
    def set_text(self, text):
        """Sets the given text in the progress bar"""
        self['splash_progress_bar'].set_text(text)
