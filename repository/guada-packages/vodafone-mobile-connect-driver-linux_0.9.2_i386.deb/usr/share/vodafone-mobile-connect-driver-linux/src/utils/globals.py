# Author:  Pablo Marti
# Copyright (C) 2006  Warp Networks S.L.
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License along
# with this program; if not, write to the Free Software Foundation, Inc.,
# 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
"""
VMC's global variables
"""
__version__ = "$Rev: 262 $"

# python imports
import os.path
import sys

if sys.argv[0] == '/usr/bin/py.test': # TODO: remove me
    TOP_DIR = '/home/huno/vmc'
if sys.argv[0]:
    TOP_DIR = os.path.dirname(os.path.abspath(sys.argv[0]))
else:
    TOP_DIR = "."

RESOURCES_DIR = os.path.join(TOP_DIR, 'resources')
GLADE_DIR = os.path.join(RESOURCES_DIR, 'glade')
IMAGES_DIR = os.path.join(RESOURCES_DIR, 'glade') #TODO: fix this mess
TEMPLATES_DIR = os.path.join(RESOURCES_DIR, 'templates')
HELP_DIR = os.path.join(RESOURCES_DIR, 'help')
EXTRA_DIR = os.path.join(RESOURCES_DIR, 'extra')

NETWORKS_CSV = os.path.join(EXTRA_DIR, 'networks.csv')

WVTEMPLATE = os.path.join(TEMPLATES_DIR, 'wvdial.conf.tpl')
CFGTEMPLATE = os.path.join(TEMPLATES_DIR, 'vmc.cfg.tpl')

USER_HOME = os.path.expanduser('~')
VMC_HOME = os.path.join(USER_HOME, '.vmc')
VMC_CFG = os.path.join(VMC_HOME, 'vmc.cfg')

# databases, they could be merged in the future
CONTACTS_DB = os.path.join(VMC_HOME, 'contacts.db')
MESSAGES_DB = os.path.join(VMC_HOME, 'messages.db')
NETWORKS_DB = os.path.join(VMC_HOME, 'networks.db')

# static dns stuff

VMC_DNS_LOCK = os.path.join('/tmp', 'vmc-conn.lock')

# SIGNALS
SIG_SMSRECV = 'sms_recv'
SIG_TIMEOUT = 'timeout'
SIG_SPEEDLINK = 'speed'
SIG_INVALID_DNS = 'invalid_dns'
SIG_CONNECTED = 'connected'
SIG_DISCONNECTED = 'disconnected'
SIG_DEVICE_REMOVED = 'removed'
