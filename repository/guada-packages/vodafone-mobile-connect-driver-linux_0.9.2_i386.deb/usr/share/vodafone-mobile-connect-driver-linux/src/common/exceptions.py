# Author:  Pablo Marti
# Copyright (C) 2006  Warp Networks S.L.
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License along
# with this program; if not, write to the Free Software Foundation, Inc.,
# 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

__version__ = "$Rev: 294 $"

class AlreadyConnected(Exception):
    """
    Raised when the user tries to connect to Internet and is already connected
    """

class AlreadyConnecting(Exception):
    """
    Raised when the user tries to connect to Internet and is in the middle of
    the process of connecting
    """

class ATError(Exception):
    """Exception raised when an ERROR has occurred"""

class CMEError(Exception):
    """Exception raised when a CME ERROR has occurred"""

class CMEErrorIncorrectPassword(CMEError):
    """Exception raised with a +CME ERROR: incorrect password"""

class CMEErrorInvalidCharactersInDialString(CMEError):
    """
    Exception raised with a +CME ERROR: invalid characters in dial string
    """

class CMEErrorNotFound(CMEError):
    """Exception raised with a +CME ERROR: not found"""
    
class CMEErrorOperationNotAllowed(CMEError):
    """Exception raised with a +CME ERROR: operation not allowed"""

class CMEErrorSIMBusy(CMEError):
    """Exception raised with a +CME ERROR: SIM busy"""

class CMEErrorSIMFailure(CMEError):
    """Exception raised with a +CME ERROR: SIM failure"""

class CMEErrorSIMNotStarted(CMEError):
    """Exception raised with +CME ERROR: SIM interface not started"""

class CMEErrorSIMPINRequired(CMEError):
    """Exception raised with +CME ERROR: SIM PIN required"""

class CMEErrorSIMPUKRequired(CMEError):
    """Exception raised with +CME ERROR: SIM PUK required"""

class CMEErrorSIMPUK2Required(CMEError):
    """Exception raised with +CME ERROR: SIM PUK2 required"""

class CMSError(Exception):
    """Base class for CMS errors"""

class CMSError300(CMSError):
    """CMS ERROR: Phone failure"""

class CMSError301(CMSError):
    """CMS ERROR: SMS service of phone reserved """

class CMSError302(CMSError):
    """CMS ERROR: Operation not allowed"""

class CMSError303(CMSError):
    """CMS ERROR: Operation not supported"""

class CMSError304(CMSError):
    """CMS ERROR: Invalid PDU mode parameter"""

class CMSError305(CMSError):
    """CMS ERROR: Invalid text mode parameter"""

class CMSError310(CMSError):
    """CMS ERROR: SIM not inserted"""

class CMSError311(CMSError):
    """CMS ERROR: SIM PIN necessary"""

class CMSError313(CMSError):
    """CMS ERROR: SIM failure"""

class CMSError314(CMSError):
    """CMS ERROR: SIM busy"""

class CMSError315(CMSError):
    """CMS ERROR: SIM wrong"""

class CMSError320(CMSError):
    """CMS ERROR: Memory failure"""

class CMSError321(CMSError):
    """CMS ERROR: Invalid memory index"""

class CMSError322(CMSError):
    """CMS ERROR: Memory full"""

class CMSError330(CMSError):
    """CMS ERROR: SMSC address unknown"""

class CMSError331(CMSError):
    """CMS ERROR: No network service"""

class CMSError332(CMSError):
    """CMS ERROR: Network timeout"""
    
class CMSError500(CMSError):
    """CMS ERROR: Unknown Error"""
    
class DeviceNotFoundError(Exception):
    """Exception raised when no suitable device has been found"""

class InputValueError(Exception):
    """Exception raised when INPUT VALUE IS OUT OF RANGE is received"""
