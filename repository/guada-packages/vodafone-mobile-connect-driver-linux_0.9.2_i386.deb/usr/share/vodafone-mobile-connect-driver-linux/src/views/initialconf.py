# Author:  Pablo Marti
# Copyright (C) 2006  Warp Networks S.L.
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License along
# with this program; if not, write to the Free Software Foundation, Inc.,
# 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
"""View for the initial config dialog"""
__version__ = "$Rev: 195 $"

# python imports
import os.path
import utils.globals
# gtkmvc imports
from gtkmvc.view import View

class InitialConfView(View):
    """View for the initial config dialog"""
    
    GLADE_FILE = os.path.join(utils.globals.GLADE_DIR, "config.glade")
    
    def __init__(self, ctrl):
        View.__init__(self, ctrl, self.GLADE_FILE,
                      'config_dialog', register=False, domain="VMC")
        self.setup_view()
        ctrl.register_view(self)
    
    def setup_view(self):
        pass
    
    def run(self):
        widget = self.get_top_widget()
        res = widget.run()
        widget.destroy()
        return res

class DeviceConfView(View):
    """View for the initial config dialog"""
    
    GLADE_FILE = os.path.join(utils.globals.GLADE_DIR, "config.glade")
    
    def __init__(self, ctrl):
        View.__init__(self, ctrl, self.GLADE_FILE,
                      'new_card_dialog', register=False, domain="VMC")
        ctrl.register_view(self)
        self.ctrl = ctrl
        self.setup_view()
    
    def setup_view(self):
        device = self.ctrl.model.device
        self['card_model_entry'].set_text(device.description)
        self['card_model_entry'].set_editable(False)
        self.populate_combobox()
    
    def run(self):
        widget = self.get_top_widget()
        resp = widget.run()
        widget.destroy()
        return resp
    
    def populate_combobox(self):
        import gobject
        import gtk
        model = gtk.ListStore(gobject.TYPE_STRING)
        from common.device import CONN_OPTS_LIST as options
 
        [model.append([opt]) for opt in options]
        self['conn_combobox'].set_model(model)
        self['conn_combobox'].set_active(len(options) - 1)
        