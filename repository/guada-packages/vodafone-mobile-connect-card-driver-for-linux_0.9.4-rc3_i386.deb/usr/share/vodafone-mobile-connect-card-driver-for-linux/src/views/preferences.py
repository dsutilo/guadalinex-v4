# Author:  Pablo Marti
# Copyright (C) 2006  Warp Networks S.L.
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License along
# with this program; if not, write to the Free Software Foundation, Inc.,
# 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
"""View for the preferences window"""
__version__ = "$Rev: 377 $"

# python imports
import os.path
import utils.globals

# gtk imports
import gobject
import gtk

# gtkmvc imports
from gtkmvc import View

# VMC imports
from common.config import VMCConfig

class PreferencesView(View):
    """View for the preferences window"""
    
    GLADE_FILE = os.path.join(utils.globals.GLADE_DIR, "preferences.glade")
    
    def __init__(self, ctrl, device):
        View.__init__(self, ctrl, self.GLADE_FILE, 'preferences_window',
                      register=False, domain="VMC")
        self.device = device
        self.initial_option = None
        self.setup_view()
        ctrl.register_view(self)
    
    def setup_view(self):
        conf = VMCConfig()
        
        # get values
        username = conf.get('connection', 'username')
        password = conf.get('connection', 'password')
        apn = conf.get('connection', 'apn')
        conn = conf.get('connection', 'connection')
        
        # populate entries
        self['username_entry'].set_text(username)
        self['password_entry'].set_text(password)
        self['apn_entry'].set_text(apn)
        
        # setup conn_combobox
        self.setup_conn_comobobox(conn)
        
        # name server stuff
        static = conf.getboolean('connection', 'staticdns')
        dns1 = conf.get('connection', 'dns1')
        dns2 = conf.get('connection', 'dns2')
        self['dns1_entry'].set_text(dns1)
        self['dns2_entry'].set_text(dns2)
        if not static:
            self['checkbutton'].set_active(False)
            self['dns1_entry'].set_sensitive(False)
            self['dns2_entry'].set_sensitive(False)
        else:
            self['checkbutton'].set_active(True)
        
        # second page of the notebook
        
        custom = conf.getboolean('connection', 'use_custom_wvdial_profile')
        self['frame19'].set_sensitive(custom)
        self['custom_profile_checkbutton'].set_active(custom)
        #setup wvdial_combobox
        self.setup_wvdial_combobox()
    
    def setup_conn_comobobox(self, conn):
        model = self.get_conn_combobox_model()
        self['connection_combobox'].set_model(model)
        # select current preferred connection
        from common.hardware import CONN_OPTS_DICT_REV
        name = CONN_OPTS_DICT_REV[conn]
        self.select_conn_combobox_option(model, name)
        
    def get_conn_combobox_model(self):
        from common.hardware import CONN_OPTS_LIST
        model = gtk.ListStore(gobject.TYPE_STRING)
        [model.append([opt]) for opt in CONN_OPTS_LIST]
        
        return model
        
    def select_conn_combobox_option(self, model, option):
        cont = 0
        for row in model:
            if row[0] == option:
                self['connection_combobox'].set_active(cont)
                self.initial_option == option
                break
            
            cont += 1
    
    # second notebook page
    
    def setup_wvdial_combobox(self):        
        model = self.get_wvdial_combobox_model()
        self['wvdial_profiles_combobox'].set_model(model)
        
        conf = VMCConfig()
        custom = conf.getboolean('connection', 'use_custom_wvdial_profile')
        if custom:
            wvdial_profile = conf.get('connection', 'wvdial_profile_name')
            if not wvdial_profile:
                wvdial_profile = _('default')
            self.select_wvdial_combobox_option(model, wvdial_profile)
        else:
            self.select_wvdial_combobox_option(model, _('default'))
        
    def get_wvdial_combobox_model(self):
        from common.wvdialprofile import get_custom_profiles_list
        model = gtk.ListStore(gobject.TYPE_STRING)
        [model.append([prof.name]) for prof in get_custom_profiles_list()]
        
        return model
    
    def select_wvdial_combobox_option(self, model, profile):
        cont = 0
        for row in model:
            if row[0] == profile:
                self['wvdial_profiles_combobox'].set_active(cont)
                return
            
            cont += 1

class ProfileEditorView(View):
    """View for the profiles' editor"""
    
    GLADE_FILE = os.path.join(utils.globals.GLADE_DIR, "preferences.glade")
    
    def __init__(self, ctrl):
        View.__init__(self, ctrl, self.GLADE_FILE, 'profile_edit_window',
                      register=True, domain="VMC")
    
    def set_edit_view(self):
        self.get_top_widget().set_title(_("Edit profile"))
    
    def set_new_view(self):
        self.get_top_widget().set_title(_("New profile"))
    