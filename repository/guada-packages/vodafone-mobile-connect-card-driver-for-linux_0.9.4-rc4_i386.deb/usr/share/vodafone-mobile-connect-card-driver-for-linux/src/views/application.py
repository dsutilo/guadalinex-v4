# -*- coding: utf-8 -*-
# Copyright (C) 2006-2007  Vodafone España, S.A.
# Author:  Pablo Martí
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License along
# with this program; if not, write to the Free Software Foundation, Inc.,
# 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

__version__ = "$Rev: 406 $"

# python imports
import os.path
import utils.globals

# gtk imports
import gtk

# gtkmvc imports
from gtkmvc import View

# VMC imports
from controllers.base import TV_DICT
from views.base import BaseDialogView
from models.sms import SMSStoreModel
from models.contacts import ContactsStoreModel

WIDGETS_TO_HIDE = ['connect_button', 'connect1',
                   'change_pin1_menu_item', 'request_pin1',
                   'import_contacts1', 'export_contacts1', 'new_menu_item',
                   'new_sms_menu_item', 'contact1', 'reply_sms_menu_item',
                   'reply_sms_menu', 'forward_sms_menu_item',
                   'imagemenuitem3', 'preferences_menu_item']

class ApplicationView(View):
    """Main view for application"""
    GLADE_FILE = os.path.join(utils.globals.GLADE_DIR, "VMC.glade")
    
    def __init__(self, ctrl):
        View.__init__(self, ctrl, self.GLADE_FILE,
                      'main_window', register=False, domain="VMC")
        ctrl.register_view(self)
        self.setup_view()
        self.throbber = None
    
    def setup_view(self):
        self.set_name()
    
    def set_name(self, name=utils.globals.APP_LONG_NAME):
        self.get_top_widget().set_title(name)
    
    def set_disconnected(self):
        image = gtk.Image()
        image.set_from_file(
                os.path.join(utils.globals.IMAGES_DIR, 'connect.png'))
        image.show()
        self['connect_button'].set_icon_widget(image)
        self['connect_button'].set_label(_("Connect"))
        
        self['signal_image'].set_from_file(
                   os.path.join(utils.globals.IMAGES_DIR, 'signal-00.png'))
        
        self['upload_alignment'].hide()
        self['download_alignment'].hide()
        
        self['net_statusbar'].push(1, _('Not connected'))
    
    def set_connected(self):
        image = gtk.Image()
        image.set_from_file(os.path.join(utils.globals.IMAGES_DIR,
                                         'disconnect.png'))
        image.show()
        
        self['connect_button'].set_icon_widget(image)
        self['connect_button'].set_label(_("Disconnect"))
        
        self['mobile1'].set_sensitive(False)
        self['preferences_menu_item'].set_sensitive(False)
        
        self['upload_alignment'].show()
        self['download_alignment'].show()
    
    def set_no_device_present(self):
        for widget in WIDGETS_TO_HIDE:
            self[widget].set_sensitive(False)
        
        self.set_name(utils.globals.APP_LONG_NAME + ' / ' +
                      _('No device present'))
        
        self['cell_type_label'].set_text(_('N/A'))
        self['network_name_label'].set_text(_('N/A'))
    
    def set_device_present(self, ignored=None):
        for widget in WIDGETS_TO_HIDE:
            self[widget].set_sensitive(True)
        
        self.set_name()
    
    def setup_treeview(self, ctrl):
        """Sets up the treeviews"""
        
        for name in list(set(TV_DICT.values())):
            treeview = self[name]
            COL_SMSTYPE, COL_SMSTEXT, COL_SMSNUMBER, \
                    COL_SMSDATE, COL_SMSID = range(5)
            COL_USERTYPE, COL_USERNAME, COL_USERNUMBER, COL_USERID = range(4)
            if name in 'contacts_treeview':
                model = ContactsStoreModel()
            else:
                model = SMSStoreModel()
            
            treeview.set_model(model)
            treeview.get_selection().set_mode(gtk.SELECTION_MULTIPLE)
            
            if name in 'contacts_treeview':
                cell = gtk.CellRendererPixbuf()
                column = gtk.TreeViewColumn(_("Type"))
                column.pack_start(cell)
                column.set_attributes(cell, pixbuf = COL_USERTYPE)
                treeview.append_column(column)
                
                cell = gtk.CellRendererText()
                column = gtk.TreeViewColumn(_("Name"), cell,
                                            text=COL_USERNAME)
                column.set_resizable(True)
                column.set_sort_column_id(COL_USERNAME)
                cell.set_property('editable', True)
                cell.connect('edited', ctrl._name_contact_cell_edited)
                treeview.append_column(column)
                
                cell = gtk.CellRendererText()
                column = gtk.TreeViewColumn(_("Number"), cell,
                                            text=COL_USERNUMBER)
                column.set_resizable(True)
                column.set_sort_column_id(COL_USERNUMBER)
                cell.set_property('editable', True)
                cell.connect('edited', ctrl._number_contact_cell_edited)
                treeview.append_column(column)
                
                cell = gtk.CellRendererText()
                column = gtk.TreeViewColumn("IntId", cell, text=COL_USERID)
                column.set_visible(False)
                column.set_sort_column_id(COL_USERID)
                treeview.append_column(column)
                
            else: # inbox_tv outbox_tv drafts_tv sent_tv
                cell = gtk.CellRendererPixbuf()
                column = gtk.TreeViewColumn(_("Type"))
                column.pack_start(cell)
                column.set_attributes(cell, pixbuf = COL_SMSTYPE)
                treeview.append_column(column)
                
                cell = gtk.CellRendererText()
                cell.set_property('editable', False)
                column = gtk.TreeViewColumn(_("Text"), cell,
                                        text=COL_SMSTEXT)
                column.set_resizable(True)
                column.set_sort_column_id(COL_SMSTEXT)
                column.set_sizing(gtk.TREE_VIEW_COLUMN_FIXED)
                column.set_fixed_width(250)
                treeview.append_column(column)
                
                cell = gtk.CellRendererText()
                thename = name in 'sent_treeview' and _("Recipient") \
                                or _("Sender")
                column = gtk.TreeViewColumn(thename, cell, text=COL_SMSNUMBER)
                column.set_resizable(True)
                column.set_sort_column_id(COL_SMSNUMBER)
                cell.set_property('editable', False)
                treeview.append_column(column)
                    
                cell = gtk.CellRendererText()
                column = gtk.TreeViewColumn(_("Date"), cell, text=COL_SMSDATE)
                column.set_resizable(True)
                column.set_sort_column_id(COL_SMSDATE)
                cell.set_property('editable', False)
                treeview.append_column(column)
                
                cell = gtk.CellRendererText()
                column = gtk.TreeViewColumn("intId", cell, text=COL_SMSID)
                column.set_visible(False)
                column.set_sort_column_id(COL_SMSID)
                treeview.append_column(column)
    
    def start_throbber(self):
        self.throbber = gtk.Image()
        self['throbber_hbox'].pack_start(self.throbber, expand=False)
        animationpath = os.path.join(utils.globals.IMAGES_DIR, 'throbber.gif')
        animation = gtk.gdk.PixbufAnimation(animationpath)
        self.throbber.set_from_animation(animation)
        self.throbber.show()
    
    def stop_throbber(self):
        self.throbber.hide()

class ApplicationAboutView(BaseDialogView):
    """View for the about dialog"""
    GLADE_FILE = os.path.join(utils.globals.GLADE_DIR, "VMC.glade")
    
    def __init__(self, ctrl):
        BaseDialogView.__init__(self, ctrl, 'about_dialog')
    