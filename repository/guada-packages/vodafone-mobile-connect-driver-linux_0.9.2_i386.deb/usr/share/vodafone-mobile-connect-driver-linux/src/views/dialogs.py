# Author:  Pablo Marti
# Copyright (C) 2006  Warp Networks S.L.
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License along
# with this program; if not, write to the Free Software Foundation, Inc.,
# 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
"""Dialogs views"""
__version__ = "$Rev: 118 $"

# python imports
import os.path
# gtkmvc imports
from gtkmvc.view import View
# VMC imports
import utils.globals

class DialogView(View):
    """This is the base class for the dialogs"""
    
    GLADE_FILE = os.path.join(utils.globals.GLADE_DIR, "dialogs.glade")
    
    def __init__(self, ctrl, top_widget):        
        View.__init__(self, ctrl, self.GLADE_FILE, top_widget,
                      domain="VMC")

    def run(self):
        res = self.get_top_widget().run()
        self.get_top_widget().destroy()
        return res
    
class DialogMessage(DialogView):
    """Dialog message"""
    
    def __init__(self, ctrl, message, details):
        DialogView.__init__(self, ctrl, "dialog_message")
        self['label_message'].set_markup("<big><b>%s</b></big>" % message)
        self['label_details'].set_text(details)  

class WarningRequestOkCancel(DialogView):
    """Warning dialog with two OK/Cancel buttons"""
    
    def __init__(self, ctrl, message, details):
        DialogView.__init__(self, ctrl, "dialog_confirm_cancel_ok")
        self['label_message'].set_markup("<big><b>%s</b></big>" % message)
        self['label_details'].set_text(details)
        
class QuestionConfirmAction(DialogView):
    """Confirmation dialog for an action"""
    
    def __init__(self, ctrl, action_name, message, details):
        DialogView.__init__(self, ctrl, "dialog_confirm_action")
        self['label_message'].set_markup("<big><b>%s</b></big>" % message)
        self['label_details'].set_text(details)
        self['button_action'].set_label(action_name)
