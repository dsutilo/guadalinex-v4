# Author:  Pablo Marti
# Copyright (C) 2006  Warp Networks S.L.
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License along
# with this program; if not, write to the Free Software Foundation, Inc.,
# 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

__version__ = "$Rev: 262 $"

def attach_serial_protocol(device, debug=False, test=False):
    """
    Attachs the protocol to the reactor and returns the protocol's instance
    """
    from twisted.internet.serialport import SerialPort
    from twisted.internet import reactor
    bdrate = device.baudrate
    port = device.cport
    if not test:
        from common.middleware import SIMCardConnAdapter
        sconn = SIMCardConnAdapter(device, debug, test)
    else:
        from common.protocol import SIMCardConnection
        sconn = SIMCardConnection(device, debug, test)
    
    SerialPort(sconn, port, reactor, baudrate=bdrate)
    return sconn, SerialPort

def hook_it_up(sview, device_manager, sconn):
    """Attachs comms core to GUI and presents main screen"""
    
    # get main screen up
    from models.application import ApplicationModel
    from views.application import ApplicationView
    from controllers.application import ApplicationController
            
    model = ApplicationModel(sview, sconn)
    ctrl = ApplicationController(model, device_manager)
    view = ApplicationView(ctrl)
    
    import louie
    from louie.plugin import TwistedDispatchPlugin
    louie.install_plugin(TwistedDispatchPlugin())
    import utils.globals
    louie.connect(ctrl.sms_recv, utils.globals.SIG_SMSRECV)
    louie.connect(ctrl.timeout_handler, utils.globals.SIG_TIMEOUT)
    louie.connect(ctrl.invalid_dns_handler, utils.globals.SIG_INVALID_DNS)
    louie.connect(ctrl.disconnected_handler, utils.globals.SIG_DISCONNECTED)
    louie.connect(ctrl.device_removed_handler,
                  utils.globals.SIG_DEVICE_REMOVED)
    