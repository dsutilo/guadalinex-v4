# -*- coding: utf-8 -*-
# Copyright (C) 2006-2007  Vodafone España, S.A.
# Author:  Pablo Martí
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License along
# with this program; if not, write to the Free Software Foundation, Inc.,
# 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
"""
Config related classes and methods
"""
__version__ = "$Rev: 406 $"

# python imports
import os
from ConfigParser import ConfigParser
# VMC imports
from utils.borg import Borg
from utils.globals import VMC_CFG, WVTEMPLATE
from utils.utilities import get_file_data, save_file

class VMCConfig(Borg):
    """I manage VMC's configuration"""
    
    def __init__(self, path=VMC_CFG):
        Borg.__init__(self)
        self.path = path
        self.conf = ConfigParser()
        self.conf.readfp(open(self.path))
        
    def get(self, section, option):
        return self.conf.get(section, option)
    
    def getboolean(self, section, option):
        return self.conf.getboolean(section, option)
    
    def write(self):
        """Saves the current configuration to utils.globals.VMC_CFG"""
        return self.conf.write(open(self.path, 'w'))
     
    def set(self, section, option, value):
        return self.conf.set(section, option, value)

### binaries stuff
def get_default_binaries():
    """Returns the default MUA and browser binaries of the used DE"""
    de_dict = _get_binaries_dict_from_de()
    bin_dict = {}
    for key in de_dict.iterkeys():
        bin_dict[key] = _find_executable(de_dict[key])
    
    return bin_dict  
        
def _find_executable(binary):
    """Returns the absolute path of the binarie"""
    path_list = os.environ['PATH'].split(':')
    for path in path_list:
        tmppath = os.path.join(path, binary)
        if os.path.isfile(tmppath):
            return tmppath
    
    return None

def _get_binaries_dict_from_de():
    if os.environ.has_key('GNOME_DESKTOP_SESSION_ID'): # gnome
        return {'browser': 'firefox', 'mua': 'evolution'}
        
    elif os.environ.has_key('KDE_FULL_SESSION'): # kde
        return {'browser': 'konqueror', 'mua': 'kmail'}
    else:
        return {'browser': 'firefox', 'mua': 'evolution'}

### wvdial.conf stuff
def get_wvdial_conf_file(serial_port):
    """Returns the path of the generated wvdial.conf"""
    text = _generate_wvdial_conf(serial_port)
    import tempfile
    dirpath = tempfile.mkdtemp('', 'VMC', '/tmp')
    filepath = tempfile.mkstemp('wvdial.conf', 'VMC', dirpath, True)[1]
    save_file(filepath, text)
    return filepath

def _generate_wvdial_conf(serial_port):
    """
    Generates a specially crafted wvdial.conf with the given serial_port
    """
    from string import Template
    from cStringIO import StringIO
    
    conf = VMCConfig()
    user = conf.get('connection', 'username')
    passwd = conf.get('connection', 'password')
    theapn = conf.get('connection', 'apn')
    
    filedata = get_file_data(WVTEMPLATE)
    data = StringIO(filedata)
    template = Template(data.getvalue())
    wvdial_conf = template.substitute(serialport=serial_port,
                                      username=user,
                                      password=passwd,
                                      apn=theapn)
    data.close()
    return wvdial_conf
    