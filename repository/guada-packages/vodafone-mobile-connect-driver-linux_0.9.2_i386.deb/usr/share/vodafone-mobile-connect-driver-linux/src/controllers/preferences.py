# Author:  Pablo Marti
# Copyright (C) 2006  Warp Networks S.L.
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License along
# with this program; if not, write to the Free Software Foundation, Inc.,
# 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

__version__ = "$Rev: 247 $"

# gtkmvc imports
from gtkmvc.controller import Controller

class PreferencesController(Controller):
    """Controller for preferences"""
    
    def __init__(self, model):
        Controller.__init__(self, model)
    
    def register_view(self, view):
        Controller.register_view(self, view)

    def get_preferences(self):
        model = self.view['connection_combobox'].get_model()
        index = self.view['connection_combobox'].get_active()
        if index < 0:
            conn = None
        else:
            conn = model[index][0]
        from common.device import CONN_OPTS_DICT
        conn_option = CONN_OPTS_DICT[conn]
        return dict(username=self.view['username_entry'].get_text(),
                    password=self.view['password_entry'].get_text(),
                    connection=conn_option,
                    apn = self.view['apn_entry'].get_text())
    
    # ------------------------------------------------------------ #
    #                       Signals Handling                       #
    # ------------------------------------------------------------ #
    
    def on_preferences_ok_button_clicked(self, widget):
        preferences = self.get_preferences()
        from common.config import VMCConfig
        conf = VMCConfig()
        conf.set('connection', 'username', preferences['username'])
        conf.set('connection', 'password', preferences['password'])
        conf.set('connection', 'connection', preferences['connection'])
        conf.set('connection', 'apn', preferences['apn'])
        
        if self.view['checkbutton'].get_active():
            dns1 = self.view['dns1_entry'].get_text()
            dns2 = self.view['dns2_entry'].get_text()
            if not self._validate_correct_dns_ip(dns1):
                self.popup_invalid_url()
                self.view['dns1_entry'].select_region(0, -1)
                return
            elif not self._validate_correct_dns_ip(dns2):
                self.popup_invalid_url()
                self.view['dns2_entry'].select_region(0, -1)
                return
            else:
                conf.set('connection', 'dns1', dns1)
                conf.set('connection', 'dns2', dns2)
                conf.set('connection', 'staticdns', 'yes')
                
        else:
            conf.set('connection', 'staticdns', 'no')
        
        conf.write()
        
        # now set the new connection preference in case they're
        # already connected
        conn_str = self.model.sconn.device.conndict[preferences['connection']]
        d = self.model.send_conn_string(conn_str)
        def callback(resp):
            # now hide
            self.model.unregister_observer(self)
            self.view.hide()
        def errback(failure):
            print "FAILURE received setting up connection", failure
            
        d.addCallback(callback)
        d.addErrback(errback)
    
    def on_preferences_cancel_button_clicked(self, widget):
        self.model.unregister_observer(self)
        self.view.hide()
        
    def on_checkbutton_toggled(self, widget):
        try:
            active = self.view['checkbutton'].get_active()
        except TypeError:
            # We ignore this because the view will emit the toggled signal
            # and as the controller is not still registered, it produces
            # an exception, we can safely ignore it.
            return
        
        if active:
            self.view['dns1_entry'].set_sensitive(True)
            self.view['dns2_entry'].set_sensitive(True)
        else:
            self.view['dns1_entry'].set_sensitive(False)
            self.view['dns2_entry'].set_sensitive(False)
    
    # ------------------------------------------------------------ #
    #                       Misc Functionality                     #
    # ------------------------------------------------------------ #
    
    def _validate_correct_dns_ip(self, ip_str):
        return self.model.validate_ip(ip_str)
    
    def popup_invalid_url(self):
        import utils.dialogs
        message = _("Invalid IP")
        details = _("The IP you've just entered is not valid")
        utils.dialogs.open_message_dialog(message, details)
        