# -*- coding: utf-8 -*-
# Copyright (C) 2006-2007  Vodafone España, S.A.
# Author:  Pablo Martí
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License along
# with this program; if not, write to the Free Software Foundation, Inc.,
# 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
"""
Starts Vodafone Mobile Connect driver for Linux

execute it with:  twistd -r gtk2 -noy tap.py
"""

import os
import sys
import re
import gettext
import locale

from twisted.internet import reactor
from twisted.application.service import Application

from vmc.common.startup import create_service
from vmc.common.oal import get_os_object
import vmc.utils.globals
from vmc.common.exceptions import DeviceNotFoundError, DeviceLacksExtractInfo
from vmc.common.hardware import HardwareRegistry

__version__ = "$Rev: 495 $"

# i10n and i18n stuff
locale.setlocale(locale.LC_ALL, '')
gettext.install("VMC", None, unicode=1)

def check_dependencies():
    """checks that dependencies are satisfied"""
    try:
        import pygtk
        pygtk.require("2.0")
    except (ImportError, AssertionError):
        print "pygtk2 not found in sys.path"
        sys.exit(1)
        
    try:
        from twisted.copyright import version
        if [int(x) for x in re.search(r'^(\d+)\.(\d+)\.(\d+)',
                      version).groups()] < [ 2, 2, 0, ]:
            
            print "python-twisted module is too old, please upgrade"
            sys.exit(1)
        del version
    except ImportError:
        print "python-twisted module not present"
        sys.exit(1)
    
check_dependencies()

osobj = get_os_object()
if not osobj:
    print _(
"""
The OS/Distro under which you are running %s
is not registered in the OS database. Check the common.oal module for what
you should do in order to support your OS/Distro
""") % vmc.utils.globals.APP_LONG_NAME
    sys.exit(1)

def get_device():
    # VMC imports
    
    hw_reg = HardwareRegistry()
    
    try:
        device = hw_reg.get_3g_device()
    except DeviceNotFoundError:
        device = None
        
    return device

device = get_device()

def install_signal_handler():
    import signal
    from vmc.common.shutdown import shutdown_core
    signal.signal(signal.SIGINT, shutdown_core)

install_signal_handler()

service = create_service(device)
application = Application(vmc.utils.globals.APP_SHORT_NAME)
service.setServiceParent(application)
