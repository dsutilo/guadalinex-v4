# Author:  Pablo Marti
# Copyright (C) 2006  Warp Networks S.L.
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License along
# with this program; if not, write to the Free Software Foundation, Inc.,
# 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
"""
SerialProtocol-related classes
"""
__version__ = "$Rev: 299 $"

# python imports
import re
# twisted imports
from twisted.internet import protocol, reactor, defer
from twisted.python.failure import Failure
# VMC imports
import louie
from common.command import ATCmd, CMD_DICT as cmd_dict, XTRA
from common.aterrors import extract_error
import common.exceptions as ex
import utils.globals
from utils.utilities import ip_is_private

class SIMProtocol(protocol.Protocol):
    """SIMProtocol handles the communication with the SIM card
    
    SIMProtocol actually is an specially tailored Finite State Machine.
    This FSM has just four states:
     - idle: sitting idle for user input or SIM input.
     - busy: the FSM has received a command from the user and it will
             transition to the next state (waiting) once it has read
             the echo of the current command.
     - waiting: the FSM is waiting for the SIM's response of the command
             sent before the busy state.
     - sms_recv: the FSM was in idle state and has received a SMS.
     
     The transition to each state is driven by regular expressions, each
     command has associated a set of regular expressions that make the FSM
     change states. This regexps are defined in common.command.
    """
    
    def __init__(self, device, debug=True):
        self.device = device
        self.state = 'idle'
        self.iddlebuffer = ""
        self.busybuffer = ""
        self.waitbuffer = ""
        self.tskgbuffer = ""
        self.tskgb_is_over = False
        self.currentcmd = None
        self.debug = debug
        self.queue = defer.DeferredQueue()
        self.mutex = defer.DeferredLock()
        self.waitdefer = None
        self.timeoutdefer = None
        self._check_queue()
    
    def dataReceived(self, data):
        """This is called whenever data is received in the serial port"""
        match = XTRA['huaweigb'].search(data)
        if match:
            self.log("I've detected Huawei GARBAGE: %r" % match.group())
            self.log("Data received was %r" % data)
            data = re.sub(XTRA['huaweigb'], '', data)
            if not data:
                return
            
        self.log("Data received %r" % data)
        name = 'handle_' + self.state
        getattr(self, name)(data)
    
    def log(self, msg):
        """Logs the given message"""
        if self.debug:
            print msg
    
    def send_splitcmd(self):
        """
        Used to send the second part of a split command after prompt appears
        """
        self.transport.write(self.currentcmd.splitcmd)
    
    def _clean_data(self, data):
        """Returns a clean copy of data (without \r\n)"""
        return data.replace('\r', '').replace('\n', '')
    
    def _transition_tsk_garbage(self):
        """Transitions the FSM to the tsk_garbage state"""
        self.log("Transitioning to TSK garbage state")
        self.state = 'tsk_garbage'
        reactor.callLater(6, self._finish_stkgb_state)
    
    def _finish_stkgb_state(self):
        if not self.tskgb_is_over:
            self.log("I'm gonna transition to idle state, this card " + \
                     "doesn't seems to support STK or is already over")
            self.tskgb_is_over = True
            self._transition_idle()
    
    def _transition_idle(self):
        self.log("Transitioning to idle state...")
        self.currentcmd = None
        self.busybuffer = ""
        self.waitbuffer = ""
        self.iddlebuffer = ""
        self.state = 'idle'
        if self.mutex.locked:
            self.mutex.release()
        self._check_queue()
    
    def _check_queue(self):
        self.waitdefer = self.queue.get()
        self.waitdefer.addCallback(self._process_at_cmd)
    
    def queue_at_cmd(self, cmd):
        """Queues an ATCmd and returns a deferred
        
        This deferred will be called with the command's response
        """
        self.queue.put(cmd)
        return cmd.deferred
    
    def _process_at_cmd(self, atcmd):
        def transition_n_send(ignored_mutex):
            self.currentcmd = atcmd        
            assert self.state == 'idle', \
                    "My state is not idle: %s" % self.state
            
            self.state = 'waiting'
            self.log("my state is " + self.state)
            self.log("Sending atcmd %r" % atcmd.cmd)
            self.transport.write(atcmd.cmd)
            
        self.mutex.acquire().addCallback(transition_n_send)
    
    #####################################################################
    # STATES STUFF
    #####################################################################
    
    def handle_tsk_garbage(self, data):
        """Handler for the tsk_garbage state
        
        Cards like Option's Globetrotter doesn't discard unsolicited STK
        (SIM Application Toolkit) messages. This means that after sending
        the PIN, the card will send us an unsolicited message codes that
        must be ignored. This will happen for example with 64K SIM cards
        that have an STK app builtin.
        """
        self.tskgbuffer += data
        self.log("My tsk buffer is %r" % self.tskgbuffer)
        # My tsk buffer is
        match = XTRA['stkgb'].search(self.tskgbuffer)
        if match:
            self.log("I've detected STK garbage I think we're done")
            self._finish_stkgb_state()
        
    def handle_idle(self, data):
        """Handler for the idle state
        
        While in idle state, we might receive a notification from the SIM
        that we have received a SMS, in that case we will transition to
        the SMS recv state.
        """
        self.iddlebuffer += data
        self.log("handle_idle received %r" % data)
        match = XTRA['newsms'].match(self.iddlebuffer)
        if match:
            self.handle_sms_recv(match)
        else:
            self.log("handle_idle: %r doesn't matchs my regexp" %
                     self.iddlebuffer)
    
    def handle_busy(self, data):
        """Handler for the busy state
        
        Being in busy state means that we are in the process of sending an
        at command. It will wait till the regexp defined in common.command
        matches the busybuffer, when it finds a match it will transition to
        the waiting state. Some times the echo of the sent command and its
        response are packed in a single replay, handle_busy handles it.
        """
        assert self.state == 'busy'
        self.busybuffer += data
        self.log("handle_busy received %r" % self.busybuffer)
        if cmd_dict.has_key(self.currentcmd.name):
            retuple = cmd_dict[self.currentcmd.name]
            match = retuple['echo'].match(self.busybuffer)
            if match:
                matched = match.group()
                if len(matched) < len(self.busybuffer):
                    # there are some cases when the command echo and its
                    # response (or part of it) are sent together in the
                    # same chunk, this detects it and auto transitions to
                    # the waiting state with the rest of the data
                    remain = self.busybuffer[len(matched):]
                    self.log("Auto transitioning to waiting")
                    self.state = 'waiting'
                    self.handle_waiting(remain)
                
                self.log("I'm transitioning to waiting state")
                self.state = 'waiting'
            else:
                self.log("Data %r didn't match my regexp" % data)
        else:
            self.log("I don't have a busy handler for cmd %s"
                     % self.currentcmd.name)
    
    def handle_waiting(self, data):
        """Handler for the waiting state
        
        Being in waiting state means that we have already been through
        the busy state and we have received its echo. Each command has
        associated a regexp and an associated state that when matched
        will fire the transition_'name' method, effectively transitioning
        to the associated state.
        """
        assert self.state == 'waiting'
        self.log("handle_waiting received %r" % data)
        self.waitbuffer += data
        if cmd_dict.has_key(self.currentcmd.name):
            cmdinfo = cmd_dict[self.currentcmd.name]
            if cmdinfo['end'].search(self.waitbuffer): # end of response
                self.log("End of response detected, firing deferred")
                if cmdinfo['extract']:
                    # There's an regex to extract info from data
                    response = []
                    for match in re.finditer(cmdinfo['extract'],
                                         self.waitbuffer):
                        response.append(match)
                    self.log("I'm gonna callback with this: "
                             + str([match.groups() for match in response]))
                    
                    self.currentcmd.deferred.callback(response)
                else: # there's no regex in cmdinfo to extract info
                    if self.currentcmd.cheat:
                        # This is an special case for commands like
                        # add_contact where by its semantics returning
                        # the desired value is difficult, this is ugly but
                        # does the job
                        self.currentcmd.deferred.callback(
                                              self.currentcmd.cheat)
                    else:
                        cleandata = self._clean_data(self.waitbuffer)
                        self.log("I'm gonna callback clean with this "
                                 + cleandata)
                        self.currentcmd.deferred.callback(cleandata)
                
                # get next state 
                nextname = '_transition_' + cmdinfo['nextstate']
                self.log("I'm transitioning to %s state" % nextname)
                nextstate = getattr(self, nextname, None)
                nextstate()
                    
            else:
                match = extract_error(self.waitbuffer)
                if match:
                    excep, error = match
                    self.log("ERROR received: %s" % error)
                    failure = Failure(error, excep)
                    # send the failure back
                    self.currentcmd.deferred.errback(failure)
                    
                    self._transition_idle()
                else:
                    self.log("Data %r didn't match my regexp" % data)
                    if XTRA['splitprompt'].match(data):
                        self.waitbuffer = self.waitbuffer[:-len(data)]
                        self.log("Looks like this is an splitcmd...")
                        self.send_splitcmd()
    
    def handle_sms_recv(self, sms):
        """Handler for the sms_recv state"""
        self.log("handle_sms_recv received sms" + str(sms))
        from utils.globals import SIG_SMSRECV
        louie.send(SIG_SMSRECV, None, sms)

class SIMCardConnection(SIMProtocol):
    """
    SIMCardConnection provides several methods to interact with the SIM card
    """
    def __init__(self, device, debug=False, test=False):
        SIMProtocol.__init__(self, device, debug)
        self.size = None
    
    #####################################################################
    # USER COMMANDS
    #####################################################################
    
    def add_contact(self, contact):
        """Adds a contact to the SIM card
        
        @type contact: L{common.persistent.Contact}
        @param contact: The contact to be added
        
        @rtype: L{common.persistent.Contact}
        @return: The contact object just added. If the user didn't specify an
        index she will be interested in the object as the returned object has
        the index updated.
        """
        # Add a contact represents a challenge as its semantics are
        # "funny". In order to add a contact, you need to specify the index
        # where the contact will be stored or you can also let the SIM card
        # decide the index where it will be stored. The problem is that
        # AT+CPBW doesn't returns the index where it was stored, just a mere
        # OK. In this asynchronous world, we need to return a deferred asap
        # and this blocking operation is in the middle... Solution?
        # <hack>
        # We cheat, we still return a deferred but instead the ATCmd's one,
        # we create one extra that will be callback'd with the response of
        # AT+CPBW=foo,bar. Why? Because we substitute the ATCmd's one with
        # our deferred (d2) and that's the one callbacked in handle_waiting
        # </hack>
        
        # contacts are limited to ascii for now, stay tuned
        contact.name = contact.name.encode('ascii', 'replace')
        
        if contact.index:
            args = str(contact.index) + ',"' + contact.number + '",' + \
                contact.category + ',"' + contact.name + '"'
            cmd = ATCmd('AT+CPBW=' + args)
            cmd.name = 'add_contact'
            return self.queue_at_cmd(cmd)
        else:
            d = self.get_next_contact_id()
            d2 = defer.Deferred()
            def callback(index, auxdefer):
                args = str(index) + ',"' + contact.number + '",' + \
                        contact.category + ',"' + contact.name + '"'
                cmd = ATCmd('AT+CPBW=' + args)
                cmd.name = 'add_contact'
                cmd.deferred = auxdefer
                cmd.cheat = index
                self.queue_at_cmd(cmd)
            
            d.addCallback(callback, d2)
            return d2
    
    def change_pin(self, oldpin, newpin):
        """Changes oldpin to newpin in the SIM card
        
        @type oldpin: C{int}
        @type newpin: C{int}
        
        @return: If everything goes well, it will return an 'OK' through the
        callback, otherwise it will raise an exception.
        
        @raise common.exceptions.ATError: When the password is incorrect.
        @raise common.exceptions.CMEErrorIncorrectPassword: When the
        password is incorrect.
        @raise common.exceptions.InputValueError: When the PIN != \d{4}
        """
        cmd = ATCmd('AT+CPWD="SC","' + str(oldpin) + '","' + str(newpin) +'"')
        cmd.name = 'change_pin'
        return self.queue_at_cmd(cmd)
    
    def check_pin(self):
        """Checks what's necessary to authenticate against the SIM card
        
        @return: If everything goes well, it will return one of the following
          1. +CPIN: READY
          2. +CPIN: SIM PIN
          3. +CPIN: SIM PUK
          4. +CPIN: SIM PUK2
        
        @raise common.exceptions.CMEErrorSIMBusy: When the SIM is not ready
        @raise common.exceptions.CMEErrorSIMNotStarted: When the SIM is not
        ready
        @raise common.exceptions.CMEErrorSIMFailure: This exception is
        raised by GlobeTrotter's 3G cards (without HSDPA) when PIN
        authentication is disabled
        """
        cmd = ATCmd('AT+CPIN?')
        cmd.name = 'check_pin'
        return self.queue_at_cmd(cmd)
    
    def delete_all_contacts(self):
        """Deletes all the contacts in SIM card, function useful for tests"""
        d2 = defer.Deferred()
        d = self.get_used_contact_ids()
        def callback(used):
            if used == []:
                d2.callback(True)
            
            def callback2(resp):
                d2.callback(True)
            
            d3 = self.delete_list_contacts(used)            
            d3.addCallback(callback2)
        
        def errback(failure):
            d2.errback(failure)
        
        d.addCallback(callback)
        d.addErrback(errback)
        return d2
    
    def delete_all_sms(self):
        """Deletes all the messages in SIM card, function useful for tests"""
        d2 = defer.Deferred()
        d = self.get_used_sms_ids()
        def callback(used):
            if not used:
                d2.callback(True)
            
            def callback2(resp):
                d2.callback(True)
            
            d3 = self.delete_list_sms(used)
            if not d3.called:           
                d3.addCallback(callback2)
        
        d.addCallback(callback)
        
        return d2 
            
    def delete_list_contacts(self, clist):
        """Deletes the list of contacts specified by clist"""
        deflist = []
        for index in clist:
            d = self.delete_contact(index)
            deflist.append(d)
          
        return defer.DeferredList(deflist)
    
    def delete_list_sms(self, smslist):
        """Deletes the list of sms specified by smslist"""
        if not smslist:
            return defer.succeed(True)
        
        deflist = []
        for index in smslist:
            d = self.delete_sms(index)
            deflist.append(d)
        
        return defer.DeferredList(deflist)
    
    def delete_contact(self, index):
        """Deletes the contact specified by index"""
        cmd = ATCmd('AT+CPBW=' + str(index))
        cmd.name = 'delete_contact'
        return self.queue_at_cmd(cmd)
    
    def delete_sms(self, index):
        """Deletes the message specified by index"""
        cmd = ATCmd('AT+CMGD=' + str(index))
        cmd.name = 'delete_sms'
        return self.queue_at_cmd(cmd)
    
    def disable_echo(self):
        """Disables echo of AT cmds"""
        cmd = ATCmd('ATE0')
        cmd.name = 'disable_echo'
        return self.queue_at_cmd(cmd)
    
    def disable_pin(self, pin):
        """Disables pin authentication at startup
        
        @type pin: C{int}
        @return: If everything goes well, it will return an 'OK' through the
        callback, otherwise it will raise an exception.
        
        @raise common.exceptions.ATError: When the PIN is incorrect.
        @raise common.exceptions.CMEErrorIncorrectPassword: When the
        PIN is incorrect.
        @raise common.exceptions.InputValueError: When the PIN != \d{4}
        """
        cmd = ATCmd('AT+CLCK="SC",0,"' + pin + '"')
        cmd.name = 'disable_pin'
        return self.queue_at_cmd(cmd)
    
    def enable_pin(self, pin):
        """Enables pin authentication at startup
        
        @type pin: C{int}
        @return: If everything goes well, it will return an 'OK' through the
        callback, otherwise it will raise an exception.
        
        @raise common.exceptions.ATError: When the PIN is incorrect.
        @raise common.exceptions.CMEErrorIncorrectPassword: When the
        PIN is incorrect.
        @raise common.exceptions.InputValueError: When the PIN != \d{4}
        """
        cmd = ATCmd('AT+CLCK="SC",1,"' + pin + '"')
        cmd.name = 'enable_pin'
        return self.queue_at_cmd(cmd)
        
    def find_contact(self, pattern):
        """Returns a list of contacts that match the given pattern"""
        cmd = ATCmd('AT+CPBF="' + pattern + '"')
        cmd.name = 'find_contact'
        return self.queue_at_cmd(cmd)
    
    def get_all_sms(self):
        """Returns a list with all the messages stored in the SIM card
        
        @return: Returns a list of C{re.MatchObject} with the messages.
        
        @raise common.exceptions.ATError: When no messages are found.
        @raise common.exceptions.CMEErrorNotFound: When no messages are
        found.
        @raise common.exceptions.CMEErrorSIMBusy: When the SIM is not
        ready.
        @raise common.exceptions.CMEErrorSIMNotStarted: When the SIM is not
        ready.
        @raise common.exceptions.CMSError500: When the SIM is not
        ready.
        """
        cmd = ATCmd('AT+CMGL=4')
        cmd.name = 'get_all_sms'
        return self.queue_at_cmd(cmd)
    
    def _get_all_contacts(self):
        """Returns a list with all the contacts stored in the SIM card
        
        @return: Returns a list of C{re.MatchObject} with the contacts.
        
        @raise common.exceptions.ATError: When no contacts are found.
        @raise common.exceptions.CMEErrorNotFound: When no contacts are
        found.
        @raise common.exceptions.CMEErrorSIMBusy: When the SIM is not
        ready.
        @raise common.exceptions.CMEErrorSIMNotStarted: When the SIM is not
        ready.
        """
        if not self.size:
            d = self.get_phonebook_size()
            d2 = defer.Deferred()
            def callback(sizeregexp, auxdefer):
                # necessary for tests
                if isinstance(sizeregexp, int):
                    size = sizeregexp
                else:
                    size = int(sizeregexp[0].group('size'))
                
                self.size = size
                cmd = ATCmd('AT+CPBR=1,' + str(self.size))
                cmd.name = 'get_all_contacts'
                cmd.deferred = auxdefer
                return self.queue_at_cmd(cmd)
            
            d.addCallback(callback, d2)
            return d2
        else:
            cmd = ATCmd('AT+CPBR=1,' + str(self.size))
            cmd.name = 'get_all_contacts'
            return self.queue_at_cmd(cmd)
    
    def get_card_version(self):
        """Returns the SIM card version"""
        cmd = ATCmd('AT+GMR')
        cmd.name = 'get_card_version'
        return self.queue_at_cmd(cmd)
    
    def get_card_model(self):
        """Returns the SIM card model"""
        cmd = ATCmd('AT+CGMM')
        cmd.name = 'get_card_model'
        return self.queue_at_cmd(cmd)
                
    def get_imei_number(self):
        """Returns the IMEI number of the SIM card"""
        cmd = ATCmd('AT+CGSN')
        cmd.name = 'get_imei_number'
        return self.queue_at_cmd(cmd)
    
    def get_imsi_number(self):
        """Returns the IMSI number of the SIM card"""
        cmd = ATCmd('AT+CIMI')
        cmd.name = 'get_imsi_number'
        return self.queue_at_cmd(cmd)
    
    def get_manufacturer_name(self):
        """Returns the manufacturer name of the SIM card"""
        cmd = ATCmd('AT+CGMI')
        cmd.name = 'get_manufacturer_name'
        return cmd
    
    def get_network_info(self):
        """Returns a tuple with the network info"""
        cmd = ATCmd('AT+COPS?')
        cmd.name = 'get_network_info'
        return self.queue_at_cmd(cmd)
    
    def get_free_contact_ids(self):
        """Returns a list with the not used contact ids"""
        def callback(used_ids):
            if not used_ids:
                return range(1, self.size)
            
            busy_ids = [int(contact.group('id')) for contact in used_ids]
            
            return list(set(range(1, self.size)) ^ set(busy_ids))
        
        def errback(failure):
            failure.trap(ex.CMEErrorNotFound, ex.ATError)
            return range(1, self.size)
        
        d = self._get_all_contacts()
        d.addCallback(callback)
        d.addErrback(errback)
        return d
    
    def get_next_contact_id(self):
        """Returns the next free contact id"""
        def callback(free):
            return free.pop(0)
        
        d = self.get_free_contact_ids()
        d.addCallback(callback)
        return d
    
    def get_signal_level(self):
        """Returns a tuple with the RSSI and BER of the connection"""
        cmd = ATCmd('AT+CSQ')
        cmd.name = 'get_signal_level'
        return self.queue_at_cmd(cmd)
    
    def get_sms(self, index):
        """Returns the message stored at index"""
        cmd = ATCmd('AT+CMGR=' + str(index))
        cmd.name = 'get_sms'
        return self.queue_at_cmd(cmd)
    
    def get_phonebook_size(self):
        """Returns the phonebook size of the SIM card
        
        @return: A C{re.MatchObject} with the size of the phonebook
        
        @raise common.exceptions.CMEErrorSIMBusy: When the SIM is not
        ready.
        @raise common.exceptions.CMSError500: When the SIM is not ready.
        @raise common.exceptions.ATError: When the SIM is not ready.
        """
        cmd = ATCmd('AT+CPBR=?')
        cmd.name = 'get_phonebook_size'
        return self.queue_at_cmd(cmd)
    
    def _get_pin_status(self):
        """Checks wether the pin is enabled or disabled"""
        cmd = ATCmd('AT+CLCK="SC",2')
        cmd.name = 'check_pin_status'
        return self.queue_at_cmd(cmd)
    
    def get_used_contact_ids(self):
        """Returns a list with the used contact ids"""
        def callback(contacts):
            if not contacts:
                return []
            
            return [int(contact.group('id')) for contact in contacts]
        
        def errback(failure):
            failure.trap(ex.CMEErrorNotFound, ex.ATError)
            return []
        
        d = self._get_all_contacts()
        d.addCallback(callback)
        d.addErrback(errback)
        return d
    
    def get_used_sms_ids(self):
        """Returns a list with used SMS ids in the SIM card"""
        d = self.get_all_sms()
        def callback(smslist):
            if not smslist:
                return []
            
            return [int(sms.group('id')) for sms in smslist]
        
        def errback(failure):
            failure.trap(ex.CMEErrorNotFound, ex.ATError)
            return None
        
        d.addCallback(callback)
        d.addErrback(errback)
        return d
    
    def save_sms(self, number, text):
        """Returns the index where the message was stored at"""
        cmd = ATCmd('AT+CMGW="' + str(number) + '"', eol='\r')
        cmd.splitcmd = text + '\032'
        cmd.name = 'save_sms'
        return self.queue_at_cmd(cmd)
    
    def send_conn_string(self, conn_str):
        """Sends the conn_str to the SIM card"""
        cmd = ATCmd(conn_str)
        cmd.name = 'send_conn_string'
        return self.queue_at_cmd(cmd)
    
    def send_pin(self, pin):
        """Sends the PIN to the SIM card"""
        cmd = ATCmd('AT+CPIN=' + str(pin))
        cmd.name = 'send_pin'
        return self.queue_at_cmd(cmd)
    
    def send_puk(self, puk, pin):
        """Sends the PUK to the SIM card"""
        cmd = ATCmd('AT+CPIN="' + str(puk) + '","' + str(pin) + '"')
        cmd.name = 'send_puk'
        return self.queue_at_cmd(cmd)
    
    def send_sms(self, sms):
        """Sends the given text to the number and returns the index"""
        from common.sms.sms import message_to_pdu
        pdu_text = message_to_pdu(sms)
        command = 'AT+CMGS=%d' % (len(pdu_text) / 2)
        cmd = ATCmd(command, eol='\r')
        cmd.splitcmd = '00%s\x1a' % pdu_text
        cmd.name = 'send_sms'
        return self.queue_at_cmd(cmd)
    
    def set_sms_format(self, format=1):
        """Sets the format of the SMS"""
        cmd = ATCmd('AT+CMGF=' + str(format))
        cmd.name = 'set_sms_format'
        return self.queue_at_cmd(cmd)
    
    def set_sms_indication(self, mode=2, mt=1):
        """Sets the SMS indication mode"""
        cmd = ATCmd('AT+CNMI=' + str(mode) + ',' + str(mt))
        cmd.name = 'set_sms_indication'
        return self.queue_at_cmd(cmd)


MAX_ATTEMPTS_REGEXP = re.compile('Maximum Attempts Exceeded')
PPPD_DIED_REGEXP = re.compile('The PPP daemon has died')
DNS_REGEXP = re.compile(r"""
   DNS\saddress
   \s                                     # beginning of the string
   (?P<ip>                                # group named ip
   (25[0-5]|                              # integer range 250-255 OR
   2[0-4][0-9]|                           # integer range 200-249 OR
   [01]?[0-9][0-9]?)                      # any number < 200
   \.                                     # matches '.'
   (25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?) # repeat
   \.                                     # matches '.'
   (25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?) # repeat
   \.                                     # matches '.'
   (25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?) # repeat
   )                                      # end of group
   \b                                     # end of the string
   """, re.VERBOSE)

class WVDialProtocol(protocol.ProcessProtocol):
    """ProcessProtocol for wvdial"""
    
    def __init__(self, staticdns):
        self.__connected = False
        self.deferred = defer.Deferred()
        self.staticdns = staticdns
        self.dns = []
        
    def connectionMade(self):
        self.transport.closeStdin()
        
    def outReceived(self, data):
        print "WVDIAL: sysout", data
        
    def errReceived(self, data):
        """wvdial has this bad habit of using stderr for debug"""
        print 'WVDIAL: errdata is', data
        self.parse_output(data)
        
    def outConnectionLost(self):
        print 'WVDIAL: The child closed their stdout!'
        
    def errConnectionLost(self):
        print 'WVDIAL: The child closed their stderr.'
        
    def processEnded(self, status_object):
        print 'quitting'
    
    def extract_dns_strings(self, data):
        if self.__connected:
            return
        
        for match in re.finditer(DNS_REGEXP, data):
            dns_ip = match.group('ip')
            self.dns.append(dns_ip)
        
        if len(self.dns) == 2:
            # Notify the user we are connected
            louie.send(utils.globals.SIG_CONNECTED, None)
            self.deferred.callback(True)
            self.__connected = True
            # check if they're valid DNS ips
            if ip_is_private(self.dns[0]) or ip_is_private(self.dns[1]):
                # the DNS assigned by the APN is probably invalid
                # lets notify the user only if she didn't specify static DNS
                if not self.staticdns:
                    louie.send(utils.globals.SIG_INVALID_DNS, None, self.dns)
    
    def extract_disconnected(self, data):
        disconnected = MAX_ATTEMPTS_REGEXP.search(data)
        pppd_died = PPPD_DIED_REGEXP.search(data)
        if disconnected or pppd_died:
            louie.send(utils.globals.SIG_DISCONNECTED, None)
    
    def parse_output(self, data):
        self.extract_dns_strings(data)
        self.extract_disconnected(data)
        