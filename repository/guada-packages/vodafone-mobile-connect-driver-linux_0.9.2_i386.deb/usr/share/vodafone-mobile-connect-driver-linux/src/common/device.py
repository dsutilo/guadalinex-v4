# Author:  Pablo Marti
# Copyright (C) 2006  Warp Networks S.L.
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License along
# with this program; if not, write to the Free Software Foundation, Inc.,
# 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
"""
Set of classes that handle device discovery via dbus/hal
"""
__version__ = "$Rev: 300 $"

# python imports
import os.path
# dbus imports
import dbus

if dbus.version >= (0, 80, 0):
    print "VMC with dbus >= 0.8.0 is currently broken"
    from twisted.internet import reactor
    reactor.stop()

if getattr(dbus, 'version', (0, 0, 0)) >= (0, 41, 0):
    import dbus.glib

# VMC imports
import common.exceptions as ex

try:
    _
except NameError:
    import gettext
    _ = gettext.gettext

HUAWEI_DICT = {
   'GPRSONLY' : 'AT^SYSCFG=13,1,3FFFFFFF,2,4',
   '3GONLY' : 'AT^SYSCFG=14,2,3FFFFFFF,2,4',
   'GPRSPREF' : 'AT^SYSCFG=2,1,3FFFFFFF,2,4',
   '3GPREF' : 'AT^SYSCFG=2,2,3FFFFFFF,2,4',
}

OPTION_DICT = {
   'GPRSONLY' : 'AT_OPSYS=0',
   '3GONLY' : 'AT_OPSYS=1',
   'GPRSPREF' : 'AT_OPSYS=2',
   '3GPREF' : 'AT_OPSYS=3',
}

CONN_OPTS_LIST = [_('GPRS only').encode('utf8'), _('3G only').encode('utf8'),
                  _('GPRS preferred').encode('utf8'),
                  _('3G preferred').encode('utf8')]

CONN_OPTS_DICT = {
   _('GPRS only').encode('utf8') : 'GPRSONLY',
   _('3G only').encode('utf8') : '3GONLY',
   _('GPRS preferred').encode('utf8') : 'GPRSPREF',
   _('3G preferred').encode('utf8') : '3GPREF'
}

CONN_OPTS_DICT_REV = {}
for k, v in CONN_OPTS_DICT.iteritems():
    CONN_OPTS_DICT_REV[v] = k

class DeviceManager(object):
    """This class discovers and manages devices"""
    
    def __init__(self):
        self.bus = dbus.SystemBus()
        self.hal_manager = self.bus.get_object('org.freedesktop.Hal',
                                  '/org/freedesktop/Hal/Manager')
        self.hal_interface = dbus.Interface(self.hal_manager,
                                            'org.freedesktop.Hal.Manager')
        self.device = None
    
        self.hal_interface.connect_to_signal('DeviceAdded',
                                         self.device_added_cb)
        self.hal_interface.connect_to_signal('DeviceRemoved',
                                         self.device_removed_cb)
    
    def device_added_cb(self, udi):
        print udi
    
    def device_removed_cb(self, udi):
        if udi == self.device.udi:
            import louie
            from utils.globals import SIG_DEVICE_REMOVED
            louie.send(SIG_DEVICE_REMOVED, None)
    
    def get_3g_device(self):
        """
        Returns a NetworkDevice instance corresponding to the attached device
        """
        found = False
        # <malign hack>
        for udi in self.hal_interface.FindDeviceStringMatch('info.bus', 'usb'):
            if found:
                break

            obj = self.bus.get_object('org.freedesktop.Hal', udi)
            vendor_id = obj.GetProperty('usb.vendor_id')
            product_id = obj.GetProperty('usb.product_id')
            
            try:
                net_device = DEVICES_DICT[vendor_id][product_id]
                device_udi = obj.GetProperty('info.udi')
            except KeyError:
                continue
            else:
                found = True  
        
        if found:
            for udi in self.hal_interface.FindDeviceByCapability('serial'):
                obj = self.bus.get_object('org.freedesktop.Hal', udi)
                serial_udi = obj.GetProperty('info.udi')
                if serial_udi.startswith(device_udi):
                    net_device.udi = device_udi
                    self.device = net_device
                    return True
        else:
            # Option's GlobeTrotter with nozomi drivers doesn't shows up in
            # lshal, so we have to do this ugly hack where we check wether
            # /dev/noz0 exists or not.
            # <malign hack>
            if os.path.exists('/dev/noz0'):
                self.device = GPRSUMTSHSDPADevice(
                       "GlobeTrotter 3G+",
                       'noz0', 'noz2', 115200,
                       OPTION_DICT)
                return True
            # </malign hack>
 
        raise ex.DeviceNotFoundError(_("No supported 3G device found"))

class MobileDevice(object):
    """I represent a mobile device"""
    
    def __init__(self, description, dport, cport, baudrate, conndict):
        self.description = description
        self.dport = '/dev/' + dport
        self.cport = '/dev/' + cport
        self.baudrate = baudrate
        self.conndict = conndict
        self.udi = None

class GPRSDevice(MobileDevice):
    """I represent a GPRS-capable device"""
    pass

class UMTSDevice(MobileDevice):
    """I represent a UMTS-capable device"""
    pass

class HSDPADevice(MobileDevice):
    """I represent an HSDPA-capable device"""
    pass

class GPRSUMTSDevice(GPRSDevice, UMTSDevice):
    pass

class GPRSUMTSHSDPADevice(GPRSDevice, UMTSDevice, HSDPADevice):
    pass

DEVICES_DICT = {
     0xAF0  : {             # vendor_id
           0x5000 :         # product id
                GPRSUMTSDevice(
                    "Option's 3G Datacard", # description
                    'ttyUSB0',                           # control port
                    'ttyUSB2',                           # data port
                    115200,                              # baudrate
                    OPTION_DICT),
                
           0x5001 :
                 GPRSUMTSHSDPADevice(
                     "Vodafone Mobile Connect Card - HSDPA",
                     'nz0',
                     'nz2',
                     115200,
                     OPTION_DICT),
     },
     0x12D1 : {
           
           0x1001 :
               GPRSUMTSHSDPADevice(
                    "Huawei's E620 UMTS/HSDPA",
                    'ttyUSB0',
                    'ttyUSB2',
                    115200,
                    HUAWEI_DICT),
            
           0x1003 :
               GPRSUMTSHSDPADevice(
                     "Huawei/E220 HSDPA modem",
                     'ttyUSB0',
                     'ttyUSB2',
                     115200,
                     HUAWEI_DICT),
     }
}
