# Author:  Pablo Marti
# Copyright (C) 2006  Warp Networks S.L.
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License along
# with this program; if not, write to the Free Software Foundation, Inc.,
# 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
"""
AT Commands related classes and help functions
"""
__version__ = "$Rev: 281 $"

# python imports
import re
# twisted imports
from twisted.internet import defer
# VMC imports
from common.aterrors import ERROR_REGEXP

XTRA = {
    'huaweigb' : re.compile('\r\n\^[A-Z]{3,}:\d+.*\r\n'), 
    'stkgb' : re.compile('\r\n\r\n\+STC:\s\d+\r\n'),
    'newsms' : re.compile('\r\n\+CMTI:\s"(?P<where>\w{2})",(?P<id>\d+)\r\n'),
    'splitprompt' : re.compile('^\r\n>\s$'),
    'numericid' : re.compile('\d+')
}

CMD_DICT = {
                 
    'add_contact' :
            dict(echo=re.compile('AT\+CPBW=\d+,"[\+]?\d+",\d+,".*"\r'),
                 end=re.compile('\r\nOK\r\n$'),
                 error=ERROR_REGEXP,
                 extract=None,
                 nextstate='idle'),
    
    'change_pin' :
            dict(echo=re.compile('AT\+CPWD="SC","\d+","\d+"\r'),
                 end=re.compile('\r\nOK\r\n'),
                 error=ERROR_REGEXP,
                 extract=None,
                 nextstate='idle'),
    
    'check_pin' :
            dict(echo=re.compile('AT\+CPIN\?\r'),
                 end=re.compile('\r\nOK\r\n$'),
                 error=ERROR_REGEXP,
                 extract=re.compile("""
                     \r\n
                     (?P<resp>
                     \+CPIN:\sREADY    |
                     \+CPIN:\sSIM\sPIN |
                     \+CPIN:\sSIM\sPUK
                     )\r\n
                     """, re.VERBOSE),
                 nextstate='idle'),
                 
    'check_pin_status' :
            dict(echo=re.compile('AT\+CLCK="SC",2\r'),
                 end=re.compile('\r\nOK\r\n'),
                 error=ERROR_REGEXP,
                 extract=re.compile('\r\n\+CLCK:\s(?P<status>\d)\r\n'),
                 nextstate='idle'),
     
    'delete_contact' :
            dict(echo=re.compile('AT\+CPBW=\d+\r'),
                 end=re.compile('\r\nOK\r\n$'),
                 error=ERROR_REGEXP,
                 extract=None,
                 nextstate='idle'),
    
    'delete_sms' :
            dict(echo=re.compile('AT\+CMGD=\d+\r'),
                 end=re.compile('\r\nOK\r\n$'),
                 error=ERROR_REGEXP,
                 extract=None,
                 nextstate='idle'),
                 
    'disable_echo' :
            dict(echo=re.compile('ATE0\r'),
                 end=re.compile('\r\nOK\r\n$'),
                 error=ERROR_REGEXP,
                 extract=None,
                 nextstate='idle'),
                 
    'disable_pin' :
            dict(echo=re.compile('AT\+CLCK="SC",0,"\d+"\r'),
                 end=re.compile('\r\n(OK)\r\n$'),
                 error=ERROR_REGEXP,
                 extract=None,
                 nextstate='idle'),
                 
    'enable_pin' :
            dict(echo=re.compile('AT\+CLCK="SC",1,"\d+"\r'),
                 end=re.compile('\r\n(OK)\r\n$'),
                 error=ERROR_REGEXP,
                 extract=None,
                 nextstate='idle'),
                 
    'find_contact' :
            dict(echo=re.compile('AT\+CPBF="(.*)"\r'),
                 end=re.compile('\r\nOK\r\n'),
                 error=ERROR_REGEXP,
                 extract=re.compile("""
                     \r\n\+CPBF:\s
                     (?P<id>\d+),
                     "(?P<number>\+?\d+)",
                     (?P<category>\d+),
                     \"(?P<name>.*)\"
                     """, re.VERBOSE),
                 nextstate='idle'),
                  
    'get_all_contacts' :
            dict(echo=re.compile('AT\+CPBR=\d,\d+'),
                 end=re.compile('\r\n(OK)\r\n'),
                 error=ERROR_REGEXP,
                 extract=re.compile("""
                       \r\n\+CPBR:\s(?P<id>\d+),
                       "(?P<number>\+?\d+)",
                       (?P<cat>\d+),
                       "(?P<name>.*)"
                       """, re.VERBOSE),
                 nextstate='idle'),
                 
    'get_all_sms' :
            dict(echo=re.compile('AT\+CMGL=4\r'), 
                 end=re.compile('\r\nOK\r\n'),
                 error=ERROR_REGEXP,
                 extract=re.compile('\+CMGL:\s(?P<id>\d+),(?P<storedat>\d),,\d+\r\n(?P<pdu>\w+)\r\n'),
                 nextstate='idle'),
                  
    'get_card_version' :
            dict(echo=re.compile('AT\+GMR\r'),
                 end=re.compile('\r\nOK\r\n$'),
                 error=ERROR_REGEXP,
                 extract=re.compile('\r\n(\+GMR:)?(?P<version>.*)\r\n\r\nOK\r\n'),
                 nextstate='idle'),
     
    'get_card_model' :
            dict(echo=re.compile('AT\+CGMM\r'),
                 end=re.compile('\r\nOK\r\n' ),
                 error=ERROR_REGEXP,
                 extract=re.compile('\r\n(?P<model>.*)\r\n\r\nOK\r\n'),
                 nextstate='idle'),
            
    'get_imsi_number' :
            dict(echo=re.compile('AT\+CIMI\r'),
                 end=re.compile('\r\nOK\r\n$'),
                 error=ERROR_REGEXP,
                 extract=re.compile('\r\n(?P<imsi>\d+)\r\n\r\nOK\r\n'),
                 nextstate='idle'),
            
    'get_imei_number' :
            dict(echo=re.compile('AT\+CGSN\r'),
                 end=re.compile('\r\nOK\r\n'),
                 error=ERROR_REGEXP,
                 extract=re.compile("""
                     \r\n
                     (?P<imei>   # group named imei
                     \d+)        # 1+ digits
                     (,\S+)?     # maybe followed by a ``,SNUMBER''
                     \r\n
                     """, re.VERBOSE),
                 nextstate='idle'),
                 
    'get_network_info' :
            dict(echo=re.compile('AT\+COPS\?\r'),
                 end=re.compile('\r\nOK\r\n$'),
                 error=ERROR_REGEXP,
                 extract=re.compile("""
                          \+COPS:\s\d,\d,
                          "(?P<netname>.*)",
                          (?P<status>\d)\r\n
                          """, re.VERBOSE),
                 nextstate='idle'),
    
    'get_signal_level' :
            dict(echo=re.compile('AT\+CSQ\r'),
                 end=re.compile('\r\nOK\r\n'),
                 error=ERROR_REGEXP,
                 extract=re.compile('\+CSQ:\s(?P<rssi>\d+),(?P<ber>\d+)'),
                 nextstate='idle'),
    
    'get_phonebook_size' :
            dict(echo=re.compile('AT\+CPBR=?\r'),
                 end=re.compile('\r\nOK\r\n'),
                 error=ERROR_REGEXP,
                 extract=re.compile('\+CPBR:\s\(\d-(?P<size>\d+)'),
                 nextstate='idle'),
    
    'get_sms' :
            dict(echo=re.compile('AT\+CMGR=\d+\r'),
                 end=re.compile('\r\nOK\r\n$'),
                 error=ERROR_REGEXP,
                 extract=re.compile('\r\n\+CMGR:\s(?P<storedat>\d),,\d+\r\n(?P<pdu>\w+)\r\n\r\nOK\r\n'),
                 nextstate='idle'),
                 
    'save_sms' :
            dict(echo=re.compile('AT\+CMGW="[\+]?\d+"\r'),
                 end=re.compile('\r\nOK\r\n$'),
                 error=ERROR_REGEXP,
                 extract=re.compile('\+CMGW:\s(?P<id>\d+)\r\n\r\nOK\r\n'),
                 nextstate='idle'),
    
    'send_conn_string' :
            dict(echo=re.compile('AT.*\r'),
                 end=re.compile('\r\nOK\r\n$'),
                 error=ERROR_REGEXP,
                 extract=None,
                 nextstate='idle'),
                 
    'send_sms' :
            dict(echo=re.compile('AT\+CMGS=\d+\r'),
                 end=re.compile('\r\nOK\r\n$'),
                 error=ERROR_REGEXP,
                 extract=re.compile('\+CMGS:\s(\d+)\r\n\r\nOK\r\n'),
                 nextstate='idle'),
                 
    'send_pin' :
            dict(echo=re.compile('AT\+CPIN=\d+\r'),
                 end=re.compile('\r\nOK\r\n'),
                 error=ERROR_REGEXP,
                 extract=re.compile('\r\n(OK)\r\n'),
                 nextstate='idle'),
    'send_puk' :
            dict(echo=re.compile('AT\+CPIN="\d+","\d+"\r'),
                 end=re.compile('\r\nOK\r\n'),
                 error=ERROR_REGEXP,
                 extract=re.compile('\+CPIN:\s[(OK|SIM\sPIN)]'),
                 nextstate='tsk_garbage'),
                 
    'set_sms_indication' :
            dict(echo=re.compile('AT\+CNMI=\d,\d\r'),
                 end=re.compile('\r\nOK\r\n'),
                 error=ERROR_REGEXP,
                 extract=None,
                 nextstate='idle'),
                 
    'set_sms_format' :
            dict(echo=re.compile('AT\+CMGF=\d\r'),
                 end=re.compile('\r\nOK\r\n$'),
                 error=ERROR_REGEXP,
                 extract=None,
                 nextstate='idle'),
}

class ATCmd(object):
    """I encapsulate all data related an AT command"""
    def __init__(self, cmd, eol='\r\n'):
        self.cmd = cmd
        if eol:
            self.cmd += eol
        self.name = ""
        # Some commands like sending a sms require an special handling this
        # is because we have to wait till we receive a prompt like '\r\n> '
        # if splitcmd is set, the second part will be send 0.1 seconds later
        self.splitcmd = None 
        self.deferred = defer.Deferred()
        # Some commands like add_contact have stupid semantics that leave us
        # with no choice but cheating, when cheat is set the deferred will be
        # called back with cheat as return value
        self.cheat = None
        self.timeout = 15
        