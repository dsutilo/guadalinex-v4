# Author:  Pablo Marti
# Copyright (C) 2006  Warp Networks S.L.
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License along
# with this program; if not, write to the Free Software Foundation, Inc.,
# 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
"""Controllers for the main window and the about dialog"""

__version__ = "$Rev: 323 $"

# python imports
import os
import time
import datetime

# pygtk imports
import gtk

# gtkmvc imports
from gtkmvc.controller import Controller

# twisted imports
from twisted.internet import reactor

# VMC imports
from common.persistent import ContactsManager, SMSManager
from common.command import XTRA
from controllers.base import Notifier, TV_DICT
from models.sms import SMSStoreModel
from models.contacts import ContactsStoreModel
import utils.dialogs
import utils.globals

class ApplicationController(Controller, Notifier):
    """Controller for the main window"""
    
    def __init__(self, model, hw_monitor):
        Controller.__init__(self, model)
        Notifier.__init__(self)
        self.hw_monitor = hw_monitor
        self.signal_loop = None
        self.net_loop = None
        self.time_loop = None
        self.start_time = 0
        self.tray = None
        self._setup_trayicon()
    
    def quit_application(self, *args):
        """Closes open connections and exits the application"""
        # hide notifications just in case
        self.hide_notifications()
        self.model.disconnect_internet()
        self.model.disconnect_serial()
    
    def register_view(self, view):
        """Overrides the register_view method and starts the whole thing up"""
        Controller.register_view(self, view)
        window = self.view.get_top_widget()
        window.set_position(gtk.WIN_POS_CENTER)
        window.connect("delete_event",
                                   self.quit_application)
        window.set_size_request(width=600, height=500)
        
        self._setup_treeview(view)
        self._setup_menubar_hacks()
        
        image = gtk.Image()
        image.set_from_file(
                os.path.join(utils.globals.IMAGES_DIR, 'connect.png'))
        image.show()
        self.view['connect_button'].set_icon_widget(image)
        self.view['connect_button'].set_label(_("Connect"))
        
        self.view['signal_image'].set_from_file(
                   os.path.join(utils.globals.IMAGES_DIR, 'signal-00.png'))
        
        self.model.disable_echo()
        self.model.set_sms_indication(2, 1)
        self.model.set_sms_format(0)
        self.start_signal_quality_timer()
        self.set_network_name()
        self._fill_treeviews()
            
        self.view['net_statusbar'].push(1, _('Not connected'))
        self.view['upload_alignment'].hide()
        self.view['download_alignment'].hide()
            
        d = self.model.get_pin_status()
        def callback2(active):
            if not active:
                self.view['change_pin1_menu_item'].set_sensitive(False)
                self.view['request_pin1'].set_active(False)
                
        d.addCallback(callback2)
    
    def _setup_menubar_hacks(self):
        def fake_delete_event(widget, event):
            if event.button == 1:
                self.on_delete_menu_item_activate(widget)
                return True
            
            return False
        
        def fake_forward_event(widget, event):
            if event.button == 1:
                self.on_forward_sms_menu_item_activate(widget)
                return True
            
            return False
        
        items = ['imagemenuitem8', 'sms_delete_menu_item',
                 'forward_sms_menu_item']
        
        for item in items:
            self.view[item].set_events(gtk.gdk.BUTTON_PRESS_MASK)
        
        # contacts_menubar delete item
        self.view['imagemenuitem8'].connect("button_press_event",
                                            fake_delete_event)
        # messages_menubar delete item
        self.view['sms_delete_menu_item'].connect("button_press_event",
                                                  fake_delete_event)
        # messages_menubar forward item
        self.view['forward_sms_menu_item'].connect("button_press_event",
                                                   fake_forward_event)
            
    def _setup_treeview(self, view):
        """Sets up the treeviews"""
        treeviews = ['inbox_treeview', 'drafts_treeview',
                     'sent_treeview', 'contacts_treeview']
        
        for name in treeviews:
            treeview = view[name]
            COL_SMSTYPE, COL_SMSTEXT, COL_SMSNUMBER, \
                    COL_SMSDATE, COL_SMSID = range(5)
            COL_USERTYPE, COL_USERNAME, COL_USERNUMBER, COL_USERID = range(4)
            if name in 'contacts_treeview':
                model = ContactsStoreModel()
            else:
                model = SMSStoreModel()
            
            treeview.set_model(model)
            treeview.get_selection().set_mode(gtk.SELECTION_MULTIPLE)
            
            treeview.connect('key_press_event', self.__on_treeview_key_press)
            
            if name in 'contacts_treeview':
                cell = gtk.CellRendererPixbuf()
                column = gtk.TreeViewColumn(_("Type"))
                column.pack_start(cell)
                column.set_attributes(cell, pixbuf = COL_USERTYPE)
                treeview.append_column(column)
                
                cell = gtk.CellRendererText()
                column = gtk.TreeViewColumn(_("Name"), cell,
                                            text=COL_USERNAME)
                column.set_resizable(True)
                column.set_sort_column_id(COL_USERNAME)
                cell.set_property('editable', True)
                cell.connect('edited', self._name_contact_cell_edited)
                treeview.append_column(column)
                
                cell = gtk.CellRendererText()
                column = gtk.TreeViewColumn(_("Number"), cell,
                                            text=COL_USERNUMBER)
                column.set_resizable(True)
                column.set_sort_column_id(COL_USERNUMBER)
                cell.set_property('editable', True)
                cell.connect('edited', self._number_contact_cell_edited)
                treeview.append_column(column)
                
                cell = gtk.CellRendererText()
                column = gtk.TreeViewColumn("IntId", cell, text=COL_USERID)
                column.set_visible(False)
                column.set_sort_column_id(COL_USERID)
                treeview.append_column(column)
                
            else: # inbox_tv outbox_tv drafts_tv sent_tv
                cell = gtk.CellRendererPixbuf()
                column = gtk.TreeViewColumn(_("Type"))
                column.pack_start(cell)
                column.set_attributes(cell, pixbuf = COL_SMSTYPE)
                treeview.append_column(column)
                
                treeview.connect('row-activated',
                                 self._row_activated_treeview)
                cell = gtk.CellRendererText()
                cell.set_property('editable', False)
                column = gtk.TreeViewColumn(_("Text"), cell,
                                        text=COL_SMSTEXT)
                column.set_resizable(True)
                column.set_sort_column_id(COL_SMSTEXT)
                column.set_sizing(gtk.TREE_VIEW_COLUMN_FIXED)
                column.set_fixed_width(250)
                treeview.append_column(column)
                
                cell = gtk.CellRendererText()
                thename = name in 'sent_treeview' and _("Recipient") \
                                or _("Sender")
                column = gtk.TreeViewColumn(thename, cell, text=COL_SMSNUMBER)
                column.set_resizable(True)
                column.set_sort_column_id(COL_SMSNUMBER)
                cell.set_property('editable', False)
                treeview.append_column(column)
                    
                cell = gtk.CellRendererText()
                column = gtk.TreeViewColumn(_("Date"), cell, text=COL_SMSDATE)
                column.set_resizable(True)
                column.set_sort_column_id(COL_SMSDATE)
                cell.set_property('editable', False)
                treeview.append_column(column)
                
                cell = gtk.CellRendererText()
                column = gtk.TreeViewColumn("intId", cell, text=COL_SMSID)
                column.set_visible(False)
                column.set_sort_column_id(COL_SMSID)
                treeview.append_column(column)
    
    def _fill_treeviews(self):
        """Fills the treeviews with the SIM and HD's data"""
        
        # fill sms from DB
        self.model.set_splash_text(_('Reading messages from DB...'))
        manager = SMSManager()
        d = manager.read_messages()
        def callback(sms_list):
            for sms in sms_list:
                active_tv = TV_DICT[sms.where] # select treeview
                treeview = self.view[active_tv]
                model = treeview.get_model()
                model.add_message(sms)
                
            self.model.set_splash_fraction(.7)
            manager.close()
        d.addCallback(callback)
        
        # fill contacts from DB
        self.model.set_splash_text(_('Reading contacts from DB...'))
        manager = ContactsManager()
        def callback2(contacts):
            _model = self.view['contacts_treeview'].get_model()
            _model.add_contacts(contacts)
            self.model.set_splash_fraction(.8)
            manager.close()
        
        d = manager.read_contacts()
        d.addCallback(callback2)
        
        # fill sms from sim
        self.model.set_splash_text(_('Reading messages from SIM...'))
        d = self.model.get_all_sms()
        def fill_sms_from_sim_cb(messages):
            for sms in messages:
                active_tv = TV_DICT[sms.where]
                _model = self.view[active_tv].get_model()
                _model.add_message(sms)
            
            self.model.set_splash_fraction(.9)
            self.model.set_splash_text(_('Reading contacts from SIM...'))
            
        d.addCallback(fill_sms_from_sim_cb)
        
        # fill contacts from sim
        _model = self.view['contacts_treeview'].get_model()
        d = self.model.get_all_contacts()
        
        def fill_contacts_from_sim_cb(contacts):
            _model.add_contacts(contacts)
            
            self.model.set_splash_fraction(1.0)
            # now we are done, hide the splash screen
            self.model.sview.hide()
            # and show ourselves
            self.view.get_top_widget().show()
        
        d.addCallback(fill_contacts_from_sim_cb)
    
    #----------------------------------------------#
    # Signals Handling                             #
    #----------------------------------------------#
    
    def on_quit_menu_item_activate(self, widget):
        resp = utils.dialogs.open_warning_request_cancel_ok(
                            _("Quit Vodafone Mobile Connect Driver Linux"),
                            _("Are you sure you want to exit?"))
        if resp:
            self.quit_application()
    
    def on_diagnostics_item_activate(self, widget):
        from views.diagnostics import DiagnosticsView
        from controllers.diagnostics import DiagnosticsController
        from models.diagnostics import DiagnosticsModel
        
        model = DiagnosticsModel(self.model.sconn)
        ctrl = DiagnosticsController(model)
        view = DiagnosticsView(ctrl)
        view.run()

    def on_about_menu_item_activate(self, widget):
        from views.application import ApplicationAboutView
        
        ctrl = ApplicationAboutCtrl(self.model)
        view = ApplicationAboutView(ctrl)
        view.run()
        self.model.unregister_observer(ctrl)
    
    def on_change_pin1_menu_item_child_activate(self, widget):
        from views.pin import PinModifyView
        from controllers.pin import PinModifyController
        
        ctrl = PinModifyController(self.model)
        view = PinModifyView(ctrl)
        view.show()
    
    def on_request_pin1_activate(self, checkmenuitem):        
        from models.pin import AskPINModel
        from controllers.pin import AskPINAndExecuteFuncController
        from views.pin import AskPINView
        
        model = AskPINModel(self.model.sconn)
        
        active = checkmenuitem.get_active()
        if active: # The user wants the pin to be asked at startup
            # first we check if its already set
            d = self.model.get_pin_status()
            def callback(active):
                if active:
                    self.view['change_pin1_menu_item'].set_sensitive(True)
                    self.view['request_pin1'].set_active(True)
                else:
                    def func_callback(parent_ctrl):
                        parent_ctrl.view[
                                 'change_pin1_menu_item'].set_sensitive(True)
                        parent_ctrl.view['request_pin1'].set_active(True)
                    
                    def func_errback(parent_ctrl):
                        parent_ctrl.view['request_pin1'].set_active(False)
                    
                    ctrl = AskPINAndExecuteFuncController(model)
                    ctrl.set_callback(func_callback, self)
                    ctrl.set_errback(func_errback, self)
                    view = AskPINView(ctrl)                
                    ctrl.set_mode('enable_pin')
                    view.show()
                
            d.addCallback(callback)
            
        else:  # The user doesn't wants the pin to be asked
            d = self.model.get_pin_status()
            def callback(active):
                if active:
                    def func_callback(parent_ctrl):
                        parent_ctrl.view[
                                 'change_pin1_menu_item'].set_sensitive(False)
                        parent_ctrl.view['request_pin1'].set_active(False)
                    
                    def func_errback(parent_ctrl):
                        parent_ctrl.view['request_pin1'].set_active(True)
                    
                    ctrl = AskPINAndExecuteFuncController(model)  
                    ctrl.set_callback(func_callback, self)
                    ctrl.set_errback(func_errback, self)
                    view = AskPINView(ctrl)                
                    ctrl.set_mode('disable_pin')
                    view.show()
                else:
                    self.view['change_pin1_menu_item'].set_sensitive(False)
                    self.view['request_pin1'].set_active(False)
            
            d.addCallback(callback)
            
    def on_profiles_menu_item_activate(self, widget):
        pass
    
    def on_updates_menu_item_activate(self, widget):
        pass
    
    def on_preferences_menu_item_activate(self, widget):
        from views.preferences import PreferencesView
        from models.preferences import PreferencesModel
        from controllers.preferences import PreferencesController
        
        model = PreferencesModel(self.model.sconn)
        ctrl = PreferencesController(model)
        view = PreferencesView(ctrl, self.model.sconn.device)
        view.show()
    
    def on_mobile1_activate(self, widget):
        # This emits the toggled signal
        self.view['connect_button'].set_active(True)
    
    def on_import_contacts1_activate(self, widget):
        filepath = utils.dialogs.open_import_csv_dialog()
        if filepath:
            from common.csvutils import CSVUnicodeReader
            reader = CSVUnicodeReader(open(filepath))
            _model  = self.view['contacts_treeview'].get_model()
            now = time.strftime("%c", datetime.datetime.now().timetuple())
            
            def callback(free):                
                def callback2(filepath, contact):
                    _model.add_contact(contact)

                from common.persistent import Contact
                
                for row in reader:
                    name = row[0] # Name is unicode
                    number = row[1].encode('utf-8').replace('"', '').strip()
                    index = free.pop(0)
                    contact = Contact(name, number, index)
                    
                    d = self.model.add_contact(contact)
                    d.addCallback(callback2, contact)
            
            d = self.model.get_free_contact_ids()
            d.addCallback(callback)
                
    def on_export_contacts1_activate(self, widget):
        filepath = utils.dialogs.save_csv_file()
        if filepath:
            from common.csvutils import CSVUnicodeWriter
            writer = CSVUnicodeWriter(open(filepath, 'w'))
            def callback(contacts):
                # write contacts from SIM card
                for contact in contacts:
                    writer.write_row(contact.to_csv())
                
                manager = ContactsManager()
                d = manager.read_contacts()
                def callback2(contacts):
                    # write contacts from DB
                    for contact in contacts:
                        writer.write_row(contact.to_csv())
                
                d.addCallback(callback2)

            d = self.model.get_all_contacts()
            d.addCallback(callback)
            
    def on_connect_button_toggled(self, button):
        if button.get_active():
            # the button was not active and now is active
            d = self.model.connect_internet()
            def callback(resp):
                # show the upload/download statusbars
                self.view['upload_alignment'].show()
                self.view['download_alignment'].show()
                # make the connect->mobile insensitive
                self.view['mobile1'].set_sensitive(False)
                # make connection preferences unsensitive
                self.view['preferences_menu_item'].set_sensitive(False)
                self.start_network_stats_timer()
                
                image = gtk.Image()
                image.set_from_file(os.path.join(utils.globals.IMAGES_DIR,
                                    'disconnect.png'))
                image.show()
                self.view['connect_button'].set_icon_widget(image)
                self.view['connect_button'].set_label(_("Disconnect"))
                self.set_network_name()
                
                d = self.model.sconn.get_network_info()
                def callback2(netinfo):
                    self.view['net_statusbar'].pop(1)
                    if netinfo:
                        status = int(netinfo[0].group('status'))
                        if status == 2:
                            self.view['net_statusbar'].push(1,
                                                    _('Connected to 3G'))
                        elif status == 0:
                            self.view['net_statusbar'].push(1,
                                                    _('Connected to GPRS'))
                d.addCallback(callback2)
            def errback(failure):
                print failure
            
            d.addCallback(callback)
            d.addErrback(errback)
            self.model.connecting = True
            self.view['net_statusbar'].push(1, _('Connecting...'))
        else:
            # the button was active and now it isn't
            self.model.disconnect_internet()
            self.model.connecting = False
            self.model.internet_connected = False
            self.view['mobile1'].set_sensitive(True)
            self.view['preferences_menu_item'].set_sensitive(True)
            self.stop_network_stats_timer()
            self.view['upload_alignment'].hide()
            self.view['download_alignment'].hide()
            self.view['net_statusbar'].push(1, _('Not connected'))
                
            image = gtk.Image()
            image.set_from_file(
                    os.path.join(utils.globals.IMAGES_DIR, 'connect.png'))
            image.show()
            self.view['connect_button'].set_icon_widget(image)
            self.view['connect_button'].set_label(_("Connect"))
            
    def on_sms_menu_item_activate(self, widget):
        self.on_sms_button_clicked(None)
    
    def on_usage_menu_item_activate(self, widget):
        self.on_usage_button_clicked(None)
    
    def on_support_menu_item_activate(self, widget):
        self.on_support_button_clicked(None)
    
    def on_minimize_menu_item_activate(self, widget):
        pass
        
    def on_mail_button_clicked(self, widget):
        if not self.__check_if_connected():
            return
        
        from common.config import get_default_binaries
        bindict = get_default_binaries()
        from twisted.internet.utils import getProcessOutput
        getProcessOutput(bindict['mua'], [], os.environ)
    
    def on_sms_button_clicked(self, widget):
        if not self.model.sms_shown:
            if self.model.usage_shown:
                self.view['usage_frame'].hide()
                self.model.usage_shown = False
            elif self.model.support_shown:
                self.view['support_notebook'].hide()
                self.model.support_shown = False
            self.view['sms_frame_alignment'].show()
            self.model.sms_shown = True
        
    def on_internet_button_clicked(self, widget):
        if not self.__check_if_connected():
            return
        
        from common.config import get_default_binaries
        bindict = get_default_binaries()
        from twisted.internet.utils import getProcessOutput
        getProcessOutput(bindict['browser'], [], os.environ)
        
    def on_usage_button_clicked(self, widget):
        if not self.model.usage_shown:
            if self.model.sms_shown:
                self.view['sms_frame_alignment'].hide()
                self.model.sms_shown = False
            if self.model.support_shown:
                self.view['support_notebook'].hide()
                self.model.support_shown = False
            self.view['usage_frame'].show()
            self.model.usage_shown = True
    
    def on_support_button_clicked(self, widget):
        if not self.model.support_shown:
            if self.model.usage_shown:
                self.view['usage_frame'].hide()
                self.model.usage_shown = False
            elif self.model.sms_shown:
                self.view['sms_frame_alignment'].hide()
                self.model.sms_shown = False
            self.view['support_notebook'].show()
            self.model.support_shown = True
    
    def on_new_contact_menu_item_activate(self, widget):
        from views.contacts import AddContactView
        from controllers.contacts import AddContactController
        self.view['main_notebook'].set_current_page(3) # contacts_tv
        ctrl = AddContactController(self.model, self)
        view = AddContactView(ctrl)
        view.show()
    
    def on_search_contact_menu_item_activate(self, widget):
        from views.contacts import SearchContactView
        from controllers.contacts import SearchContactController
        self.view['main_notebook'].set_current_page(3) # contacts_tv
        ctrl = SearchContactController(self.model, self)
        view = SearchContactView(ctrl)
        view.run()
    
    def on_new_sms_activate(self, widget):
        from views.sms import NewSmsView
        from models.sms import NewSmsModel
        from controllers.sms import NewSmsController
        
        ctrl = NewSmsController(NewSmsModel(), self)
        view = NewSmsView(ctrl)
        view.show()
    
    def on_reply_sms_no_quoting_menu_item_activate(self, widget):
        response = self.get_text_number_and_date_of_selection()
        if not response:
            return
        
        from views.sms import ForwardSmsView
        from models.sms import NewSmsModel
        from controllers.sms import ForwardSmsController
        
        ctrl = ForwardSmsController(NewSmsModel(), self)
        view = ForwardSmsView(ctrl)
        ctrl.set_recipient_numbers(response[1])
        view.show()
    
    def on_reply_sms_quoting_menu_item_activate(self, widget):
        response = self.get_text_number_and_date_of_selection()
        if not response:
            return
        
        from views.sms import ForwardSmsView
        from models.sms import NewSmsModel
        from controllers.sms import ForwardSmsController
        
        ctrl = ForwardSmsController(NewSmsModel(), self)
        view = ForwardSmsView(ctrl)
        ctrl.set_textbuffer_text(response[0])
        ctrl.set_recipient_numbers(response[1])
        view.show()
    
    def on_forward_sms_menu_item_activate(self, widget):
        response = self.get_text_number_and_date_of_selection()
        if not response:
            return
        
        from views.sms import ForwardSmsView
        from models.sms import NewSmsModel
        from controllers.sms import ForwardSmsController
        
        ctrl = ForwardSmsController(NewSmsModel(), self)
        view = ForwardSmsView(ctrl)
        view['recipients_entry'].grab_focus()
        ctrl.set_textbuffer_text(response[0])
        view.show()
    
    def on_add_contact_menu_item_activate(self, widget):
        self.on_new_contact_menu_item_activate(None)
    
    def on_delete_menu_item_activate(self, widget):
        page = self.view['main_notebook'].get_current_page() + 1
        treeview = self.view[TV_DICT[page]]
        self.delete_entries(widget, None, treeview)
        treeview.grab_focus()
    
    def on_generic_treeview_row_button_press_event(self, treeview, event):
        if treeview.name in ['inbox_treeview', 'outbox_treeview',
                                 'drafts_treeview']:
            
            if event.button == 1 and event.type == gtk.gdk._2BUTTON_PRESS:
                pass
            elif event.button == 3 and event.type == gtk.gdk.BUTTON_PRESS:
                selection = treeview.get_selection()
                model, pathlist = selection.get_selected_rows()
                if pathlist:
                    menu = self.get_generic_popup_menu(pathlist, treeview)
                    menu.popup(None, None, None, event.button, event.time)
                    return True # selection is not lost
                    
        else: # contacts_treeview
            if event.button == 1 and event.type == gtk.gdk.BUTTON_PRESS:
                pass
            elif event.button == 3 and event.type == gtk.gdk.BUTTON_PRESS:
                selection = treeview.get_selection()
                model, pathlist = selection.get_selected_rows()
                if pathlist:
                    menu = self.get_contacts_popup_menu(pathlist, treeview)
                    menu.popup(None, None, None, event.button, event.time)
                    return True # selection is not lost
    
    def on_cursor_changed_treeview_event(self, treeview):
        col = treeview.get_cursor()[0]
        model = treeview.get_model()
        text = model[col][1]
        buffer = self.view['smsbody_textview'].get_buffer()
        buffer.set_text(text)
        self.view['vbox17'].show()

    def on_main_notebook_switch_page(self, notebook, ptr, pagenum):
        pagenum = int(pagenum)
        if pagenum == 3:
            self.view['contacts_menubar'].show()
            self.view['sms_menubar'].hide()
        else:
            self.view['contacts_menubar'].hide()
            self.view['sms_menubar'].show()
        
        self.view['vbox17'].hide()
            
    #----------------------------------------------#
    # MISC FUNCTIONALITY                           #
    #----------------------------------------------#
    
    def _name_contact_cell_edited(self, widget, path, newvalue):
        """Handler for the cell-edited signal of the name column"""
        model = self.view['contacts_treeview'].get_model()
        # first check that the edit is necessary
        if newvalue == model[path][1]:
            return
        
        model[path][1] = newvalue
        name = unicode(newvalue, 'utf8')
        number = model[path][2]
        index = int(model[path][3])
        
        contact = Contact(name, number, index)
        self._edit_contact(contact)
        
    def _number_contact_cell_edited(self, widget, path, newvalue):
        """Handler for the cell-edited signal of the number column"""
        model = self.view['contacts_treeview'].get_model()
        number = newvalue.strip()
        # first check that the edit is necessary
        if number == model[path][2]:
            return
        
        from utils.utilities import is_valid_number
        if not is_valid_number(number):
            return
        
        model[path][2] = number
        name = unicode(model[path][1], 'utf-8')
        number = newvalue
        index = int(model[path][3])
        
        from common.persistent import Contact
        contact = Contact(name, number, index)
        self._edit_contact(contact)
    
    def _edit_contact(self, contact):
        if int(contact.index) < 1000:
            self.__edit_contact_in_sim(contact)
        else:
            self.__edit_contact_in_db(contact)
    
    def __edit_contact_in_sim(self, contact):
        def callback(ignored):
            print ignored
            
        def errback(failure):
            print failure
        
        d = self.model.add_contact(contact)
        d.addCallback(callback)
        d.addErrback(errback)
    
    def __edit_contact_in_db(self, contact):
        mana = ContactsManager()
        def callback(resp):
            mana.close()
        d = mana.update_contact(contact)
        d.addCallback(callback)
        
    def _setup_trayicon(self):
        # make the tray object
        import egg.trayicon
        tray = egg.trayicon.TrayIcon("VMC")
        # attach an image
        image = gtk.Image()
        image.set_from_file(os.path.join(utils.globals.IMAGES_DIR,
                                         'VF_logo.png'))
        # inside an eventbox
        event_box = gtk.EventBox()
        event_box.set_events(gtk.gdk.BUTTON_PRESS_MASK)
        event_box.connect("button_press_event", self._show_hide_window)
        event_box.add(image)
        # add the eventbox to the tray object
        tray.add(event_box)
        tray.show_all()
        self.tray = tray # we keep a reference for the notifications
    
    def _show_hide_window(self, eventbox, event):
        if event.button == 1: # left click
            window = self.view.get_top_widget()
            if window.get_property('visible'):
                window.hide()
            else:
                window.present()
        elif event.button == 3: # right click
            menu = self.get_trayicon_popup_menu()
            menu.popup(None, None, None, event.button, event.time)
    
    def _row_activated_treeview(self, treeview, path, col):
        # get selected row
        model, selected = treeview.get_selection().get_selected_rows()
        if len(path) > 1: # more than one? no way
            return
        
        iter_ = model.get_iter(selected[0])
        text = model.get_value(iter_, 1)
        number = model.get_value(iter_, 2)
        
        from views.sms import ForwardSmsView
        from models.sms import NewSmsModel
        from controllers.sms import ForwardSmsController
        
        ctrl = ForwardSmsController(NewSmsModel(), self)
        view = ForwardSmsView(ctrl)
        ctrl.set_textbuffer_text(text)
        ctrl.set_recipient_numbers(number)
        view.show()
    
    def __check_if_connected(self):
        """
        Returns True if connected or the user doesn't cares is not connected
        """
        if self.model.internet_connected:
            return True
        else:
            message = _("Not connected")
            details = _("No mobile connection. Do you want to continue?")
            return utils.dialogs.open_warning_request_cancel_ok(message,
                                                        details)
    
    def __on_treeview_key_press(self, widget, event):
        """Handler for key_press_button in treeviews"""
        if event.keyval == 65535: # Key Del was pressed 
            # get current treeview
            num = self.view['main_notebook'].get_current_page() + 1
            treeview_name = TV_DICT[num]
            treeview = self.view[treeview_name]
            self.delete_entries(None, None, treeview)
    
    def delete_entries(self, menuitem, pathlist, treeview):
        """Deletes the entries selected in the treeview
        
        This entries are deleted in SIM/HD and the treeview"""
        model, selected = treeview.get_selection().get_selected_rows()
        iters = [model.get_iter(path) for path in selected]
        pos = treeview.name in 'contacts_treeview' and 3 or 4
        del_ids = [model.get_value(_iter, pos) for _iter in iters] # get ids
        sim_ids, db_ids = self.split_ids(del_ids) # split into categories
        if treeview.name in 'contacts_treeview':
            manager = ContactsManager()
            manager.delete_ids(db_ids) # delete contacts from db
            self.model.delete_list_contacts(sim_ids) # delete sim contacts
        else:
            manager = SMSManager()
            manager.delete_ids(db_ids) # delete sms from db
            self.model.delete_list_sms(sim_ids) # delete sim sms
        [model.remove(_iter) for _iter in iters] # delete from treeview
        
        # If we are in a sms treeview and no sms is selected, clear textview
        if treeview.get_name() != 'contacts_treeview':
            resp = self.get_data_from_selected_row()
            if not resp:
                buffer = self.view['smsbody_textview'].get_buffer()
                buffer.set_text('')
    
    def get_trayicon_popup_menu(self):
        """Returns a popup menu when you right click on the trayicon"""
        menu = gtk.Menu()
        
        if self.model.internet_connected:
            item = gtk.ImageMenuItem(_("Disconnect"))
            img = gtk.Image()
            img.set_from_file(os.path.join(utils.globals.IMAGES_DIR,
                              'stop16x16.png'))
            item.set_image(img)
            item.connect("activate", self.on_mobile1_activate)
            item.show()
            menu.append(item)
        
        else:
            item = gtk.ImageMenuItem(_("Connect"))
            img = gtk.Image()
            img.set_from_file(os.path.join(utils.globals.IMAGES_DIR,
                              'mobile-connect-16x16.png'))
            item.set_image(img)
            item.connect("activate", self.on_connect_button_toggled)
            item.show()
            menu.append(item)
        
        separator = gtk.SeparatorMenuItem()
        separator.show()
        menu.append(separator)
        
        item = gtk.ImageMenuItem(_("Send SMS"))
        img = gtk.Image()
        img.set_from_file(os.path.join(utils.globals.IMAGES_DIR,
                              'sms16x16.png'))
        item.set_image(img)
        item.connect("activate", self.on_new_sms_activate)
        item.show()
        menu.append(item)
        
        separator = gtk.SeparatorMenuItem()
        separator.show()
        menu.append(separator)
        
        item = gtk.ImageMenuItem(_("Quit"))
        img = gtk.image_new_from_stock(gtk.STOCK_QUIT, gtk.ICON_SIZE_MENU)
        item.set_image(img)
        item.connect("activate", self.on_quit_menu_item_activate)
        item.show()
        menu.append(item)
        
        return menu
    
    def get_contacts_popup_menu(self, pathinfo, treeview):
        """Returns a popup menu for the contacts treeview"""
        menu = gtk.Menu()
        item = gtk.ImageMenuItem(_("_Delete"))
        img = gtk.image_new_from_stock(gtk.STOCK_DELETE, gtk.ICON_SIZE_MENU)
        item.set_image(img)
        item.connect("activate", self.delete_entries, pathinfo, treeview)
        item.show()
        menu.append(item)
        
        return menu
    
    def get_generic_popup_menu(self, pathinfo, treeview):
        """Returns a popup menu for the rest of treeviews"""
        detailmenu = gtk.Menu()
        item = gtk.ImageMenuItem(_("_Add to contacts"))
        img = gtk.image_new_from_stock(gtk.STOCK_ADD, gtk.ICON_SIZE_MENU)
        item.set_image(img)
        item.connect("activate", self._use_detail_add_contact)
        item.show()
        
        detailmenu.append(item)
        detailitem = gtk.MenuItem(_("_Use detail"))
        detailitem.set_submenu(detailmenu)
        detailitem.show()
        
        menu = gtk.Menu() # main menu
        menu.append(detailitem)
        
        if treeview.get_name() != 'drafts_treeview':
            item = gtk.ImageMenuItem(_("Save to draft"))
            img = gtk.image_new_from_stock(gtk.STOCK_SAVE, gtk.ICON_SIZE_MENU)
            item.set_image(img)
            item.connect("activate", self._save_sms_to_draft)
            item.show()
            menu.append(item)
            
        separator = gtk.SeparatorMenuItem()
        separator.show()
        menu.append(separator)
        
        item = gtk.ImageMenuItem(_("Delete"))
        img = gtk.image_new_from_stock(gtk.STOCK_DELETE, gtk.ICON_SIZE_MENU)
        item.set_image(img)
        item.connect("activate", self.delete_entries, pathinfo, treeview)
        item.show()
        menu.append(item)
        
        return menu
    
    def _save_sms_to_draft(self, widget):
        """This will save the selected SMS to the drafts tv and the DB"""
        resp = self.get_data_from_selected_row()
        if not resp:
            return
        
        id_ = int(resp[3])
        def callback(sms):
            # Now save SMS to DB
            mana = SMSManager()
            def callback2(smsrep):
                self.view['drafts_treeview'].get_model().add_message(smsrep)
                mana.close()
            
            d = mana.insert_message(sms, 2) # 2 == drafts_treeview
            d.addCallback(callback2)
            
        if id_ < 1000:
            d = self.model.get_sms(id_)
            d.addCallback(callback)
        
    def _use_detail_add_contact(self, widget):
        """Handler for the use detail menu"""
        resp = self.get_text_number_and_date_of_selection()
        if not resp:
            return
        number = resp[1]
        
        from views.contacts import AddContactView
        from controllers.contacts import AddContactController
        ctrl = AddContactController(self.model, self)
        view = AddContactView(ctrl)
        view['add_contact_number_entry'].set_text(number)
        view.show()
    
    def get_data_from_selected_row(self):
        """Returns the data from the selected row"""
        
        page = self.view['main_notebook'].get_current_page() + 1
        if page == 4 : # contacts
            return None
        
        treeview = self.view[TV_DICT[page]]
        selection = treeview.get_selection()
        model, selected = selection.get_selected_rows()
        if not selected or len(selected) > 1:
            return None
        
        _iter = model.get_iter(selected[0])
        text = model.get_value(_iter, 1)
        number = model.get_value(_iter, 2)
        date = model.get_value(_iter, 3)
        id_ = model.get_value(_iter, 4)
        return text, number, date, id_
        
    def get_text_number_and_date_of_selection(self):
        """Returns a tuple with the text and number of current selected row
        
        Returns None if # of row selected != 1 or current_page == contacts
        """
        resp = self.get_data_from_selected_row()
        if resp:
            return resp[0], resp[1], resp[2]
        
        return None
    
    def set_network_name(self):
        """Sets the network name in network_name_label"""
        d = self.model.sconn.get_network_info()
        def callback(netinfo):
            if netinfo:
                netname = netinfo[0].group('netname')
                status = int(netinfo[0].group('status'))
                conn_type = (status == 0) and 'GPRS' or '3G'
                self.view['cell_type_label'].set_text(conn_type)
                
                if netname in ['Limited Service', 'No Connection']:
                    reactor.callLater(3, self.set_network_name)
                    return
                
                try:
                    XTRA['numericid'].match(netname).group()
                    def set_it():
                        # lookup the network id in the database
                        from utils.utilities import get_network_name_from_id
                        from utils.utilities import country_to_code
                        def callback(response):
                            if not response:
                                reactor.callLater(5, set_it)
                                return
                            
                            operator = response[0]
                            country = response[1]
                            try:
                                code = country_to_code[country]
                            except KeyError:
                                code = country
                            op_name = operator.capitalize() + ' ' + \
                                        code.upper()
                            self.view['network_name_label'].set_text(op_name)
                                                             
                        d = get_network_name_from_id(netname)
                        d.addCallback(callback)
                    set_it()
                except AttributeError:
                    self.view['network_name_label'].set_text(netname)
            else:
                def tryagain():
                    d = self.model.sconn.get_network_info()
                    d.addCallback(callback)
                reactor.callLater(4, tryagain)
        d.addCallback(callback)
    
    def split_ids(self, the_ids):
        """Splits the_ids in two lists of SIM ids and DB ids"""
        sim_ids = []
        db_id = []
        for id_ in the_ids:
            if int(id_) < 1000:
                sim_ids.append(id_)
            else:
                db_id.append(id_)

        return sim_ids, db_id
    
    def start_signal_quality_timer(self):
        """Starts the timer that regularly checks the signal quality"""
        from twisted.internet import task
        self.signal_loop = task.LoopingCall(self.change_signal_level)
        self.signal_loop.start(10)
    
    def start_network_stats_timer(self):
        """Starts the timer that updates the speed stats on screen"""
        # first off, show both status bars
        self.view['upload_alignment'].show()
        self.view['download_alignment'].show()
        from twisted.internet import task
        self.net_loop = task.LoopingCall(self.change_net_stats)
        self.net_loop.start(1)
    
    def start_connection_timer(self):
        from twisted.internet import task
        self.start_time = time.time()
        self.time_loop = task.LoopingCall(self.change_time)
        self.time_loop.start(1)
    
    def stop_connection_timer(self):
        """Stops the connection timer"""
        self.time_loop.stop()
        self.view['time_label'].set_text('')
    
    def stop_network_stats_timer(self):
        """Stops the network stats timer and clears messages from statusbar"""
        try:
            self.net_loop.stop()
        except:
            pass
        self.view['upload_alignment'].hide()
        self.view['download_alignment'].hide()
    
    def change_time(self):
        from common.uptime import get_uptime_string
        diff = time.time() - self.start_time
        conn_time = get_uptime_string(diff)
        self.view['time_label'].set_text(conn_time)
    
    def change_signal_level(self):
        """Changes the signal level of the bottom_progressbar"""
        def callback(slevel):
            slevel = slevel[0]
            slevel = int(slevel.group('rssi'))
            if slevel < 5 or slevel > 31:
                image = 'signal-00.png'
            elif slevel < 10:
                image = 'signal-25.png'
            elif slevel < 16:
                image = 'signal-50.png'
            elif slevel < 26:
                image = 'signal-75.png'
            else:
                image = 'signal-100.png'
            
            self.view['signal_image'].set_from_file(
                   os.path.join(utils.globals.IMAGES_DIR, image))
        
        d = self.model.get_signal_level()
        d.addCallback(callback)
    
    def change_net_stats(self):
        """Updates network statistics"""
        up = self.model.netspeed['up']
        down = self.model.netspeed['down']
        
        upspeed = (up * 8) / 1000.0
        downspeed = (down * 8) / 1000.0
        
        if upspeed > 1000:
            self.view['upload_statusbar'].push(1,
                                         "%3.2f Mbps" % (upspeed / 1000))
        else:
            self.view['upload_statusbar'].push(1, "%3.2f Kbps" % upspeed)
        
        if downspeed > 1000:
            self.view['download_statusbar'].push(1,
                                         "%3.2f Mbps" % (downspeed / 1000))
        else:
            self.view['download_statusbar'].push(1, "%3.2f Kbps" % downspeed)
    
    #################################################################
    # SIGNAL HANDLERS                                               #
    #################################################################
        
    def sms_recv(self, smsinfo):
        """I'm called by a louie's signal whenever a SMS is received"""
        assert smsinfo.group('where') == "SM"
        def callback(sms):
            # add sms to treeview
            self.view['inbox_treeview'].get_model().add_message(sms)
            # notify the user
            message = _("<small>SMS received from %s</small>") % sms.number
            details = _(
                    "<small>Received at %(date)s</small>\n<b>%(text)s</b>") % \
                    {'date' : sms.get_localised_date(), 'text' : sms.text}
            
            from common.notification import show_normal_notification
            noti = show_normal_notification(self.tray, message, details)
            self.append_notification(noti)
        
        index = int(smsinfo.group('id'))
        d = self.model.get_sms(index)
        d.addCallback(callback)
    
    def timeout_handler(self, *args):
        """
        I'm called by a louie's signal whenever a timeout in an ATCmd occurs
        """
        message = _("Problems with SIM card connection")
        details = _(
"""
An unexpected internal problem has occured, this probably
has happened because the SIM card took too much to reply
my last command. Please eject and insert the card and start
Vodafone Mobile Connect Driver Linux again.
""")
        utils.dialogs.open_message_dialog(message, details)
        reactor.stop()
    
    def invalid_dns_handler(self, dnslist):
        """Handler called when wvdial recibes invalid DNS"""
        title = _("Invalid DNS recibed from APN")
        message = _(
"""
<small>The DNS recibed from the APN are invalid. You will probably want
to restart the connection or if the problem does persist, you can specify
an static DNS entry in the connection preferences</small>
""")
        from common.notification import show_error_notification
        notification = show_error_notification(self.tray, title, message)
        self.append_notification(notification)
    
    def disconnected_handler(self, *args):
        """Handler called when wvdial recibes invalid DNS"""
        title = _("Disconnected from Internet")
        message = _(
"""
<small>Vodafone Mobile Connect Driver Linux has given up
after trying to connect three times to Internet. This might
be provoked by a problem in the configuration or just the
fact that there's no carrier.</small>
""")
        from common.notification import show_error_notification
        notification = show_error_notification(self.tray, title, message)
        self.append_notification(notification)
        self.view['connect_button'].set_active(False)
    
    def device_removed_handler(self):
        """Handler called when wvdial recibes invalid DNS"""
        message = _("Device in use removed")
        details = _(
"""
The 3G device in use has been removed. Now Vodafone Mobile
Connect Driver Linux is going to shutdown. In order to
continue, plug in the 3G device and start again.
""")
        utils.dialogs.open_message_dialog(message, details)
        reactor.stop()
        
class ApplicationAboutCtrl (Controller):
    """Controller for the about dialog"""
    
    def __init__(self, model):
        Controller.__init__(self, model)
