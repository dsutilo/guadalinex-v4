# -*- coding: utf-8 -*-
# Copyright (C) 2006-2007  Vodafone España, S.A.
# Author:  Pablo Martí
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License along
# with this program; if not, write to the Free Software Foundation, Inc.,
# 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
"""Module uptime"""

__version__ = "$Rev: 406 $"

# twisted imports
from twisted.internet import defer, utils

try:
    _
except NameError:
    import gettext
    _ = gettext.gettext

time_desc = {
      60 : 'minute',
      3600 : 'hour',
      86400 : 'day',
}
time_keys = time_desc.keys()
time_keys.sort()
time_keys.reverse()

def get_uptime():
    """Returns a deferred that will be called with the uptime as string"""
    d = utils.getProcessOutput('cat', args=['/proc/uptime'])
    def2 = defer.Deferred()
        
    def callback(uptime, d2):
        uptime = uptime.split()[0]
        uptime = float(uptime)
        from math import ceil
        uptime = int(ceil(uptime))
        msg = get_uptime_string(uptime)
            
        d2.callback(msg)
    d.addCallback(callback, def2)
    return def2

def get_time_dict(uptime):
    """Returns a dictionary with a resolution of minutes"""
    resp = {}
    for key in time_keys:
        div = int(uptime / key)
        if div == 0:
            continue
        uptime -= div * key
        key_name = time_desc[key]
        resp[key_name] = div
    
    return resp

def get_uptime_string(uptime):
    """Returns a uptime's like output from a uptime expressed in seconds"""
    time_dict = get_time_dict(uptime)
    try:
        hour = "%d" % time_dict['hour']
    except KeyError:
        hour = "0"
    
    try:
        minute = "%d" % time_dict['minute']
        if time_dict['minute'] < 10:
            minute = '0' + minute
    except KeyError:
        minute = '00'
    
    msg = "%s:%s" % (hour, minute)
    try:
        day = time_dict['day']
        if day > 1:
            resp = _("%(day)d days, %(msg)s") % {'day': day, 'msg' : msg}
        else:
            resp = _("%(day)d day, %(msg)s") % {'day': day, 'msg' : msg}
        
    except KeyError:
        resp = msg
    
    return resp
