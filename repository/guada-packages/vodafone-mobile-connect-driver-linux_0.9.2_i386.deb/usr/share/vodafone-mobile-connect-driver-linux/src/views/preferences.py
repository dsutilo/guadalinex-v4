# Author:  Pablo Marti
# Copyright (C) 2006  Warp Networks S.L.
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License along
# with this program; if not, write to the Free Software Foundation, Inc.,
# 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
"""View for the preferences window"""
__version__ = "$Rev: 239 $"

# python imports
import os.path
import utils.globals
# gtkmvc imports
from gtkmvc.view import View

option_dict_hsdpa = {
   'hsdpa' : 0,
   'umts' : 1,
   'gprs' : 2
}
option_dict_umts = {
   'umts' : 0,
   'gprs' : 1
}
option_dict_hsdpa_list = ['hsdpa', 'umts', 'gprs']
option_dict_umts_list = ['umts', 'gprs']

class PreferencesView(View):
    """View for the preferences window"""
    
    GLADE_FILE = os.path.join(utils.globals.GLADE_DIR, "preferences.glade")
    
    def __init__(self, ctrl, device):
        View.__init__(self, ctrl, self.GLADE_FILE, 'preferences_window',
                      register=False, domain="VMC")
        self.device = device
        self.setup_view()
        ctrl.register_view(self)
    
    def setup_view(self):
        from common.config import VMCConfig
        conf = VMCConfig()
        
        # get values
        username = conf.get('connection', 'username')
        password = conf.get('connection', 'password')
        apn = conf.get('connection', 'apn')
        conn = conf.get('connection', 'connection')
        
        # populate entries
        self['username_entry'].set_text(username)
        self['password_entry'].set_text(password)
        self['apn_entry'].set_text(apn)
        
        # set model in combobox
        model = self.get_combobox_model(conn)
        self['connection_combobox'].set_model(model)
        # select current preferred connection
        from common.device import CONN_OPTS_DICT_REV
        name = CONN_OPTS_DICT_REV[conn]
        self.select_combobox_option(model, name)
        
        # name server stuff
        static = conf.getboolean('connection', 'staticdns')
        dns1 = conf.get('connection', 'dns1')
        dns2 = conf.get('connection', 'dns2')
        self['dns1_entry'].set_text(dns1)
        self['dns2_entry'].set_text(dns2)
        if not static:
            self['checkbutton'].set_active(False)
            self['dns1_entry'].set_sensitive(False)
            self['dns2_entry'].set_sensitive(False)
        else:
            self['checkbutton'].set_active(True)
        
    def get_combobox_model(self, preferred_conn):
        import gobject
        import gtk
        model = gtk.ListStore(gobject.TYPE_STRING)
        from common.device import CONN_OPTS_LIST as options
        [model.append([opt]) for opt in options]
        return model
    
    def select_combobox_option(self, model, option):
        cont = 0
        for row in model:
            if row[0] == option:
                self['connection_combobox'].set_active(cont)
                return
            cont += 1
        