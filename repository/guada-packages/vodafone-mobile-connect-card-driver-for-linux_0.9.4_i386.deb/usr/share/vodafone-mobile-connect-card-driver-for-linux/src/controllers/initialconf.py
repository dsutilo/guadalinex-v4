# -*- coding: utf-8 -*-
# Copyright (C) 2006-2007  Vodafone España, S.A.
# Author:  Pablo Martí
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License along
# with this program; if not, write to the Free Software Foundation, Inc.,
# 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

__version__ = "$Rev: 406 $"

# gtkmvc imports
from gtkmvc import Controller

class DeviceConfController(Controller):
    
    def __init__(self, model, sview=None):
        Controller.__init__(self, model)
        self.sview = sview
        
    def on_ok_button_clicked(self, widget):
        # get selected option
        model = self.view['conn_combobox'].get_model()
        index = self.view['conn_combobox'].get_active()
        if index < 0:
            conn = None
        else:
            conn = model[index][0]
        if not conn:
            return
        
        from common.hardware import CONN_OPTS_DICT
        conn_option = CONN_OPTS_DICT[conn]
        from common.config import VMCConfig
        vomcfg = VMCConfig()
        vomcfg.set('connection', 'connection', conn_option)
        vomcfg.write()
        
    def on_cancel_button_clicked(self, widget):
        self.model.unregister_observer(self)
        self.view.hide()
    